;;; Generated from the package header. -*- no-byte-compile: t; -*-
(define-package "agnostic-llm" "0.12.1.0.20261025.0" "Agentic CLI integration" '((emacs "28.1") (transient "0.4.0") (vterm "0.0.2")))
