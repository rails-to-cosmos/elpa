;;; Generated from the package header. -*- no-byte-compile: t; -*-
(define-package "agnostic-llm" "0.13.0.0.20261109.0" "Agentic CLI integration" '((emacs "28.1") (transient "0.4.0") (vterm "0.0.2")))
