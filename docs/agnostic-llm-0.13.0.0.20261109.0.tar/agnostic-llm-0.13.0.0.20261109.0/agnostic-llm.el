;;; agnostic-llm.el --- Agentic CLI integration -*- lexical-binding: t; -*-

;; Copyright (c) 2026 Dmitry Akatov
;; Author: Dmitry Akatov <dmitry.akatov@protonmail.com>
;; URL: https://github.com/rails-to-cosmos/agnostic-llm
;; Package-Version: 0.13.0.0.20261109.0
;; Package-Requires: ((emacs "28.1") (transient "0.4.0") (vterm "0.0.2"))
;; Keywords: convenience, tools

;;; Commentary:
;;
;; Drive an agentic CLI from Emacs.  Each project gets a default
;; `*llm:PROJECT*' vterm plus optional named sessions; a prompt buffer
;; feeds it, and a throwaway "bubble" streams a one-shot reply inline
;; without disturbing the main session.  `agnostic-llm-show-last-response'
;; renders the latest assistant turn from the session JSONL into a read-only
;; buffer.
;;
;; A transient menu (`agnostic-llm-menu') gathers the commands and exposes
;; per-invocation switches for model, reasoning effort, and skipping
;; permission prompts.  A FIXME/TODO annotation system records notes at
;; point, persists them (per-project under `.agnostic-llm/' or per-user
;; under `~/.cache/agnostic-llm/'), lists them, and can hand them back to
;; the LLM to resolve.
;;
;; Everything provider-specific — the CLI executable, its command-line
;; flags, the session-store layout, and the model/effort catalog — lives in
;; `agnostic-llm-providers', keyed by `agnostic-llm-provider'.  `claude' is
;; the default provider; add entries to drive other agentic CLIs (see
;; docs/multi-backend-design.org).
;;
;; Requires the active provider's CLI on PATH (the `claude' CLI by default).
;; Binds no global keys itself — bind the entry points (`agnostic-llm',
;; `agnostic-llm-menu', `agnostic-llm-prompt', ...) from your own
;; configuration.

;;; Code:

(require 'cl-lib)
(require 'subr-x)
(require 'project)
(require 'transient)
(require 'ansi-color)
(require 'vterm)

;;; Customization

(defgroup agnostic-llm nil
  "Agentic CLI integration for Emacs."
  :group 'tools
  :prefix "agnostic-llm-")

;;; Provider
;;
;; Each agentic CLI's executable, flags, session-store layout, and model
;; catalog live in a provider plist.  `agnostic-llm-providers' is the
;; registry, `agnostic-llm-provider' selects the active entry, and generic
;; code reads fields via `agnostic-llm--provider-get' — never a literal CLI
;; name.

(defcustom agnostic-llm-provider 'claude
  "Symbol selecting the active entry in `agnostic-llm-providers'.
The built-in choices are `claude' and `codex'.  Default `claude' drives
the Claude CLI."
  :type '(choice (const :tag "Claude Code" claude)
                 (const :tag "OpenAI Codex" codex)
                 (symbol :tag "Other registered provider"))
  :group 'agnostic-llm)

(defcustom agnostic-llm-providers
  '((claude :executable          "claude"
            :continue-flag       "-c"
            :print-flag          "-p"
            :session-id-flag     "--session-id"
            :resume-flag         "--resume"
            :session-name-flag   "--name"
            :named-session-function agnostic-llm--claude-named-session
            :named-sessions-function agnostic-llm--claude-named-sessions
            :option-vocabulary   ((model "--model" "%s")
                                  (effort "--effort" "%s")
                                  (dangerous "--dangerously-skip-permissions"))
            :session-dir         "~/.claude/projects/"
            :session-file-regexp "\\.jsonl\\'"
            :model-prefix        "claude-"
            :models              (("claude-fable-5"    . (:efforts ("default" "low" "medium" "high" "max" "ultracode")))
                                  ("claude-sonnet-5"   . (:efforts ("default" "low" "medium" "high" "max" "ultracode")))
                                  ("claude-opus-5"     . (:efforts ("default" "low" "medium" "high" "max" "ultracode")))
                                  ("claude-opus-4-8"   . (:efforts ("default" "low" "medium" "high" "max" "ultracode")))
                                  ("claude-opus-4-7"   . (:efforts ("default" "low" "medium" "high" "max")))
                                  ("claude-opus-4-6"   . (:efforts ("default" "low" "medium" "high" "max")))
                                  ("claude-sonnet-4-6" . (:efforts ("default" "low" "medium" "high" "max")))
                                  ("claude-haiku-4-5"  . (:efforts ("default" "low" "medium" "high" "max")))))

    (codex :executable          "codex"
           :continue-flag       "resume --last"
           :print-flag          "exec"
           :option-vocabulary   ((model "--model" "%s")
                                 (effort "-c" "model_reasoning_effort=%s")
                                 (dangerous "--yolo"))
           :session-dir         "~/.codex/sessions/"
           :session-file-regexp "rollout-.*\\.jsonl\\'"
           :model-prefix        ""
           :session-command-function agnostic-llm--codex-session-command
           :named-session-function   agnostic-llm--codex-named-session
           :named-sessions-function  agnostic-llm--codex-named-sessions
           :session-rename-command   "/rename %s"
           :bubble-command-function  agnostic-llm--codex-bubble-command
           :session-file-function    agnostic-llm--codex-session-file
           :extract-response-function agnostic-llm--codex-extract-last-response
           :bubble-json-events  t
           :models              (("gpt-6-astra"   . (:efforts ("default" "low" "medium" "high" "xhigh" "max")))
                                 ("gpt-5.6-sol"   . (:efforts ("default" "none" "low" "medium" "high" "xhigh" "max")))
                                 ("gpt-5.6-terra" . (:efforts ("default" "none" "low" "medium" "high" "xhigh" "max")))
                                 ("gpt-5.6-luna"  . (:efforts ("default" "none" "low" "medium" "high" "xhigh" "max"))))))

  "Registry of agentic-CLI providers, keyed by symbol.
Each entry is (SYMBOL . PLIST); `agnostic-llm-provider' names the active
one.  PLIST fields:

  :executable          program run for the session vterm and bubble.
  :continue-flag       continue the most recent session.
  :print-flag          one-shot, non-interactive prompt.
  :option-vocabulary   alist translating semantic options into CLI argv
                       templates.  Built-in keys are `model', `effort',
                       and `dangerous'; a \"%s\" token receives the value.
  :session-id-flag     pin a stable session id (bubble turns).
  :resume-flag         resume a session by id.
  :session-name-flag   name a new interactive session.
  :session-dir         session-store root; the project directory encodes
                       into one component under it.
  :session-file-regexp matches a session transcript there (newest by
                       mtime is live).
  :model-prefix        vendor prefix stripped before family/version
                       parsing (e.g. \"claude-\").
  :models              catalog as (NAME . PLIST); each `:efforts' lists a
                       model's effort levels.  Newest-first; the first is
                       the CLI default.

Providers whose CLI or session layout cannot be expressed by those simple
fields may supply function symbols in `:session-command-function',
`:bubble-command-function', `:session-file-function', and
`:extract-response-function'.  `:bubble-json-events' selects the Codex-style
JSONL event filter, which also learns the server-assigned session id.

Named sessions use `:named-session-function' to resolve a display name to a
resume id and `:named-sessions-function' to enumerate `(NAME ID FILE)' records
for a project root.  A provider without `:session-name-flag' may expose an
interactive `:session-rename-command' template; `%s' receives the
shell-independent name.

Add an entry and point `agnostic-llm-provider' at it to drive another CLI.
See docs/multi-backend-design.org."
  :type '(alist :key-type symbol :value-type sexp)
  :group 'agnostic-llm)

(defun agnostic-llm--provider ()
  "Return the plist describing the active provider.
Signals an error when `agnostic-llm-provider' names no entry in
`agnostic-llm-providers'."
  (or (alist-get agnostic-llm-provider agnostic-llm-providers)
      (error "Unknown `agnostic-llm-provider': %s" agnostic-llm-provider)))

(defun agnostic-llm--provider-get (key)
  "Return KEY from the active provider's plist (see `agnostic-llm--provider')."
  (plist-get (agnostic-llm--provider) key))

(defun agnostic-llm--provider-option-args (option value)
  "Derive argv for semantic OPTION with VALUE under the active provider.
The provider's `:option-vocabulary' maps OPTION to an argv template.  Each
\"%s\" occurrence in that template is replaced with VALUE.  A nil VALUE means
the option is inactive and produces no arguments."
  (when value
    (when-let* ((template
                (cdr (assq option
                           (agnostic-llm--provider-get :option-vocabulary)))))
      (mapcar (lambda (word)
                (string-replace "%s" (format "%s" value) word))
              template))))

(defun agnostic-llm--provider-options-args (model effort dangerous)
  "Derive provider argv for semantic MODEL, EFFORT, and DANGEROUS options."
  (append (agnostic-llm--provider-option-args 'model model)
          (agnostic-llm--provider-option-args 'effort effort)
          (agnostic-llm--provider-option-args 'dangerous dangerous)))

(defun agnostic-llm--models ()
  "Return the active provider's model catalog (its `:models' alist)."
  (agnostic-llm--provider-get :models))

;;; Project Root Detection

(defcustom agnostic-llm-shell (or (getenv "SHELL") shell-file-name)
  "Shell that execs the provider CLI, so its rc files set PATH and credentials.
Runs as `SHELL ARGS \"exec CLI...\"' with `agnostic-llm-shell-args'; nil runs
the CLI under Emacs's own environment."
  :type '(choice (const :tag "Emacs environment" nil) string)
  :group 'agnostic-llm)

(defcustom agnostic-llm-shell-args '("-l" "-i" "-c")
  "Arguments to `agnostic-llm-shell' before the `exec CLI...' command string."
  :type '(repeat string)
  :group 'agnostic-llm)

(defun agnostic-llm--shell-argv (command)
  "Argv that execs shell COMMAND through `agnostic-llm-shell', else `sh -c'."
  (if agnostic-llm-shell
      `(,agnostic-llm-shell ,@agnostic-llm-shell-args ,(concat "exec " command))
    (list "sh" "-c" command)))

(defun agnostic-llm--shell-wrap (command)
  "Shell COMMAND wrapped for `vterm-shell': its `agnostic-llm--shell-argv', quoted."
  (mapconcat #'shell-quote-argument (agnostic-llm--shell-argv command) " "))

(defvar-local agnostic-llm-session-name nil
  "User-facing role name of this session, or nil for the default session.")

(defvar-local agnostic-llm-session-label nil
  "Provider-native display name of this session, or nil when unnamed.")

(defun agnostic-llm--send-startup-input (buffer text)
  "Send one startup TEXT line to live vterm BUFFER."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (when (process-live-p (get-buffer-process buffer))
        (vterm-send-string text)
        (vterm-send-return)))))

(defun agnostic-llm--schedule-startup-inputs (buffer inputs)
  "Send INPUTS to BUFFER in order after its provider TUI starts."
  (cl-loop for text in inputs
           for delay from 0.5 by 0.5
           do (run-at-time delay nil #'agnostic-llm--send-startup-input
                           buffer text)))

(defun agnostic-llm--open-vterm
    (name command &optional same-window session-name session-label startup-inputs)
  "Open an LLM vterm NAME running COMMAND via `agnostic-llm--shell-wrap'.
Pops to another window unless SAME-WINDOW.  SESSION-NAME and SESSION-LABEL
become buffer-local identity.  STARTUP-INPUTS are submitted after launch."
  (let ((vterm-shell (agnostic-llm--shell-wrap command))
        (provider agnostic-llm-provider))
    (if same-window (vterm name) (vterm-other-window name))
    (setq-local agnostic-llm-provider provider)
    (setq-local agnostic-llm-session-name session-name)
    (setq-local agnostic-llm-session-label session-label)
    (when startup-inputs
      (agnostic-llm--schedule-startup-inputs (current-buffer) startup-inputs))))

(defcustom agnostic-llm-project-root-markers
  '(".git" ".claude" "CLAUDE.md" ".codex" "AGENTS.md")
  "Files/dirs that indicate a project root."
  :type '(repeat string)
  :group 'agnostic-llm)

(defcustom agnostic-llm-dangerously-skip-permissions nil
  "When non-nil, pass the provider's `dangerous' option to the CLI.
Applies to the main `*llm:PROJECT*' vterm and to the inline
bubble (captured once at bubble creation as buffer-local state).

Normally toggled per-invocation via the `-d' switch in `agnostic-llm-menu'
rather than set directly.  Beware: with this flag the CLI skips all
tool-use confirmation prompts."
  :type 'boolean
  :group 'agnostic-llm)

(defun agnostic-llm-model-choices ()
  "Return the model names offered by `agnostic-llm-menu' under the `-m' switch.
The names come from the active provider's model catalog, in table order."
  (mapcar #'car (agnostic-llm--models)))

(defcustom agnostic-llm-model nil
  "Model name passed through the active provider's option vocabulary.
Nil means use the CLI's own default (whatever its config picks).  A
string is passed through verbatim — full names like \"claude-opus-4-7\"
or aliases like \"opus\" both work with the claude provider.

Normally toggled per-invocation via the `-m' switch in `agnostic-llm-menu'
rather than set directly.  Applies to the main `*llm:PROJECT*'
vterm and to the inline bubble (captured once at bubble creation)."
  :type '(choice (const :tag "Default (CLI picks)" nil)
                 (string :tag "Model name"))
  :group 'agnostic-llm)

;;; Model resolution (name -> provider `:models' entry)
;;
;; A model name may be a full id ("claude-opus-4-8"), a date-suffixed id
;; ("claude-haiku-4-5-20251001"), or a bare family alias ("opus").
;; `agnostic-llm--model-split' breaks a name into (FAMILY NUMS), and
;; `version-list-<' orders version lists so a bare alias resolves
;; to its family's newest entry.  `agnostic-llm--model-spec' ties these
;; together, returning the declarative provider `:models' entry that
;; governs a model's effort levels.

(defun agnostic-llm--model-split (model)
  "Split MODEL into (FAMILY NUMS), without resolving aliases.
FAMILY is the family string (\"opus\", \"sonnet\", ...) or nil.  NUMS is
the version as a list of integers (major minor ...); it is empty for a
bare alias like \"opus\".  The provider's `:model-prefix' (e.g. `claude-')
and any trailing date component (an eight-digit YYYYMMDD snapshot, such as
the 20251001 in \"haiku-4-5-20251001\") are ignored."
  (let* ((name (string-remove-prefix (or (agnostic-llm--provider-get :model-prefix) "")
                                     (or model "")))
         (parts (split-string name "-" t)))
    (list (car parts)
          (cl-loop for p in (cdr parts)
                   when (and (string-match-p "\\`[0-9]+\\'" p)
                             (not (string-match-p "\\`[0-9]\\{8\\}\\'" p)))
                   collect (string-to-number p)))))

(defun agnostic-llm--model-spec (model)
  "Return the provider `:models' entry for MODEL, or nil when unknown.
Nil MODEL resolves to the first entry (the provider's default model).  A
full name matches by `assoc'; a date-suffixed id (e.g.
\"claude-haiku-4-5-20251001\") matches the entry with the same family and
version; a bare alias (e.g. \"opus\") matches that family's newest entry
ordered by `version-list-<'."
  (let ((models (agnostic-llm--models)))
    (if (null model)
        (car models)
      (or (assoc model models)
          (cl-destructuring-bind (family nums) (agnostic-llm--model-split model)
            (cond
             ((null family) nil)
             (nums
              (seq-find (lambda (entry)
                          (equal (agnostic-llm--model-split (car entry))
                                 (list family nums)))
                        models))
             (t
              (let (best best-nums)
                (dolist (entry models best)
                  (cl-destructuring-bind (fam enums)
                      (agnostic-llm--model-split (car entry))
                    (when (and (equal fam family) enums
                               (or (null best-nums)
                                   (version-list-< best-nums enums)))
                      (setq best entry best-nums enums))))))))))))

;;; Reasoning effort

(defun agnostic-llm-effort-choices-for-model (model)
  "Return the reasoning-effort levels offered for MODEL.
The `:efforts' list from MODEL's entry in the active provider's catalog,
or nil when MODEL is unknown or its entry declares no efforts.  With nil
the menu's `-e' switch offers no choices and `agnostic-llm--menu-effort'
passes no effort to the CLI."
  (plist-get (cdr (agnostic-llm--model-spec model)) :efforts))

(defcustom agnostic-llm-effort nil
  "Reasoning effort passed through the active provider's option vocabulary.
Nil means use the CLI's own default.  A string like \"low\", \"medium\",
or \"high\" is passed through verbatim.

Normally toggled per-invocation via the `-e' switch in `agnostic-llm-menu'
rather than set directly."
  :type '(choice (const :tag "Default (CLI picks)" nil)
                 (string :tag "Effort level"))
  :group 'agnostic-llm)

(defvar-local agnostic-llm--root-override nil
  "Directory pinned as this buffer's project root, bypassing marker search.
When non-nil, `agnostic-llm--project-root' returns it verbatim instead of
walking up to an ancestor marker.  A session launched in a specific
directory (via `agnostic-llm''s USER-ROOT) sets this on its vterm, so the
session's persistence (`.agnostic-llm/', prompt history) stays anchored to
that directory even when it sits inside a larger project.")

(cl-defun agnostic-llm--project-root (&optional (dir default-directory))
  "Return the project root at or above DIR.
When `agnostic-llm--root-override' is set in the current buffer, return it
verbatim, bypassing the marker search.  Otherwise this is the nearest
ancestor of DIR (inclusive) containing any marker in
`agnostic-llm-project-root-markers'.  Falls back to DIR if none found.

Walks up directory-by-directory, asking \"does any marker exist
here?\" at each level.  This is intentionally different from looping
over markers: looping would let an early marker (e.g. `.git') in a far
ancestor win over a later marker (e.g. `CLAUDE.md') in a much closer
ancestor.

The home directory is never treated as a project root.  Markers there
are global config, not project markers — most importantly `~/.claude',
claude's own config dir, which matches the `.claude' marker.  Without
this guard every markerless directory under HOME would resolve to HOME
and share one `*llm:~*' buffer."
  (if agnostic-llm--root-override
      (file-name-as-directory (expand-file-name agnostic-llm--root-override))
    (let ((home (expand-file-name "~/")))
      (or (when-let* ((root (locate-dominating-file
                            dir
                            (lambda (parent)
                              (and (not (file-equal-p parent home))
                                   (cl-some (lambda (marker)
                                              (file-exists-p
                                               (expand-file-name marker parent)))
                                            agnostic-llm-project-root-markers))))))
            (file-name-as-directory root))
          (file-name-as-directory dir)))))

(defvar-local agnostic-llm--prompt-project-root nil
  "Project root captured when the prompt buffer was opened.")

(defvar-local agnostic-llm--prompt-context-prefix nil
  "Auto-generated file/region context header.
Prepended to the user's prompt at send-time but kept out of the
visible buffer so the composition area stays clean.")

(defun agnostic-llm--current-root ()
  "Get the project root for the current context."
  (or agnostic-llm--prompt-project-root
      (agnostic-llm--project-root)))

;;; Persistence Location

(defcustom agnostic-llm-persistence-strategy 'project
  "Where to store prompt history and annotations.

- `project': per-project, inside the repo at `.agnostic-llm/'.
  Committable across machines; `.gitignore' auto-appended to avoid
  dirtying `git status'.
- `user': per-user, per-machine, at `~/.cache/agnostic-llm/<repo-id>/'.
  Never touches the repo; each checkout starts empty."
  :type '(choice (const :tag "Per-project (.agnostic-llm/ in repo)" project)
                 (const :tag "Per-user (~/.cache/agnostic-llm/)"    user))
  :group 'agnostic-llm)

(defcustom agnostic-llm-user-cache-dir
  (expand-file-name "agnostic-llm"
                    (or (getenv "XDG_CACHE_HOME")
                        (expand-file-name ".cache"
                                          (or (getenv "HOME") "~"))))
  "Root directory for per-user persistence.
Used when `agnostic-llm-persistence-strategy' is `user'."
  :type 'directory
  :group 'agnostic-llm)

(defun agnostic-llm--project-cache-subdir (root)
  "Human-readable directory name for ROOT under `agnostic-llm-user-cache-dir'.
Uses the abbreviated absolute path with `/' replaced by `!'."
  (let ((abbrev (abbreviate-file-name (directory-file-name (expand-file-name root)))))
    (replace-regexp-in-string "/" "!" abbrev)))

(defun agnostic-llm--persistence-dir (root subpath)
  "Return the absolute path of SUBPATH under ROOT.
Honors `agnostic-llm-persistence-strategy'.  SUBPATH is relative (e.g.
\"prompts\" or \"fixme.el\")."
  (pcase agnostic-llm-persistence-strategy
    ('user
     (expand-file-name
      subpath
      (expand-file-name (agnostic-llm--project-cache-subdir root)
                        agnostic-llm-user-cache-dir)))
    (_
     (expand-file-name (concat ".agnostic-llm/" subpath) root))))

;;; LLM vterm buffer management

(defun agnostic-llm--project-label (directory)
  "Return (LABEL . ROOT) for DIRECTORY.
ROOT comes from `agnostic-llm--project-root' — the single source of truth for
project roots in this package — and is never nil; LABEL is its final
path component."
  (let ((root (agnostic-llm--project-root directory)))
    (cons (file-name-nondirectory (directory-file-name root))
          root)))

(defconst agnostic-llm--session-buffer-prefix "*llm:"
  "Prefix of the per-project session vterm buffer name.
`agnostic-llm--session-buffer-name' appends the project label and a
closing `*'.  The prefix is provider-neutral by design.")

(defun agnostic-llm--session-buffer-name (label)
  "Return the session vterm buffer name for project LABEL.
Single source of truth for the `*llm:PROJECT*' buffer name, shared
by `agnostic-llm', `agnostic-llm--bubble-promote', and
`agnostic-llm-toggle-vterm-session'.  The prefix comes from
`agnostic-llm--session-buffer-prefix'."
  (format "%s%s*" agnostic-llm--session-buffer-prefix label))

(defun agnostic-llm--session-name-slug (name)
  "Return NAME as a lowercase dash-separated buffer-name component."
  (let ((slug (string-trim
               (replace-regexp-in-string
                "[^[:alnum:]]+" "-" (downcase (string-trim name)))
               "-+" "-+")))
    (unless (string-empty-p slug) slug)))

(defun agnostic-llm-buffer-p (&optional buffer)
  "Return non-nil if BUFFER (default: current buffer) is an LLM buffer."
  (string-prefix-p agnostic-llm--session-buffer-prefix
                   (buffer-name (or buffer (current-buffer)))))

(defun agnostic-llm--get-buffers ()
  "Return all live LLM buffers."
  (seq-filter #'agnostic-llm-buffer-p (buffer-list)))

(defun agnostic-llm--session-dir (dir)
  "Return the provider's session-store path for DIR.
DIR encodes into one component under `:session-dir' by replacing each `/'
and `.' with `-' (e.g. /home/u/.config → -home-u--config), matching
claude's layout."
  (let ((encoded (replace-regexp-in-string
                  "[/.]" "-"
                  (directory-file-name (expand-file-name dir)))))
    (expand-file-name encoded (agnostic-llm--provider-get :session-dir))))

(defun agnostic-llm--jsonl-last-value (file key)
  "Return the last string value for KEY in JSONL FILE's 64 KiB prefix."
  (let (value)
    (when (file-readable-p file)
      (with-temp-buffer
        (insert-file-contents file nil 0 65536)
        (goto-char (point-min))
        (while (not (eobp))
          (let ((line (buffer-substring-no-properties
                       (line-beginning-position) (line-end-position))))
            (condition-case nil
                (when-let* ((record (json-parse-string line :object-type 'alist))
                            (candidate (alist-get key record))
                            ((stringp candidate)))
                  (setq value candidate))
              (json-error nil)))
          (forward-line 1))))
    value))

(defun agnostic-llm--claude-named-session (root name)
  "Return the session id named NAME under Claude project ROOT, or nil."
  (let ((dir (agnostic-llm--session-dir root))
        match)
    (when (file-directory-p dir)
      (dolist (file (directory-files dir t "\\.jsonl\\'" t))
        (when (equal name (agnostic-llm--jsonl-last-value file 'customTitle))
          (when (or (null match)
                    (time-less-p (file-attribute-modification-time
                                  (file-attributes (cdr match)))
                                 (file-attribute-modification-time
                                  (file-attributes file))))
            (setq match (cons (file-name-base file) file))))))
    (car match)))

(defun agnostic-llm--claude-named-sessions (root)
  "Return Claude's named `(NAME ID FILE)' sessions under project ROOT."
  (let ((dir (agnostic-llm--session-dir root))
        result)
    (when (file-directory-p dir)
      (dolist (file (directory-files dir t "\\.jsonl\\'" t))
        (when-let* ((name (agnostic-llm--jsonl-last-value file 'customTitle)))
          (push (list name (file-name-base file) file) result))))
    (nreverse result)))

(defun agnostic-llm--codex-name-index ()
  "Return Codex's current session-name alist, newest entry winning."
  (let* ((store (expand-file-name (agnostic-llm--provider-get :session-dir)))
         (index (expand-file-name "session_index.jsonl"
                                  (file-name-directory
                                   (directory-file-name store))))
         result)
    (when (file-readable-p index)
      (with-temp-buffer
        (insert-file-contents index)
        (goto-char (point-min))
        (while (not (eobp))
          (let ((line (buffer-substring-no-properties
                       (line-beginning-position) (line-end-position))))
            (condition-case nil
                (let* ((record (json-parse-string line :object-type 'alist))
                       (id (alist-get 'id record))
                       (name (alist-get 'thread_name record)))
                  (when (and (stringp id) (stringp name))
                    (setf (alist-get id result nil nil #'equal) name)))
              (json-error nil)))
          (forward-line 1))))
    result))

(defun agnostic-llm--codex-named-session (root name)
  "Return the Codex session id named NAME under project ROOT, or nil."
  (cadr (cl-find name (agnostic-llm--codex-named-sessions root)
                 :key #'car :test #'equal)))

(defun agnostic-llm--codex-session-id (file)
  "Return the session id in Codex rollout FILE, or nil."
  (when (file-readable-p file)
    (with-temp-buffer
      (insert-file-contents file nil 0 16384)
      (goto-char (point-min))
      (condition-case nil
          (let* ((record (json-parse-string
                          (buffer-substring-no-properties
                           (line-beginning-position) (line-end-position))
                          :object-type 'alist))
                 (payload (alist-get 'payload record)))
            (or (alist-get 'session_id payload) (alist-get 'id payload)))
        (json-error nil)))))

(defun agnostic-llm--codex-named-sessions (root)
  "Return Codex's named `(NAME ID FILE)' sessions under project ROOT."
  (let ((store (expand-file-name (agnostic-llm--provider-get :session-dir)))
        (regexp (agnostic-llm--provider-get :session-file-regexp))
        (names (agnostic-llm--codex-name-index))
        result)
    (when (file-directory-p store)
      (dolist (file (directory-files-recursively store regexp))
        (pcase-let ((`(,cwd . ,originator)
                     (agnostic-llm--codex-session-meta file)))
          (when (and cwd (file-equal-p cwd root)
                     (equal originator "codex-tui"))
            (when-let* ((id (agnostic-llm--codex-session-id file))
                        (name (alist-get id names nil nil #'equal)))
              (push (list name id file) result))))))
    (nreverse result)))

(defun agnostic-llm--named-session (root name)
  "Return the active provider's resume id for NAME under ROOT, or nil."
  (when-let* ((finder (agnostic-llm--provider-get :named-session-function)))
    (funcall finder root name)))

(defun agnostic-llm--named-sessions (root)
  "Return active-provider named sessions under ROOT as `(NAME ID FILE)'."
  (when-let* ((finder (agnostic-llm--provider-get :named-sessions-function)))
    (funcall finder root)))

(defun agnostic-llm--session-introduction (name)
  "Return the first-turn identity message for session NAME."
  (format "This session is named %s. Treat that name as your role in this project."
          name))

(defun agnostic-llm--shell-command-from-argv (argv)
  "Return a safely shell-quoted command string for ARGV."
  (mapconcat #'shell-quote-argument argv " "))

(defun agnostic-llm--codex-session-command
    (root fresh resume-id model effort dangerous &optional name introduction)
  "Build a Codex interactive command for ROOT.
FRESH suppresses continuation; RESUME-ID selects one exact session.
MODEL, EFFORT, and DANGEROUS control the corresponding Codex options.
NAME and INTRODUCTION describe a new named session."
  (ignore introduction)
  (let* ((executable (agnostic-llm--provider-get :executable))
         (base (cond
               (resume-id (list executable "resume" resume-id))
               (fresh (list executable))
               (name (list executable))
               ((agnostic-llm--codex-session-file root t)
                (list executable "resume" "--last"))
               (t (list executable)))))
    (agnostic-llm--shell-command-from-argv
     (append base (agnostic-llm--provider-options-args model effort dangerous)))))

(defun agnostic-llm--session-shell-command
    (root &optional fresh resume-id name introduction)
  "Return the shell command launching the provider in ROOT.
Adds the `:continue-flag' when the current directory has a recorded
session.  Appends the provider vocabulary's `model', `effort', and
`dangerous' arguments when `agnostic-llm-model', `agnostic-llm-effort', and
`agnostic-llm-dangerously-skip-permissions' are respectively set.  With
FRESH, never continue; with RESUME-ID, resume that exact session.  NAME is a
provider-native name for a new session; INTRODUCTION is its first prompt."
  (if-let* ((builder (agnostic-llm--provider-get :session-command-function)))
      (funcall builder root fresh resume-id agnostic-llm-model agnostic-llm-effort
               agnostic-llm-dangerously-skip-permissions name introduction)
    (let* ((exe (agnostic-llm--provider-get :executable))
           (base (cond
                  (resume-id
                   (format "%s %s %s" exe (agnostic-llm--provider-get :resume-flag)
                           (shell-quote-argument resume-id)))
                  ((and name (agnostic-llm--provider-get :session-name-flag))
                   (format "%s %s %s" exe
                           (agnostic-llm--provider-get :session-name-flag)
                           (shell-quote-argument name)))
                  ((and (not fresh) (agnostic-llm--session-file root))
                   (concat exe " " (agnostic-llm--provider-get :continue-flag)))
                  (t exe)))
           (options (agnostic-llm--provider-options-args
                     agnostic-llm-model agnostic-llm-effort
                     agnostic-llm-dangerously-skip-permissions))
           (argv (append options
                         (and name introduction
                              (agnostic-llm--provider-get :session-name-flag)
                              (list introduction)))))
      (if argv
          (concat base " " (agnostic-llm--shell-command-from-argv argv))
        base))))

;;; Show last response in a side buffer
;;
;; Reads the current *llm:* vterm's session JSONL (newest .jsonl in the
;; buffer's project dir, via `agnostic-llm--session-dir') and renders the
;; LLM's most recent assistant turn into a plain-text buffer in another
;; window.  Nothing is written to disk.

(defcustom agnostic-llm-response-render-function #'agnostic-llm--render-response-plain
  "Function that renders an extracted LLM response for display.
Called with one argument, the raw response STRING (already joined from
the assistant turn's text blocks), in a fresh buffer that is current and
empty.  It should insert the display text and may set the major mode.

The default, `agnostic-llm--render-response-plain', inserts the text verbatim in
`fundamental-mode'.  This indirection is the single seam for future
rendering: point it at e.g. an `agnostic-llm--render-response-markdown'
that turns on `gfm-mode'/`markdown-mode' without touching the extraction
or display plumbing."
  :type 'function
  :group 'agnostic-llm)

(defun agnostic-llm--codex-session-meta (file)
  "Return (CWD . ORIGINATOR) from the metadata in Codex rollout FILE."
  (with-temp-buffer
    ;; `session_meta' is first and CWD precedes its potentially very large
    ;; instruction payload, so avoid parsing/loading every rollout in full.
    (insert-file-contents file nil 0 16384)
    (when (re-search-forward
           "\\\"type\\\":\\\"session_meta\\\".*?\\\"cwd\\\":\\\"\\([^\\\"]+\\)\\\".*?\\\"originator\\\":\\\"\\([^\\\"]+\\)\\\""
           nil t)
      (cons (replace-regexp-in-string "\\\\/" "/" (match-string-no-properties 1))
            (match-string-no-properties 2)))))

(defun agnostic-llm--file-newer-p (a b)
  "Return non-nil when file A was modified after file B."
  (time-less-p (file-attribute-modification-time (file-attributes b))
               (file-attribute-modification-time (file-attributes a))))

(defun agnostic-llm--codex-session-file (dir &optional interactive-only)
  "Return the newest Codex rollout belonging to project DIR.
With INTERACTIVE-ONLY, exclude sessions created by `codex exec'."
  (let* ((root (expand-file-name (agnostic-llm--provider-get :session-dir)))
         (wanted (file-name-as-directory (file-truename dir))))
    (when (file-directory-p root)
      (seq-find
       (lambda (file)
         (let* ((meta (agnostic-llm--codex-session-meta file))
                (cwd (car meta))
                (originator (cdr meta)))
           (and cwd
                (or (not interactive-only) (equal originator "codex-tui"))
                (equal wanted (file-name-as-directory (file-truename cwd))))))
       (sort (directory-files-recursively
              root (agnostic-llm--provider-get :session-file-regexp))
             #'agnostic-llm--file-newer-p)))))

(defun agnostic-llm--session-file (dir)
  "Return the newest session transcript file for DIR, or nil if none.
Files under `agnostic-llm--session-dir' matching `:session-file-regexp'
are ranked by mtime, so the session the live CLI is appending wins (names
are random UUIDs, so name order is meaningless)."
  (if-let* ((finder (agnostic-llm--provider-get :session-file-function)))
      (funcall finder dir)
    (let ((sdir (agnostic-llm--session-dir dir)))
      (when (file-directory-p sdir)
        (car (sort (directory-files sdir t (agnostic-llm--provider-get :session-file-regexp) t)
                   #'agnostic-llm--file-newer-p))))))

(defun agnostic-llm--session-records (file)
  "Parse FILE (JSONL) into a list of alists, in file order.
Lines that fail to parse as a JSON object are skipped, so a partially
written trailing line (the CLI still flushing mid-write) can't error."
  (let (records)
    (with-temp-buffer
      (insert-file-contents file)
      (goto-char (point-min))
      (while (not (eobp))
        (let ((line (buffer-substring-no-properties
                     (line-beginning-position) (line-end-position))))
          (unless (string-blank-p line)
            (let ((obj (ignore-errors
                         (json-parse-string line
                                            :object-type 'alist
                                            :array-type 'list
                                            :null-object nil
                                            :false-object nil))))
              (when (and obj (listp obj)) (push obj records)))))
        (forward-line 1)))
    (nreverse records)))

(defun agnostic-llm--genuine-user-prompt-p (record)
  "Return non-nil if RECORD is a genuine human prompt (the turn boundary).
A genuine prompt is a type==\"user\" line whose `message.content' is a
STRING (not an array), and which is NOT a tool result, meta/command
expansion, compact summary, or sidechain.  This string-only test is what
correctly skips the array-content lines that masquerade as user turns:
tool_result entries (content is a `tool_result' array), isMeta skill /
command expansions, and synthetic \"[Request interrupted by user]\"
markers — all of which can otherwise be mistaken for the boundary and
truncate the latest turn."
  (and (equal (alist-get 'type record) "user")
       (stringp (alist-get 'content (alist-get 'message record)))
       (not (assq 'toolUseResult record))
       (not (eq t (alist-get 'isMeta record)))
       (not (eq t (alist-get 'isCompactSummary record)))
       (not (eq t (alist-get 'isSidechain record)))))

(defun agnostic-llm--extract-last-response (records)
  "Return the latest assistant response text from RECORDS, or nil.
The latest turn is every assistant `text' block appearing after the last
genuine human prompt; blocks are joined with blank lines.  `thinking' and
`tool_use' blocks, sidechain assistant lines, and API-error lines are
intentionally dropped — this is the prose reply."
  (let* ((boundary (or (cl-position-if #'agnostic-llm--genuine-user-prompt-p records
                                       :from-end t)
                       -1))
         (tail (nthcdr (1+ boundary) records))
         texts)
    (dolist (rec tail)
      (when (and (equal (alist-get 'type rec) "assistant")
                 (not (eq t (alist-get 'isSidechain rec)))
                 (not (eq t (alist-get 'isApiErrorMessage rec))))
        (let ((content (alist-get 'content (alist-get 'message rec))))
          (when (listp content)
            (dolist (blk content)
              (when (equal (alist-get 'type blk) "text")
                (let ((txt (alist-get 'text blk)))
                  (when (and (stringp txt) (not (string-blank-p txt)))
                    (push txt texts)))))))))
    (when texts
      (string-trim (string-join (nreverse texts) "\n\n")))))

(defun agnostic-llm--codex-extract-last-response (records)
  "Return the latest assistant prose response from Codex RECORDS."
  (catch 'response
    (dolist (record (reverse records))
      (let ((payload (alist-get 'payload record)))
        (when (and (equal (alist-get 'type record) "response_item")
                   (equal (alist-get 'type payload) "message")
                   (equal (alist-get 'role payload) "assistant"))
          (let (texts)
            (dolist (block (alist-get 'content payload))
              (when (equal (alist-get 'type block) "output_text")
                (let ((text (alist-get 'text block)))
                  (when (and (stringp text) (not (string-blank-p text)))
                    (push text texts)))))
            (when texts
              (throw 'response
                     (string-trim (string-join (nreverse texts) "\n\n"))))))))))

(defun agnostic-llm--provider-extract-last-response (records)
  "Extract the latest response from provider session RECORDS."
  (if-let* ((extractor (agnostic-llm--provider-get :extract-response-function)))
      (funcall extractor records)
    (agnostic-llm--extract-last-response records)))

(defun agnostic-llm--render-response-plain (text)
  "Default renderer: insert TEXT verbatim as plain text.
Current buffer is fresh and current; leaves it in `fundamental-mode'."
  (fundamental-mode)
  (insert text))

;;;###autoload
(defun agnostic-llm-show-last-response ()
  "Show the current session's latest response in another window.
Must be invoked from a `*llm:PROJECT*' vterm.  Locates that buffer's
session JSONL (newest .jsonl under its project dir) without writing
anything to disk, extracts the most recent assistant turn, and renders it
via `agnostic-llm-response-render-function' into a reused
`*llm-response:LABEL*' buffer shown in another window, with point at
the top."
  (interactive)
  (unless (agnostic-llm-buffer-p)
    (user-error "Not an LLM buffer"))
  (let* ((dir   default-directory)
         (label (car (agnostic-llm--project-label dir)))
         (file  (agnostic-llm--session-file dir)))
    (unless file
      (user-error "No session found for %s" label))
    (let ((response (agnostic-llm--provider-extract-last-response
                     (agnostic-llm--session-records file))))
      (unless response
        (user-error "No assistant response found in latest turn"))
      (let ((buf (get-buffer-create (format "*llm-response:%s*" label))))
        (with-current-buffer buf
          (let ((inhibit-read-only t))
            (when (bound-and-true-p view-mode) (view-mode -1))
            (erase-buffer)
            (funcall agnostic-llm-response-render-function response)
            (goto-char (point-min))
            (set-buffer-modified-p nil))
          (view-mode 1))            ; q to bury; read-only with cheap nav
        (display-buffer buf '(display-buffer-pop-up-window
                              (inhibit-same-window . t)))))))

;;;###autoload
(defun agnostic-llm (&optional user-root label session-name)
  "Open the LLM CLI in a vterm buffer named *llm:project*.
With non-nil USER-ROOT, target that directory instead of the current
project.  With non-nil LABEL, use it as the buffer-label base instead of
deriving one from the project directory.  SESSION-NAME identifies an
independent named conversation, appends its slug to LABEL, and is presented to
the model as its role on the first turn.
Without prefix: reuse the existing buffer, or create one.
With \\[universal-argument]: new buffer, continue session if possible.
With \\[universal-argument] \\[universal-argument]: new buffer, fresh session."
  (interactive)
  (pcase-let* ((`(,derived . ,root)
                (if user-root
                    (cons (file-name-nondirectory
                           (directory-file-name (expand-file-name user-root)))
                          user-root)
                  (agnostic-llm--project-label default-directory)))
               (role-name (and session-name (string-trim session-name)))
               (role-name (unless (string-empty-p (or role-name ""))
                            role-name))
               (session-name
                (when role-name
                  (or (agnostic-llm--session-name-slug role-name)
                      (user-error "Session name needs an alphanumeric character"))))
               (base-label (or label derived))
               (label (if session-name
                          (format "%s-%s" base-label session-name)
                        base-label))
               (provider-name
                (and session-name
                     (format "%s--%s" base-label session-name)))
               (default-directory (or user-root root default-directory))
               (base (agnostic-llm--session-buffer-name label))
               (prefix (prefix-numeric-value current-prefix-arg))
               (resume-id (and session-name
                               (agnostic-llm--named-session root provider-name)))
               (introduction (and session-name (null resume-id)
                                  (agnostic-llm--session-introduction
                                   session-name)))
               (rename-template (and session-name (null resume-id)
                                     (agnostic-llm--provider-get
                                      :session-rename-command)))
               (startup-inputs
                (and rename-template
                     (list (format rename-template provider-name) introduction)))
               (command (agnostic-llm--session-shell-command
                         root nil resume-id
                         (and session-name (null resume-id) provider-name)
                         introduction)))
    (cond ((= prefix 1)
           (let* ((base-buffer (get-buffer base))
                  (existing
                   (or (and base-buffer
                            (eq (buffer-local-value 'agnostic-llm-provider base-buffer)
                                agnostic-llm-provider)
                            (equal (buffer-local-value 'agnostic-llm-session-name
                                                       base-buffer)
                                   session-name)
                            base-buffer)
                       (seq-find
                        (lambda (buffer)
                          (and (buffer-live-p buffer)
                               (get-buffer-process buffer)
                               (eq (buffer-local-value 'agnostic-llm-provider buffer)
                                   agnostic-llm-provider)
                               (equal (buffer-local-value 'agnostic-llm-session-name
                                                          buffer)
                                      session-name)
                               (file-equal-p
                                (buffer-local-value 'default-directory buffer)
                                default-directory)))
                        (agnostic-llm--get-buffers)))))
             (cond
              ((and existing (buffer-live-p existing)
                    (get-buffer-process existing))
               (pop-to-buffer existing))
              (t
               (when existing (kill-buffer existing))
               (agnostic-llm--open-vterm
                (if base-buffer (generate-new-buffer-name base) base)
                command nil session-name provider-name
                startup-inputs)))))
          ((= prefix 4)
           (agnostic-llm--open-vterm
            (generate-new-buffer-name base) command nil session-name
            provider-name startup-inputs))
          ((>= prefix 16)
           (agnostic-llm--open-vterm
            (generate-new-buffer-name base)
            (agnostic-llm--session-shell-command
             root t nil provider-name introduction)
            nil session-name provider-name startup-inputs)))
    ;; A session launched with an explicit USER-ROOT pins its persistence and
    ;; scope to that directory: `agnostic-llm--project-root' in this vterm now
    ;; returns USER-ROOT instead of walking up to an ancestor project marker.
    (when (and user-root (agnostic-llm-buffer-p))
      (setq-local agnostic-llm--root-override root))))

;;;###autoload
(defun agnostic-llm-vterm-here ()
  "Open or switch to a vterm buffer in the current window.
Without prefix: switch to the last *vterm:LABEL* buffer for the project,
or create one if none exist.
With prefix: always create a new vterm buffer."
  (interactive)
  (pcase-let* ((`(,label . ,_) (agnostic-llm--project-label default-directory))
               (base (format "*vterm:%s*" label)))
    (if current-prefix-arg
        (vterm (generate-new-buffer-name base))
      (let ((vterm-bufs (cl-remove-if-not
                         (lambda (b) (string-prefix-p base (buffer-name b)))
                         (buffer-list))))
        (if vterm-bufs
            (switch-to-buffer (car vterm-bufs))
          (vterm base))))))

;;; Prompt Mode

(defun agnostic-llm--prompt-capf ()
  "Completion-at-point for @file references in the prompt buffer.
Offers project-relative file paths when the point follows `@'."
  (save-excursion
    (let ((end (point)))
      (when (re-search-backward "@\\([^ \t\n]*\\)" (line-beginning-position) t)
        (let* ((at-start (match-beginning 0))
               (start    (1+ at-start))
               (root     (or agnostic-llm--prompt-project-root (agnostic-llm--current-root))))
          (when root
            (list start end
                  (completion-table-dynamic
                   (lambda (_)
                     (when-let* ((proj (project-current nil root)))
                       (mapcar (lambda (f) (file-relative-name f root))
                               (project-files proj)))))
                  :exclusive 'no
                  :annotation-function (lambda (_) " file"))))))))

(define-derived-mode agnostic-llm-prompt-mode text-mode "Agnostic-LLM"
  "Major mode for composing multi-line LLM prompts.
\\<agnostic-llm-prompt-mode-map>\\[agnostic-llm-prompt-send] to send, \\[agnostic-llm-prompt-cancel] to cancel."
  (setq header-line-format " LLM  C-c C-c send | C-c C-k cancel")
  (add-hook 'completion-at-point-functions #'agnostic-llm--prompt-capf nil t))

(define-key agnostic-llm-prompt-mode-map (kbd "C-c C-c") #'agnostic-llm-prompt-send)
(define-key agnostic-llm-prompt-mode-map (kbd "C-c C-k") #'agnostic-llm-prompt-cancel)
(define-key agnostic-llm-prompt-mode-map (kbd "C-c C-m") #'agnostic-llm--bubble-promote)

;;; Interactive Commands

(defun agnostic-llm--ensure-ignored (root)
  "Append `.agnostic-llm/' to ROOT's .gitignore if missing.
No-op unless `agnostic-llm-persistence-strategy' is `project' and ROOT
is a git repo."
  (when (and (eq agnostic-llm-persistence-strategy 'project)
             root
             (file-directory-p (expand-file-name ".git" root)))
    (let* ((gitignore (expand-file-name ".gitignore" root))
           (existing (when (file-readable-p gitignore)
                       (with-temp-buffer
                         (insert-file-contents gitignore)
                         (buffer-string)))))
      (unless (and existing
                   (string-match-p (rx line-start
                                       (? "/")
                                       ".agnostic-llm/"
                                       (? line-end))
                                   existing))
        (with-temp-buffer
          (when existing (insert existing))
          (unless (or (null existing) (string-suffix-p "\n" existing))
            (insert "\n"))
          (insert ".agnostic-llm/\n")
          (write-region (point-min) (point-max) gitignore))))))

(defun agnostic-llm--save-prompt (prompt root)
  "Save PROMPT under the persistence location for ROOT as a timestamped file."
  (let* ((r (or root (agnostic-llm--current-root)))
         (dir (agnostic-llm--persistence-dir r "prompts"))
         (file (expand-file-name
                (format "%s.txt" (format-time-string "%Y%m%d-%H%M%S"))
                dir)))
    (make-directory dir t)
    (agnostic-llm--ensure-ignored r)
    (with-temp-file file (insert prompt))))

(defun agnostic-llm--send-prompt (prompt &optional root)
  "Save PROMPT, open the project's agent session, and send PROMPT to it.
With ROOT, target the session for that project root instead of the
current one."
  (agnostic-llm--save-prompt prompt root)
  (agnostic-llm root)
  (vterm-insert prompt)
  (vterm-send-return))

(defun agnostic-llm--write-context-file (text)
  "Write TEXT to a temporary file and return its path."
  (let ((file (make-temp-file "agnostic-llm-context-" nil ".txt")))
    (with-temp-file file (insert text))
    file))

;;; Bubble (inline-response) mode

(defcustom agnostic-llm-bubble-prompt-prefix ""
  "String prepended to the user's text when sending in bubble mode.
Empty by default — the bubble sends your prompt verbatim through the
provider's one-shot invocation, which works in any environment.

Set to \"/btw \" (trailing space) if you've defined a matching custom
slash command (for the claude provider, at `~/.claude/commands/btw.md' or
`<project>/.claude/commands/btw.md').  Any other string works too —
e.g. \"By the way, briefly: \" as a plain-text framing preamble."
  :type 'string
  :group 'agnostic-llm)

(defface agnostic-llm-bubble-header-face
  '((t :inherit header-line :slant italic))
  "Face for the bubble header line.")

(defface agnostic-llm-bubble-user-face
  '((((background dark))  :foreground "#7aa2f7" :weight bold)
    (((background light)) :foreground "#5c7cfa" :weight bold))
  "Face for the \"▸\" turn marker in front of user messages.")

(defface agnostic-llm-bubble-thinking-face
  '((t :inherit shadow :slant italic))
  "Face for the animated `Thinking…' indicator.")

(defvar-local agnostic-llm--prompt-bubble nil
  "Non-nil when this prompt buffer is in bubble (inline-response) mode.")

(defvar-local agnostic-llm--bubble-process nil
  "Async one-shot provider process for a bubble, if running.")

(defvar-local agnostic-llm--bubble-last-prompt nil
  "The most recent user prompt sent in this bubble.
Used by `agnostic-llm--bubble-promote' to forward it to the main session.")

(defvar-local agnostic-llm--bubble-input-start nil
  "Marker at the start of the user's current input region.
Nil on the very first send (no conversation history yet); a live marker
once the first reply has settled and subsequent turns are being typed.")

(defvar-local agnostic-llm--bubble-session-id nil
  "Provider session id pinning every turn of this bubble.")

(defvar-local agnostic-llm--bubble-provider nil
  "Provider captured when this bubble was created.")

(defvar-local agnostic-llm--bubble-model nil
  "Buffer-local copy of `agnostic-llm-model' captured at bubble creation.
Frozen at bubble open so toggling the menu's `-m' switch mid-conversation
doesn't retroactively change which model the session uses.")

(defvar-local agnostic-llm--bubble-effort nil
  "Reasoning effort captured when this bubble was created.")

(defvar-local agnostic-llm--bubble-dangerous nil
  "Buffer-local copy of `agnostic-llm-dangerously-skip-permissions'.
Captured at bubble creation.  Frozen at bubble open so toggling the
transient mid-conversation doesn't retroactively change the session's
permission posture.")

(defvar-local agnostic-llm--bubble-thinking-overlay nil
  "Overlay showing the animated `...' indicator while the LLM is thinking.")

(defvar-local agnostic-llm--bubble-thinking-timer nil
  "Buffer-local timer animating `agnostic-llm--bubble-thinking-overlay'.")

(defvar-local agnostic-llm--bubble-thinking-tick 0
  "Counter driving the thinking-dots animation.")

(defvar-local agnostic-llm--bubble-json-remainder ""
  "Incomplete JSONL event fragment held between `process-filter' calls.")

(defun agnostic-llm--prepare-bubble-buffer (root)
  "Initialize the current buffer as a bubble rooted at ROOT."
  (agnostic-llm-prompt-mode)
  (erase-buffer)
  (setq-local agnostic-llm--prompt-project-root root)
  (setq-local agnostic-llm--prompt-bubble t)
  (setq-local agnostic-llm--bubble-provider agnostic-llm-provider)
  (setq-local agnostic-llm--bubble-session-id
              (agnostic-llm--bubble-initial-session-id))
  (setq-local agnostic-llm--bubble-dangerous agnostic-llm-dangerously-skip-permissions)
  (setq-local agnostic-llm--bubble-model agnostic-llm-model)
  (setq-local agnostic-llm--bubble-effort agnostic-llm-effort))

(defun agnostic-llm--bubble-thinking-string (tick)
  "Return the animated dots string for TICK (1–3 dots)."
  (propertize (make-string (1+ (mod tick 3)) ?.)
              'face 'agnostic-llm-bubble-thinking-face))

(defun agnostic-llm--bubble-thinking-tick-fn (buf)
  "Tick BUF's thinking animation one frame forward."
  (when (and (buffer-live-p buf)
             (overlayp (buffer-local-value 'agnostic-llm--bubble-thinking-overlay buf)))
    (with-current-buffer buf
      (cl-incf agnostic-llm--bubble-thinking-tick)
      (overlay-put agnostic-llm--bubble-thinking-overlay
                   'after-string
                   (agnostic-llm--bubble-thinking-string agnostic-llm--bubble-thinking-tick)))))

(defun agnostic-llm--bubble-start-thinking (buf)
  "Begin the `thinking' animation in BUF at current `point-max'.
The timer cancels itself if BUF is killed, so a promoted/closed bubble
can never strand a repeating timer on a dead buffer."
  (with-current-buffer buf
    (agnostic-llm--bubble-stop-thinking buf)
    (let* ((pos (point-max))
           (ov  (make-overlay pos pos buf t nil))
           timer)
      (overlay-put ov 'after-string (agnostic-llm--bubble-thinking-string 0))
      (setq-local agnostic-llm--bubble-thinking-overlay ov)
      (setq-local agnostic-llm--bubble-thinking-tick 0)
      (setq timer (run-with-timer
                   0.4 0.4
                   (lambda ()
                     (if (buffer-live-p buf)
                         (agnostic-llm--bubble-thinking-tick-fn buf)
                       (cancel-timer timer)))))
      (setq-local agnostic-llm--bubble-thinking-timer timer))))

(defun agnostic-llm--bubble-stop-thinking (buf)
  "Cancel BUF's thinking animation and remove its indicator."
  (when (buffer-live-p buf)
    (with-current-buffer buf
      (when (timerp agnostic-llm--bubble-thinking-timer)
        (cancel-timer agnostic-llm--bubble-thinking-timer))
      (setq-local agnostic-llm--bubble-thinking-timer nil)
      (when (overlayp agnostic-llm--bubble-thinking-overlay)
        (delete-overlay agnostic-llm--bubble-thinking-overlay))
      (setq-local agnostic-llm--bubble-thinking-overlay nil))))

(defun agnostic-llm--generate-uuid ()
  "Return a v4-style UUID string."
  (format "%04x%04x-%04x-%04x-%04x-%04x%04x%04x"
          (random 65536) (random 65536)
          (random 65536)
          (logior #x4000 (logand (random 65536) #x0fff))
          (logior #x8000 (logand (random 65536) #x3fff))
          (random 65536) (random 65536) (random 65536)))

(defun agnostic-llm--bubble-initial-session-id ()
  "Return the active provider's client-assigned bubble session id.
Providers with a custom bubble builder learn a server-assigned id from
their first response instead."
  (unless (agnostic-llm--provider-get :bubble-command-function)
    (agnostic-llm--generate-uuid)))

(defun agnostic-llm--bubble-command (prompt)
  "Build the provider's argv for PROMPT on this bubble's pinned session.
The `:session-id-flag' carries the same UUID every turn, so the CLI treats
all popup turns as one conversation.  Prepends
`agnostic-llm-bubble-prompt-prefix' to PROMPT; translates the bubble's model,
effort, and dangerous values through the active provider's option vocabulary."
  (let ((text (concat agnostic-llm-bubble-prompt-prefix prompt)))
    (if-let* ((builder (agnostic-llm--provider-get :bubble-command-function)))
        (funcall builder text agnostic-llm--bubble-session-id
                 agnostic-llm--bubble-model agnostic-llm--bubble-effort
                 agnostic-llm--bubble-dangerous)
      (append (list (agnostic-llm--provider-get :executable)
                    (agnostic-llm--provider-get :session-id-flag)
                    agnostic-llm--bubble-session-id)
              (agnostic-llm--provider-options-args
               agnostic-llm--bubble-model agnostic-llm--bubble-effort
               agnostic-llm--bubble-dangerous)
              (list (agnostic-llm--provider-get :print-flag) text)))))

(defun agnostic-llm--codex-bubble-command (prompt session-id model effort dangerous)
  "Build a Codex exec command for PROMPT and optional SESSION-ID.
MODEL, EFFORT, and DANGEROUS control the corresponding Codex options."
  (append (if session-id
              (list (agnostic-llm--provider-get :executable)
                    "exec" "resume" session-id)
            (list (agnostic-llm--provider-get :executable) "exec"))
          (agnostic-llm--provider-options-args model effort dangerous)
          ;; Prompt buffers are supported even when the selected project root
          ;; is not a Git repository; Codex otherwise refuses `exec'.
          (list "--skip-git-repo-check" "--json" prompt)))

(defun agnostic-llm--bubble-clean-chunk (chunk)
  "Strip CR, ANSI CSI sequences, and OSC sequences from CHUNK.
`ansi-color-apply' handles CSI (colors, cursor); OSC (e.g. title
changes like ESC ] ... BEL) and stray CR are removed by hand."
  (let* ((no-cr  (replace-regexp-in-string "\r" "" chunk))
         (no-osc (replace-regexp-in-string "\e\\][^\a]*\\(?:\a\\|\e\\\\\\)" "" no-cr)))
    (ansi-color-apply no-osc)))

(defun agnostic-llm--bubble-filter (proc chunk)
  "Process filter: clean CHUNK and append to PROC's buffer.
On the first chunk, replaces the `thinking' indicator with the
LLM turn marker."
  (when (buffer-live-p (process-buffer proc))
    (with-current-buffer (process-buffer proc)
      (agnostic-llm--bubble-insert-output
       (agnostic-llm--bubble-clean-chunk chunk)))))

(defun agnostic-llm--bubble-insert-output (text)
  "Append provider output TEXT to the current bubble."
  (let ((inhibit-read-only t)
        (first-message (overlayp agnostic-llm--bubble-thinking-overlay))
        (was-at-end (= (point) (point-max))))
    (when first-message
      (agnostic-llm--bubble-stop-thinking (current-buffer))
      (save-excursion
        (goto-char (point-max))
        (insert (propertize "— " 'face 'agnostic-llm-bubble-user-face))))
    (save-excursion
      (goto-char (point-max))
      (insert text))
    (when (or first-message was-at-end)
      (goto-char (point-max)))))

(defun agnostic-llm--bubble-json-filter (proc chunk)
  "Process Codex JSONL CHUNK from PROC, recording session and prose output."
  (when (buffer-live-p (process-buffer proc))
    (with-current-buffer (process-buffer proc)
      (let* ((input (concat agnostic-llm--bubble-json-remainder chunk))
             (complete (string-suffix-p "\n" input))
             (lines (split-string input "\n"))
             (remainder (unless complete (car (last lines)))))
        (setq-local agnostic-llm--bubble-json-remainder (or remainder ""))
        (dolist (line (if remainder (butlast lines) lines))
          (unless (string-blank-p line)
            (let ((event (ignore-errors
                           (json-parse-string line :object-type 'alist
                                              :array-type 'list
                                              :null-object nil :false-object nil))))
              (pcase (alist-get 'type event)
                ("thread.started"
                 (setq-local agnostic-llm--bubble-session-id
                             (alist-get 'thread_id event)))
                ("item.completed"
                 (let ((item (alist-get 'item event)))
                   (when (equal (alist-get 'type item) "agent_message")
                     (agnostic-llm--bubble-insert-output
                      (or (alist-get 'text item) "")))))
                ("error"
                 (agnostic-llm--bubble-insert-output
                  (format "[Codex error: %s]"
                          (or (alist-get 'message event) "unknown error"))))))))))))

(defun agnostic-llm--bubble-sentinel (proc _event)
  "Process sentinel for PROC: append a fresh input prompt and hand control back."
  (when (buffer-live-p (process-buffer proc))
    (with-current-buffer (process-buffer proc)
      (agnostic-llm--bubble-stop-thinking (current-buffer))
      (setq-local agnostic-llm--bubble-process nil)
      (let ((status (process-status proc))
            (inhibit-read-only t))
        (pcase status
          ('exit
           (goto-char (point-max))
           (insert "\n\n" (propertize "— " 'face 'agnostic-llm-bubble-user-face))
           (setq-local agnostic-llm--bubble-input-start (copy-marker (point) nil))
           (setq header-line-format
                 (propertize
                  " LLM  C-c C-c send · C-c C-k close · C-c C-m →llm"
                  'face 'agnostic-llm-bubble-header-face)))
          ('signal
           (setq header-line-format
                 (propertize " LLM  (cancelled — C-c C-k close)"
                             'face 'agnostic-llm-bubble-header-face))))))))

(defun agnostic-llm--bubble-promote ()
  "Close the bubble and open a `*llm:PROJECT*' vterm on the same session.
The new vterm continues the session the popup has been driving.

Popup turns run with `:session-id-flag' <UUID>, pinning the conversation
to one session.  Promote spawns a fresh interactive CLI with `:resume-flag'
<UUID>, loading all prior turns."
  (interactive)
  (unless agnostic-llm--bubble-last-prompt
    (user-error "Nothing to promote yet — send a turn first"))
  (unless agnostic-llm--bubble-session-id
    (user-error "No session id recorded for this bubble"))
  (when (process-live-p agnostic-llm--bubble-process)
    (user-error "The LLM is still responding — wait, or C-c C-k to cancel first"))
  (let* ((root      agnostic-llm--prompt-project-root)
         (dir       (or root default-directory))
         (label     (car (agnostic-llm--project-label dir)))
         (base      (agnostic-llm--session-buffer-name label))
         (name      (generate-new-buffer-name base))
         (sid       agnostic-llm--bubble-session-id)
         (provider  agnostic-llm--bubble-provider)
         (dangerous agnostic-llm--bubble-dangerous)
         (model     agnostic-llm--bubble-model)
         (effort    agnostic-llm--bubble-effort)
         (bubble    (current-buffer)))
    (kill-buffer bubble)
    (let ((default-directory dir)
          (agnostic-llm-provider provider)
          (agnostic-llm-model model)
          (agnostic-llm-effort effort)
          (agnostic-llm-dangerously-skip-permissions dangerous))
      (agnostic-llm--open-vterm
       name
       (agnostic-llm--session-shell-command root nil sid)))))

;;;###autoload
(defun agnostic-llm-prompt-bubble ()
  "Open a bubble: throwaway prompt that streams the reply inline.
Thin wrapper around `agnostic-llm-prompt' with the prefix argument
preset, so it is directly bindable and transient-invokable without
`universal-argument'.

The bubble runs the provider's one-shot invocation, which is
non-interactive: any tool that would normally ask you something (permission
prompts, AskUserQuestion) is auto-failed by the CLI before reaching us.  If
a turn needs that kind of interaction, promote with
\\<agnostic-llm-prompt-mode-map>\\[agnostic-llm--bubble-promote] to a `*llm:PROJECT*' vterm that resumes the same session."
  (interactive)
  (let ((current-prefix-arg '(4)))
    (call-interactively #'agnostic-llm-prompt)))

(defun agnostic-llm-prompt-bubble-send ()
  "Spawn a new bubble turn (first send or post-response follow-up).
Refuses while a turn is already running."
  (if (process-live-p agnostic-llm--bubble-process)
      (user-error "The LLM is still responding — wait, or C-c C-k to cancel")
    (agnostic-llm--bubble-spawn-turn)))

(defun agnostic-llm--bubble-spawn-turn (&optional explicit-prompt)
  "Start a new LLM turn (first send or follow-up after completion).
With EXPLICIT-PROMPT, use it as the prompt instead of reading the
buffer's input region, and skip echoing the user turn into the buffer
so only the response is rendered."
  (let* ((has-history (markerp agnostic-llm--bubble-input-start))
         (prompt (or explicit-prompt
                     (string-trim
                      (if has-history
                          (buffer-substring-no-properties
                           agnostic-llm--bubble-input-start (point-max))
                        (buffer-string)))))
         (root   agnostic-llm--prompt-project-root)
         (default-directory (or root default-directory)))
    (when (string-empty-p prompt) (user-error "Empty prompt"))
    (setq-local agnostic-llm--bubble-last-prompt prompt)
    (let ((inhibit-read-only t)
          (dash (propertize "— " 'face 'agnostic-llm-bubble-user-face)))
      (cond
       (explicit-prompt
        (erase-buffer))
       (has-history
        (delete-region agnostic-llm--bubble-input-start (point-max))
        (goto-char (point-max))
        (insert prompt "\n\n"))
       (t
        (erase-buffer)
        (insert dash prompt "\n\n")))
      (setq-local agnostic-llm--bubble-input-start nil)
      (agnostic-llm--bubble-start-thinking (current-buffer))
      (setq header-line-format
            (propertize " LLM  (running — C-c C-k cancel)"
                        'face 'agnostic-llm-bubble-header-face)))
    (setq-local agnostic-llm--bubble-json-remainder "")
    (let* ((agnostic-llm-provider agnostic-llm--bubble-provider)
           (json-events (agnostic-llm--provider-get :bubble-json-events))
           (args (agnostic-llm--shell-argv
                  (mapconcat #'shell-quote-argument
                             (agnostic-llm--bubble-command prompt) " ")))
           (process-environment
            (append '("NO_COLOR=1" "CLICOLOR=0" "TERM=dumb")
                    process-environment))
           (proc (apply #'start-process "agnostic-llm-bubble" (current-buffer) args)))
      (setq-local agnostic-llm--bubble-process proc)
      (set-process-filter proc (if json-events
                                   #'agnostic-llm--bubble-json-filter
                                 #'agnostic-llm--bubble-filter))
      (set-process-sentinel proc #'agnostic-llm--bubble-sentinel))))

;;;###autoload
(defun agnostic-llm-prompt-send ()
  "Send the contents of the prompt buffer to the LLM.
In bubble mode: run the provider's one-shot invocation as a subprocess
and stream the reply into the same bubble.  Otherwise: hand off to the
project's session vterm (queues if busy)."
  (interactive)
  (if agnostic-llm--prompt-bubble
      (agnostic-llm-prompt-bubble-send)
    (let* ((prompt (string-trim (buffer-string)))
           (ctx    agnostic-llm--prompt-context-prefix)
           (root   agnostic-llm--prompt-project-root)
           (buf    (current-buffer))
           (full   (if ctx (concat ctx prompt) prompt)))
      (when (string-empty-p prompt) (user-error "Empty prompt"))
      (kill-buffer buf)
      (agnostic-llm--send-prompt full root))))

(defun agnostic-llm-prompt-cancel ()
  "Cancel the prompt or response.
If a bubble subprocess is running, kill it and keep the bubble open.
Otherwise close the bubble and kill its buffer."
  (interactive)
  (cond
   ((and agnostic-llm--prompt-bubble (process-live-p agnostic-llm--bubble-process))
    (kill-process agnostic-llm--bubble-process)
    (setq-local agnostic-llm--bubble-process nil)
    (agnostic-llm--bubble-stop-thinking (current-buffer))
    (let ((inhibit-read-only t))
      (goto-char (point-max))
      (insert "\n\n[cancelled]\n"))
    (setq header-line-format
          (propertize " LLM bubble  (cancelled — C-c C-k close)"
                      'face 'agnostic-llm-bubble-header-face)))
   (t
    (let ((buf (current-buffer)))
      (kill-buffer buf)
      (message "Prompt cancelled")))))

;;;###autoload
(defun agnostic-llm-prompt (&optional arg)
  "Open a multi-line prompt buffer for the LLM.
Pre-populates context based on the current state:
- Active region: inserts a file/region context prefix
- Otherwise: inserts a file+line context prefix

With \\[universal-argument] ARG: bubble mode.  Opens a fresh throwaway
bubble with no file-context prefix; on send, runs the provider's one-shot
invocation as a subprocess and streams the reply into the same bubble.
Nothing is saved to prompt history and the main session vterm is
untouched."
  (interactive "P")
  (let* ((bubble (consp arg))
         (root (agnostic-llm--project-root default-directory))
         (file-name (buffer-file-name))
         (prefix (unless bubble
                   (cond
                    ((use-region-p)
                     (let* ((start (region-beginning))
                            (end (region-end))
                            (context (buffer-substring-no-properties start end))
                            (file (if file-name
                                      file-name
                                    (agnostic-llm--write-context-file context))))
                       (deactivate-mark)
                       (if file-name
                           (format "Read file %s lines %d-%d\n\n"
                                   file (line-number-at-pos start) (line-number-at-pos end))
                         (format "Context: %s\n\n" file))))
                    (file-name (format "%s:%d\n\n" file-name (line-number-at-pos (point)))))))
         (buf (if bubble
                  (generate-new-buffer "*agnostic-llm-bubble*")
                (get-buffer-create "*agnostic-llm-prompt*"))))
    (with-current-buffer buf
      (if bubble
          (agnostic-llm--prepare-bubble-buffer root)
        (agnostic-llm-prompt-mode)
        (erase-buffer)
        (setq-local agnostic-llm--prompt-project-root root)
        (setq-local agnostic-llm--prompt-bubble nil))
      (setq-local agnostic-llm--prompt-context-prefix prefix)
      (when bubble
        (goto-char (point-max))
        (insert (propertize "— " 'face 'agnostic-llm-bubble-user-face))
        (setq-local agnostic-llm--bubble-input-start (copy-marker (point) nil))
        (setq header-line-format
              (propertize
               " LLM  C-c C-c send · C-c C-k close · C-c C-m →llm"
               'face 'agnostic-llm-bubble-header-face))))
    (pop-to-buffer buf)))

;;; Prompt History

(defun agnostic-llm--prompt-history-files (root)
  "Return ROOT's saved prompt files, newest first."
  (let ((dir (agnostic-llm--persistence-dir root "prompts")))
    (when (file-directory-p dir)
      (sort (directory-files dir t "\\.txt\\'") #'string>))))

(defun agnostic-llm--prompt-preview (file)
  "Return a one-line preview string for FILE."
  (with-temp-buffer
    (insert-file-contents file nil 0 200)
    (replace-regexp-in-string "[\n\t]+" " " (buffer-string))))

(defun agnostic-llm--open-prompt-in-bubble (text root)
  "Show TEXT in the prompt bubble, tagged for ROOT."
  (let ((buf (get-buffer-create "*agnostic-llm-prompt*")))
    (with-current-buffer buf
      (agnostic-llm-prompt-mode)
      (erase-buffer)
      (insert text)
      (setq-local agnostic-llm--prompt-project-root root))
    (pop-to-buffer buf)))

;;;###autoload
(defun agnostic-llm-prompt-history ()
  "Browse this project's saved prompt files.
Picks a prompt via `completing-read' and opens it in the bubble
for editing and re-sending."
  (interactive)
  (let* ((root  (agnostic-llm--current-root))
         (files (agnostic-llm--prompt-history-files root)))
    (unless files (user-error "No saved prompts for this project"))
    (let* ((cands (mapcar (lambda (f)
                            (cons (format "%s  %s"
                                          (file-name-base f)
                                          (truncate-string-to-width
                                           (agnostic-llm--prompt-preview f)
                                           80 nil nil "…"))
                                  f))
                          files))
           (choice (completing-read "Prompt: " (mapcar #'car cands) nil t))
           (file   (cdr (assoc choice cands)))
           (text   (with-temp-buffer
                     (insert-file-contents file)
                     (buffer-string))))
      (agnostic-llm--open-prompt-in-bubble text root))))

;;;###autoload
(defun agnostic-llm-prompt-resume ()
  "Re-open the most recent saved prompt for this project in the bubble."
  (interactive)
  (let* ((root  (agnostic-llm--current-root))
         (files (agnostic-llm--prompt-history-files root)))
    (unless files (user-error "No saved prompts for this project"))
    (let ((text (with-temp-buffer
                  (insert-file-contents (car files))
                  (buffer-string))))
      (agnostic-llm--open-prompt-in-bubble text root))))

;;; Change Highlighting on Revert

(defface agnostic-llm-change-highlight-face
  '((((background dark))  :background "#1a3a1a" :extend t)
    (((background light)) :background "#d4f4d4" :extend t))
  "Face applied to lines added or changed in the last auto-revert.")

(defvar-local agnostic-llm--pre-revert-contents nil
  "Buffer text captured just before `auto-revert-mode' reverts it.")

(defvar-local agnostic-llm--change-highlight-timer nil
  "Buffer-local idle timer that removes `agnostic-llm-change-highlight' overlays.")

(defun agnostic-llm-change-highlight-clear (&optional buf)
  "Remove all change-highlight overlays from BUF (default: current buffer).
Also cancels the auto-clear timer if one is pending."
  (interactive)
  (with-current-buffer (or buf (current-buffer))
    (when (timerp agnostic-llm--change-highlight-timer)
      (cancel-timer agnostic-llm--change-highlight-timer)
      (setq agnostic-llm--change-highlight-timer nil))
    (remove-overlays (point-min) (point-max) 'category 'agnostic-llm-change-highlight)))

(defun agnostic-llm--before-revert-save ()
  "Hook: capture buffer text before `auto-revert-mode' reverts it."
  (when (buffer-file-name)
    (setq agnostic-llm--pre-revert-contents
          (buffer-substring-no-properties (point-min) (point-max)))))

(defun agnostic-llm--after-revert-highlight ()
  "Hook: highlight lines in the reverted buffer that differ from the snapshot."
  (when-let* ((old agnostic-llm--pre-revert-contents))
    (setq agnostic-llm--pre-revert-contents nil)
    (let* ((new   (buffer-substring-no-properties (point-min) (point-max)))
           (lines (agnostic-llm--diff-added-lines old new))
           (buf   (current-buffer)))
      (agnostic-llm-change-highlight-clear buf)
      (save-excursion
        (dolist (lnum lines)
          (goto-char (point-min))
          (forward-line (1- lnum))
          (let ((ov (make-overlay (line-beginning-position)
                                  (min (point-max) (1+ (line-end-position))))))
            (overlay-put ov 'face     'agnostic-llm-change-highlight-face)
            (overlay-put ov 'category 'agnostic-llm-change-highlight)
            (overlay-put ov 'priority 10))))
      (setq agnostic-llm--change-highlight-timer
            (run-with-timer 60 nil #'agnostic-llm-change-highlight-clear buf)))))

(defun agnostic-llm--diff-added-lines (old new)
  "Return a sorted list of 1-based line numbers added/changed in NEW vs OLD.
Returns nil immediately when OLD equals NEW (frequent auto-revert case
where the timer fires but nothing actually changed on disk)."
  (unless (string= old new)
    (let ((old-file (make-temp-file "agnostic-llm-diff-a"))
          (new-file (make-temp-file "agnostic-llm-diff-b"))
          lines)
      (unwind-protect
          (progn
            (with-temp-file old-file (insert old))
            (with-temp-file new-file (insert new))
            (with-temp-buffer
              (call-process "diff" nil t nil
                            "--new-line-format=%dn\n"
                            "--old-line-format="
                            "--unchanged-line-format="
                            old-file new-file)
              (goto-char (point-min))
              (while (re-search-forward "^\\([0-9]+\\)$" nil t)
                (push (string-to-number (match-string 1)) lines))))
        (ignore-errors (delete-file old-file))
        (ignore-errors (delete-file new-file)))
      (nreverse lines))))

(add-hook 'before-revert-hook #'agnostic-llm--before-revert-save)
(add-hook 'after-revert-hook  #'agnostic-llm--after-revert-highlight)

;;;###autoload
(defun agnostic-llm-switch-buffer ()
  "Switch to another LLM buffer."
  (interactive)
  (let ((bufs (agnostic-llm--get-buffers)))
    (unless bufs
      (user-error "No LLM buffers"))
    (let ((entries (cl-loop for buffer in bufs
                            collect (cons (buffer-name buffer) buffer))))
      (let* ((choice (completing-read "LLM buffer: "
                                      (mapcar #'car entries)
                                      nil t))
             (buf (cdr (assoc choice entries))))
        (pop-to-buffer buf)))))

(defun agnostic-llm--cycle-buffer (direction)
  "Switch current window to the next/previous LLM buffer.
DIRECTION is +1 (forward) or -1 (backward)."
  (let ((bufs (sort (agnostic-llm--get-buffers)
                    (lambda (a b)
                      (string< (buffer-name a) (buffer-name b))))))
    (unless bufs (user-error "No LLM buffers"))
    (let* ((pos (cl-position (current-buffer) bufs))
           (next (if pos
                     (nth (mod (+ pos direction) (length bufs)) bufs)
                   (car bufs))))
      (switch-to-buffer next))))

;;;###autoload
(defun agnostic-llm-next-buffer ()
  "Switch current window to the next LLM buffer."
  (interactive)
  (agnostic-llm--cycle-buffer +1))

;;;###autoload
(defun agnostic-llm-previous-buffer ()
  "Switch current window to the previous LLM buffer."
  (interactive)
  (agnostic-llm--cycle-buffer -1))

;;; FIXME/TODO Annotation System

(defvar agnostic-llm--annotations (make-hash-table :test 'equal)
  "Hash table mapping (ROOT . KIND) to list of annotation entries.
KIND is a string like \"FIXME\" or \"TODO\".
Each entry is a plist (:file :line :text :time).")

(defun agnostic-llm--annotation-file (root kind)
  "Return the persistence file path for KIND annotations in ROOT.
Honors `agnostic-llm-persistence-strategy'."
  (agnostic-llm--persistence-dir root (format "%s.el" (downcase kind))))

(defun agnostic-llm--annotation-key (root kind)
  "Return the hash key for ROOT and KIND."
  (cons root kind))

(defun agnostic-llm--annotation-load (root kind)
  "Load annotations of KIND for ROOT from disk."
  (let ((file (agnostic-llm--annotation-file root kind)))
    (puthash (agnostic-llm--annotation-key root kind)
             (when (file-readable-p file)
               (with-temp-buffer
                 (insert-file-contents file)
                 (read (current-buffer))))
             agnostic-llm--annotations)))

(defun agnostic-llm--annotation-save (root kind)
  "Save annotations of KIND for ROOT to disk."
  (let ((file (agnostic-llm--annotation-file root kind))
        (entries (gethash (agnostic-llm--annotation-key root kind) agnostic-llm--annotations)))
    (make-directory (file-name-directory file) t)
    (agnostic-llm--ensure-ignored root)
    (with-temp-file file
      (pp entries (current-buffer)))))

(defun agnostic-llm--annotation-alive-p (entry kind)
  "Return non-nil if ENTRY's KIND comment still exists in the file.
The needle matches the `KIND(agnostic-llm): ' prefix produced by
`agnostic-llm--annotation-comment', not a bare `KIND: '."
  (let ((file (plist-get entry :file))
        (text (plist-get entry :text)))
    (and (file-readable-p file)
         (with-temp-buffer
           (insert-file-contents file)
           (let ((needle (concat kind "(agnostic-llm): " (car (split-string text "\n")))))
             (search-forward needle nil t))))))

(defun agnostic-llm--annotation-entries (root kind)
  "Return the list of live KIND annotations for ROOT.
Loads from disk if needed, then prunes entries whose comment
has been removed from the source file."
  (let ((key (agnostic-llm--annotation-key root kind)))
    (unless (gethash key agnostic-llm--annotations)
      (agnostic-llm--annotation-load root kind))
    (let* ((entries (gethash key agnostic-llm--annotations))
           (live (cl-remove-if-not (lambda (e) (agnostic-llm--annotation-alive-p e kind)) entries)))
      (unless (= (length entries) (length live))
        (puthash key live agnostic-llm--annotations)
        (agnostic-llm--annotation-save root kind))
      live)))

(defun agnostic-llm--annotation-comment (kind text)
  "Return a KIND comment for TEXT using the current mode's comment syntax."
  (let ((cs (string-trim-right (or comment-start "# ")))
        (ce (let ((e (or comment-end ""))) (if (string-empty-p e) "" (concat " " e)))))
    (mapconcat (lambda (line)
                 (concat cs " " kind "(agnostic-llm): " line ce))
               (split-string text "\n")
               "\n")))

(defvar-local agnostic-llm--annotation-kind nil
  "The annotation kind (\"FIXME\" or \"TODO\") for the current prompt buffer.")
(defvar-local agnostic-llm--annotation-source-buf nil)
(defvar-local agnostic-llm--annotation-source-file nil)
(defvar-local agnostic-llm--annotation-source-line nil)

(defun agnostic-llm--annotation-send ()
  "Insert the annotation comment at the source location and save."
  (interactive)
  (let ((text (string-trim (buffer-string)))
        (kind agnostic-llm--annotation-kind)
        (root agnostic-llm--prompt-project-root)
        (source-buf agnostic-llm--annotation-source-buf)
        (source-file agnostic-llm--annotation-source-file)
        (source-line agnostic-llm--annotation-source-line))
    (when (string-empty-p text)
      (user-error "Empty %s text" kind))
    (kill-buffer (current-buffer))
    (when (buffer-live-p source-buf)
      (with-current-buffer source-buf
        (save-excursion
          (goto-char (point-min))
          (forward-line (1- source-line))
          (beginning-of-line)
          (open-line 1)
          (insert (agnostic-llm--annotation-comment kind text))
          (indent-region (line-beginning-position) (line-end-position)))))
    (let* ((key (agnostic-llm--annotation-key root kind))
           (entries (agnostic-llm--annotation-entries root kind)))
      (push (list :file source-file :line source-line
                  :text text :time (format-time-string "%Y-%m-%d %H:%M"))
            entries)
      (puthash key entries agnostic-llm--annotations))
    (agnostic-llm--annotation-save root kind)
    (message "%s added at %s:%d" kind source-file source-line)))

(defun agnostic-llm--add-annotation (kind)
  "Open a prompt buffer to compose a KIND annotation."
  (let* ((root (agnostic-llm--current-root))
         (source-buf (current-buffer))
         (source-file (or (buffer-file-name) (buffer-name)))
         (source-line (line-number-at-pos (point)))
         (buf (get-buffer-create (format "*agnostic-llm-%s*" (downcase kind)))))
    (with-current-buffer buf
      (agnostic-llm-prompt-mode)
      (erase-buffer)
      (setq-local agnostic-llm--prompt-project-root root)
      (setq-local agnostic-llm--annotation-kind kind)
      (setq-local agnostic-llm--annotation-source-buf source-buf)
      (setq-local agnostic-llm--annotation-source-file source-file)
      (setq-local agnostic-llm--annotation-source-line source-line)
      (setq header-line-format
            (format " %s  C-c C-c insert | C-c C-k cancel" kind))
      (use-local-map (let ((map (make-sparse-keymap)))
                        (set-keymap-parent map text-mode-map)
                        (define-key map (kbd "C-c C-c") #'agnostic-llm--annotation-send)
                        (define-key map (kbd "C-c C-k") #'agnostic-llm-prompt-cancel)
                        map)))
    (pop-to-buffer buf)))

(defvar-local agnostic-llm--annotation-list-kind nil
  "The annotation kind being displayed in the current list buffer.")

(defvar-local agnostic-llm--annotation-list-root nil
  "The project root whose annotations are displayed in the current list buffer.")

(defun agnostic-llm--annotation-list-refresh ()
  "Rebuild `tabulated-list-entries' from live annotations."
  (let ((entries (agnostic-llm--annotation-entries agnostic-llm--annotation-list-root
                                          agnostic-llm--annotation-list-kind)))
    (setq tabulated-list-entries
          (mapcar (lambda (e)
                    (list e
                          (vector (file-relative-name (plist-get e :file)
                                                      agnostic-llm--annotation-list-root)
                                  (number-to-string (plist-get e :line))
                                  (or (plist-get e :time) "")
                                  (truncate-string-to-width
                                   (replace-regexp-in-string "\n" " ⏎ "
                                                             (plist-get e :text))
                                   80 nil nil "…"))))
                  entries))
    (tabulated-list-print t)))

(defun agnostic-llm-annotation-list-visit ()
  "Jump to the source location of the annotation at point."
  (interactive)
  (let* ((entry (tabulated-list-get-id))
         (file  (plist-get entry :file))
         (line  (plist-get entry :line)))
    (unless entry (user-error "No annotation at point"))
    (unless (file-exists-p file) (user-error "File gone: %s" file))
    (find-file-other-window file)
    (goto-char (point-min))
    (forward-line (1- line))))

(defun agnostic-llm-annotation-list-delete ()
  "Delete the annotation at point from persistence.
Source-file comment is left untouched — remove it manually if desired."
  (interactive)
  (let* ((entry (tabulated-list-get-id))
         (kind  agnostic-llm--annotation-list-kind)
         (root  agnostic-llm--annotation-list-root)
         (key   (agnostic-llm--annotation-key root kind)))
    (unless entry (user-error "No annotation at point"))
    (puthash key
             (cl-remove entry (gethash key agnostic-llm--annotations) :test #'equal)
             agnostic-llm--annotations)
    (agnostic-llm--annotation-save root kind)
    (agnostic-llm--annotation-list-refresh)))

(defvar agnostic-llm-annotation-list-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "RET") #'agnostic-llm-annotation-list-visit)
    (define-key map (kbd "o")   #'agnostic-llm-annotation-list-visit)
    (define-key map (kbd "d")   #'agnostic-llm-annotation-list-delete)
    (define-key map (kbd "x")   #'agnostic-llm-annotation-list-delete)
    (define-key map (kbd "g")   #'agnostic-llm--annotation-list-refresh)
    map)
  "Keymap for `agnostic-llm-annotation-list-mode'.")

(define-derived-mode agnostic-llm-annotation-list-mode tabulated-list-mode "Agnostic-LLM List"
  "Tabulated view of project annotations.
\\<agnostic-llm-annotation-list-mode-map>\
\\[agnostic-llm-annotation-list-visit] visit, \\[agnostic-llm-annotation-list-delete] delete, \
\\[agnostic-llm--annotation-list-refresh] refresh."
  (setq tabulated-list-format
        [("File" 40 t) ("Line" 6 t) ("Time" 17 t) ("Text" 0 nil)])
  (setq tabulated-list-sort-key '("File"))
  (tabulated-list-init-header))

(defun agnostic-llm--list-annotations (kind)
  "Open a tabulated list of KIND annotations for the current project."
  (let* ((root (agnostic-llm--current-root))
         (entries (agnostic-llm--annotation-entries root kind)))
    (unless entries
      (user-error "No %ss in this project" kind))
    (let ((buf (get-buffer-create (format "*agnostic-llm-%ss: %s*"
                                          (downcase kind)
                                          (file-name-nondirectory
                                           (directory-file-name root))))))
      (with-current-buffer buf
        (agnostic-llm-annotation-list-mode)
        (setq agnostic-llm--annotation-list-kind kind
              agnostic-llm--annotation-list-root root)
        (agnostic-llm--annotation-list-refresh))
      (pop-to-buffer buf))))

(defun agnostic-llm--send-annotations (kind)
  "Send all KIND annotations for the current project to the LLM."
  (let* ((root (agnostic-llm--current-root))
         (entries (agnostic-llm--annotation-entries root kind)))
    (unless entries
      (user-error "No %ss in this project" kind))
    (let ((prompt (mapconcat
                   (lambda (e)
                     (format "%s at %s:%d — %s"
                             kind
                             (plist-get e :file)
                             (plist-get e :line)
                             (plist-get e :text)))
                   entries "\n")))
      (agnostic-llm--send-prompt
       (format "Resolve the following %ss in this project:\n\n%s" kind prompt)))))

;; The per-kind annotation commands (add/list/send for FIXME and TODO) are
;; generated from the generic helpers, so the three operations stay in sync
;; across kinds instead of being six hand-maintained wrappers.
(defmacro agnostic-llm--define-annotation-commands (kind)
  "Define `agnostic-llm-add/list/send' commands for annotation KIND (a string)."
  (let ((lc (downcase kind)))
    `(progn
       (defun ,(intern (format "agnostic-llm-add-%s" lc)) ()
         ,(format "Add a %s annotation at point." kind)
         (interactive)
         (agnostic-llm--add-annotation ,kind))
       (defun ,(intern (format "agnostic-llm-list-%ss" lc)) ()
         ,(format "List all %ss for the current project." kind)
         (interactive)
         (agnostic-llm--list-annotations ,kind))
       (defun ,(intern (format "agnostic-llm-send-%ss" lc)) ()
         ,(format "Send all %ss to the LLM." kind)
         (interactive)
         (agnostic-llm--send-annotations ,kind)))))

(agnostic-llm--define-annotation-commands "FIXME")
(agnostic-llm--define-annotation-commands "TODO")

;;;###autoload
(defun agnostic-llm-grep-annotations ()
  "Grep all TODO/FIXME/HACK/XXX comments in the current project."
  (interactive)
  (let ((root (agnostic-llm--current-root)))
    (grep-find (format "grep -rnE '(TODO|FIXME|HACK|XXX):?' %s --include='*.*' -I"
                       (shell-quote-argument (directory-file-name root))))))

;;; Transient Menu

(eval-and-compile
  (defconst agnostic-llm--transient-option-vocabulary
    '((btw . "--btw")
      (cwd . "-c")
      (dangerous . "--dangerously-skip-permissions")
      (model . "--model=")
      (effort . "--effort=")
      (session-name . "--session-name="))
    "Provider-neutral arguments exported by `agnostic-llm-menu'.
These are UI vocabulary.  Provider command lines are derived independently
from each provider's `:option-vocabulary'."))

(defun agnostic-llm--transient-option (option)
  "Return the provider-neutral transient argument for semantic OPTION."
  (or (alist-get option agnostic-llm--transient-option-vocabulary)
      (error "Unknown transient option: %s" option)))

(defun agnostic-llm--menu-switch-p (option)
  "Return non-nil when transient switch OPTION is active."
  (member (agnostic-llm--transient-option option)
          (transient-args 'agnostic-llm-menu)))

(defun agnostic-llm--menu-option-value-from (option arguments)
  "Return transient OPTION's value in ARGUMENTS, or nil for default."
  (let* ((prefix (agnostic-llm--transient-option option))
         (value (cl-some (lambda (argument)
                           (and (stringp argument)
                                (string-prefix-p prefix argument)
                                (substring argument (length prefix))))
                         arguments)))
    (unless (equal value "default") value)))

(defun agnostic-llm--menu-option-value (option)
  "Return transient OPTION's submitted value, or nil for default."
  (agnostic-llm--menu-option-value-from
   option (transient-args 'agnostic-llm-menu)))

(defun agnostic-llm--menu-dangerous-p ()
  "Return non-nil if the menu's `-d' switch is active for this invocation."
  (agnostic-llm--menu-switch-p 'dangerous))

(defun agnostic-llm--menu-use-cwd-p ()
  "Return non-nil if the menu's `-c' switch is active."
  (agnostic-llm--menu-switch-p 'cwd))

(defun agnostic-llm--menu-current-model ()
  "Return the model in effect for `agnostic-llm-menu'.
That is the `-m' override, else `agnostic-llm-model'.  Guarded so it is
safe to call while the transient is live (e.g. from an infix `:choices'
function)."
  (or (ignore-errors (agnostic-llm--menu-option-value 'model))
      agnostic-llm-model))

(defun agnostic-llm--menu-effort ()
  "The effort selected in `agnostic-llm-menu', filtered by the current model.
Returns nil when no effort is set, or when the set effort is absent from
the current model's `:efforts' in the provider catalog (e.g. \"ultracode\"
when the selected model does not offer it), so an unsupported level is
never passed to the CLI."
  (let ((effort (agnostic-llm--menu-option-value 'effort)))
    (and effort
         (member effort (agnostic-llm-effort-choices-for-model (agnostic-llm--menu-current-model)))
         effort)))

;;;###autoload
(defun agnostic-llm-set-default-model (model)
  "Set MODEL as the default for new sessions and persist it.
Empty input clears the default (the CLI will pick).  The value is saved
via `customize-save-variable', so it survives Emacs restarts.

Per-invocation overrides via the menu's `-m' switch are unaffected."
  (interactive
   (list (completing-read
          (format "Default model (current: %s, empty = CLI picks): "
                  (or agnostic-llm-model "none"))
          (agnostic-llm-model-choices) nil nil nil nil agnostic-llm-model)))
  (let ((value (if (or (string-empty-p (or model ""))
                       (equal model "default"))
                   nil model)))
    (customize-save-variable 'agnostic-llm-model value)
    (message "Default model %s"
             (if value (format "set to %s (saved)" value)
               "cleared (CLI picks)"))))

;;;###autoload
(defun agnostic-llm-set-provider (provider)
  "Select and persist PROVIDER for future LLM sessions.
Clear saved model or effort defaults that the new provider does not support."
  (interactive
   (list (intern
          (completing-read
           (format "Provider (current: %s): " agnostic-llm-provider)
           (mapcar (lambda (entry) (symbol-name (car entry)))
                   agnostic-llm-providers)
           nil t nil nil (symbol-name agnostic-llm-provider)))))
  (unless (alist-get provider agnostic-llm-providers)
    (user-error "Unknown provider: %s" provider))
  (customize-save-variable 'agnostic-llm-provider provider)
  (let ((cleared nil))
    (unless (or (null agnostic-llm-model)
                (assoc agnostic-llm-model (agnostic-llm--models)))
      (customize-save-variable 'agnostic-llm-model nil)
      (push "model" cleared))
    (unless (or (null agnostic-llm-effort)
                (member agnostic-llm-effort
                        (agnostic-llm-effort-choices-for-model agnostic-llm-model)))
      (customize-save-variable 'agnostic-llm-effort nil)
      (push "effort" cleared))
    (message "LLM provider set to %s (saved)%s"
             provider
             (if cleared
                 (format "; cleared incompatible %s default%s"
                         (string-join (nreverse cleared) " and ")
                         (if (= (length cleared) 1) "" "s"))
               ""))))

(transient-define-suffix agnostic-llm--menu-prompt-bubble ()
  "Launch the inline-conversation bubble; honors the menu's switches."
  :description "Prompt inline (conversation)"
  (interactive)
  (let ((agnostic-llm-bubble-prompt-prefix
         (if (agnostic-llm--menu-switch-p 'btw)
             "/btw "
           ""))
        (agnostic-llm-dangerously-skip-permissions
         (or agnostic-llm-dangerously-skip-permissions (agnostic-llm--menu-dangerous-p)))
        (agnostic-llm-model
         (or (agnostic-llm--menu-option-value 'model) agnostic-llm-model))
        (agnostic-llm-effort (or (agnostic-llm--menu-effort) agnostic-llm-effort))
        (default-directory (or (plist-get (transient-scope) :root)
                               (if (agnostic-llm--menu-use-cwd-p)
                                   default-directory
                                 (or (agnostic-llm--project-root) default-directory)))))
    (agnostic-llm-prompt-bubble)))

(transient-define-suffix agnostic-llm--menu-open-session ()
  "Open the project's agent session vterm; honors the menu's switches."
  :description "Open session in project"
  (interactive)
  (let* ((scope (transient-scope))
         (agnostic-llm-dangerously-skip-permissions
          (or agnostic-llm-dangerously-skip-permissions (agnostic-llm--menu-dangerous-p)))
         (agnostic-llm-model
          (or (agnostic-llm--menu-option-value 'model) agnostic-llm-model))
         (agnostic-llm-effort (or (agnostic-llm--menu-effort) agnostic-llm-effort))
         (root (or (plist-get scope :root)
                   (when (agnostic-llm--menu-use-cwd-p) default-directory)))
         (label (plist-get scope :label))
         (session-name (agnostic-llm--menu-option-value 'session-name))
         (current-prefix-arg nil))
    (agnostic-llm root label session-name)))

(defun agnostic-llm--menu-model-description ()
  "Return the model switch label with its current menu value."
  (format "Model [%s]"
          (or (agnostic-llm--menu-option-value-from 'model
                                                    (transient-get-value))
              agnostic-llm-model "default")))

(defun agnostic-llm--menu-effort-description ()
  "Return the effort switch label with its current menu value."
  (format "Effort [%s]"
          (or (agnostic-llm--menu-option-value-from 'effort
                                                    (transient-get-value))
              agnostic-llm-effort "default")))

(defmacro agnostic-llm--define-menu-option (name option &rest properties)
  "Define transient infix NAME for semantic OPTION with PROPERTIES."
  (declare (indent 2))
  `(transient-define-infix ,name ()
     :argument ,(alist-get option agnostic-llm--transient-option-vocabulary)
     ,@properties))

(agnostic-llm--define-menu-option agnostic-llm--menu-btw-option btw
  :description "Prepend /btw slash-command to inline prompts")

(agnostic-llm--define-menu-option agnostic-llm--menu-cwd-option cwd
  :description "Use current directory (not project root)")

(agnostic-llm--define-menu-option agnostic-llm--menu-dangerous-option dangerous
  :description "Dangerously skip permission prompts")

(agnostic-llm--define-menu-option agnostic-llm--menu-model-option model
  :class 'transient-option
  :description #'agnostic-llm--menu-model-description
  :choices (lambda () (agnostic-llm-model-choices)))

(agnostic-llm--define-menu-option agnostic-llm--menu-effort-option effort
  :class 'transient-option
  :description #'agnostic-llm--menu-effort-description
  :choices (lambda ()
             (agnostic-llm-effort-choices-for-model
              (agnostic-llm--menu-current-model))))

(agnostic-llm--define-menu-option agnostic-llm--menu-session-name-option session-name
  :class 'transient-option
  :description "Session name")

(defun agnostic-llm--menu-header ()
  "Return the options-group title, flagging any pinned session override.
The override -- directory ROOT and buffer LABEL passed to `agnostic-llm-menu' --
lives in the transient scope; `agnostic-llm--menu-open-session' honors it."
  (let ((root  (plist-get (transient-scope) :root))
        (label (plist-get (transient-scope) :label))
        (name (when-let* ((value (ignore-errors
                                   (agnostic-llm--menu-option-value-from
                                    'session-name
                                    (transient-get-value)))))
                (agnostic-llm--session-name-slug value))))
    (if (or root label)
        (concat (propertize "Session override →" 'face 'transient-heading)
                (when root  (concat " dir="
                                    (propertize (abbreviate-file-name (directory-file-name root))
                                                'face 'transient-value)))
                (when label
                  (let ((display-label
                         (if name
                             (format "%s-%s" label name)
                           label)))
                    (concat " buffer="
                            (propertize
                             (agnostic-llm--session-buffer-name display-label)
                             'face 'transient-value)))))
      "Options")))

;;;###autoload (autoload (quote agnostic-llm-menu) "agnostic-llm" nil t)
(transient-define-prefix agnostic-llm-menu (&optional root label)
  "LLM CLI commands.
ROOT and LABEL, when supplied (e.g. by an integration such as org-glance), pin
the session to that directory and buffer name instead of deriving them from the
current project; the header highlights the override."
  [:description agnostic-llm--menu-header
   ("-b" agnostic-llm--menu-btw-option)
   ("-c" agnostic-llm--menu-cwd-option)
   ("-d" agnostic-llm--menu-dangerous-option)
   ("-m" agnostic-llm--menu-model-option)
   ("-e" agnostic-llm--menu-effort-option)
   ("-n" agnostic-llm--menu-session-name-option)]
  [["Session"
    ("c" agnostic-llm--menu-open-session)
    ("v" "Vterm in project"       agnostic-llm-vterm-here)
    ("b" "Switch buffer"          agnostic-llm-switch-buffer)
    ("p" "Prompt"                 agnostic-llm-prompt)
    ("P" agnostic-llm--menu-prompt-bubble)
    ("r" "Resume last prompt"     agnostic-llm-prompt-resume)
    ("H" "Prompt history"         agnostic-llm-prompt-history)
    ("B" "Set provider"           agnostic-llm-set-provider)
    ("M" "Set default model"      agnostic-llm-set-default-model)
    ("?" "Describe at point"      agnostic-llm-describe-at-point)
    ("R" "Show last response"     agnostic-llm-show-last-response)]
   ["Annotations"
    ("f" "Add FIXME"          agnostic-llm-add-fixme)
    ("t" "Add TODO"           agnostic-llm-add-todo)
    ("F" "List FIXMEs"        agnostic-llm-list-fixmes)
    ("T" "List TODOs"         agnostic-llm-list-todos)
    ("S" "Send FIXMEs"        agnostic-llm-send-fixmes)
    ("D" "Send TODOs"         agnostic-llm-send-todos)
    ("G" "Grep annotations"   agnostic-llm-grep-annotations)]
   ["Highlights"
    ("h" "Clear revert highlights" agnostic-llm-change-highlight-clear)]]
  (interactive)
  (transient-setup 'agnostic-llm-menu nil nil :scope (list :root root :label label)))

;;;###autoload
(defun agnostic-llm-toggle-vterm-session ()
  "Toggle current window between `*vterm:PROJECT*' and `*llm:PROJECT*'.
Switches to the counterpart of the current buffer, creating it in the
current window if missing.  When the current buffer is neither, jump
to the project's vterm first (reusing or spawning)."
  (interactive)
  (let* ((name (buffer-name))
         ;; Derive the session prefix's kind from the single source of
         ;; truth so this predicate tracks `agnostic-llm--session-buffer-name'.
         (session-kind (substring agnostic-llm--session-buffer-prefix 1 -1))
         (re (format "\\`\\*\\(vterm\\|%s\\):\\(.*\\)\\*\\'"
                     (regexp-quote session-kind))))
    (if (string-match re name)
        (let* ((kind   (match-string 1 name))
               (label  (match-string 2 name))
               (target (if (equal kind "vterm")
                           (agnostic-llm--session-buffer-name label)
                         (format "*vterm:%s*" label)))
               (existing (get-buffer target)))
          (if (buffer-live-p existing)
              (switch-to-buffer existing)
            (pcase-let* ((`(,_ . ,root) (agnostic-llm--project-label default-directory))
                         (default-directory (or root default-directory)))
              (if (equal kind "vterm")
                  (agnostic-llm--open-vterm
                   target (agnostic-llm--session-shell-command root) t)
                (vterm target)))))
      (let ((current-prefix-arg nil))
        (agnostic-llm-vterm-here)))))

;;;###autoload
(defun agnostic-llm-describe-at-point ()
  "Ask the LLM to describe the symbol at point or the active region.
Spawns a bubble seeded with a prompt referencing the visiting file and
line(s), and auto-sends.  If the buffer isn't visiting a file, the
buffer name is used as context instead."
  (interactive)
  (let* ((region-p (use-region-p))
         (rb (and region-p (region-beginning)))
         (re (and region-p (region-end)))
         (thing (cond
                 (region-p (string-trim (buffer-substring-no-properties rb re)))
                 ((thing-at-point 'symbol t))
                 (t (user-error "No symbol at point and no active region"))))
         (file-name (buffer-file-name))
         (loc (cond
               (region-p (format "lines %d-%d"
                                 (line-number-at-pos rb)
                                 (line-number-at-pos re)))
               (t        (format "line %d" (line-number-at-pos (point))))))
         (where (if file-name
                    (format "%s (%s)" file-name loc)
                  (format "buffer %s (%s)" (buffer-name) loc)))
         (text (if (string-match-p "\n" thing)
                   (format "Describe the following snippet in the context of %s:\n\n```\n%s\n```"
                           where thing)
                 (format "Describe `%s` in the context of %s." thing where)))
         (root (agnostic-llm--current-root))
         (buf (generate-new-buffer "*agnostic-llm-bubble*")))
    (when region-p (deactivate-mark))
    (with-current-buffer buf
      (agnostic-llm--prepare-bubble-buffer root))
    (pop-to-buffer buf)
    (with-current-buffer buf
      (agnostic-llm--bubble-spawn-turn text))))

;;; Vterm display fixups

(defun agnostic-llm--vterm-display-fixups ()
  "Neutralize global display settings that corrupt vterm's character grid.
Some Emacs configs set `line-spacing' globally; the extra
pixels between rows break the vertical box-drawing borders of TUIs like
an interactive agentic CLI, so it is zeroed buffer-locally here.  Symbol
prettification (from `global-prettify-symbols-mode') has no place in a
terminal grid and is likewise disabled.

The terminal dimensions are computed during `vterm-mode' init, before
this hook fires, so they reflect the old `line-spacing'.  A deferred
resize corrects the mismatch once the buffer is displayed."
  (setq-local line-spacing 0)
  (when (bound-and-true-p prettify-symbols-mode)
    (prettify-symbols-mode -1))
  (let ((buf (current-buffer)))
    (run-with-timer 0 nil
      (lambda ()
        (when (and (buffer-live-p buf)
                   (get-buffer-window buf))
          (window--adjust-process-windows))))))

(add-hook 'vterm-mode-hook #'agnostic-llm--vterm-display-fixups)

(provide 'agnostic-llm)
;;; agnostic-llm.el ends here
