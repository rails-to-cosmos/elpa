;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20260713.1033"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "a5d9d4451502d6d0e93bfdae275bd7ce86f7ab1c"
  :revdesc "a5d9d4451502"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
