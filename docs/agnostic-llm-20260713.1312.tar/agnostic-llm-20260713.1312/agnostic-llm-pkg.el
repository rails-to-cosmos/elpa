;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20260713.1312"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "24d03780b1fd97932813c9438ebc2ebb8079bbbc"
  :revdesc "24d03780b1fd"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
