;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20260714.1339"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "f337a8850a090b69379087e1abdebfb6f642f821"
  :revdesc "f337a8850a09"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
