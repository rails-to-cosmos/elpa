;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20260717.1027"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "d8b65902a05738cef6fab281f6c0020a15816e0a"
  :revdesc "d8b65902a057"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
