;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20260724.1132"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (cond-let  "0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "c481040288d83e8fb129dc96909f046f97f26292"
  :revdesc "c481040288d8"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
