;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20260727.1110"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (cond-let  "0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "a4db5cc332eeb729a079098cfb8d20522e7fb2de"
  :revdesc "a4db5cc332ee"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
