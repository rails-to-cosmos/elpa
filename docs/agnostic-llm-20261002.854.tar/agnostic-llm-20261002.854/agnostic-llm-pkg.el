;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20261002.854"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "9b446af8eeb31d6e771f9598d19e534234be049c"
  :revdesc "9b446af8eeb3"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
