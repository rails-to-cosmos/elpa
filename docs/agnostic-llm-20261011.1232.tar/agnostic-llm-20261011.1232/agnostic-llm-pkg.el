;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20261011.1232"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "c27fefaf81a58df0a3c523ee7de6643794d3dda1"
  :revdesc "c27fefaf81a5"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
