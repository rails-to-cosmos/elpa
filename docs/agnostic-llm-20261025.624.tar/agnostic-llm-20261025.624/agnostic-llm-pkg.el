;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20261025.624"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "be4218a98ed329a64abc7e688f8be61a8bfb08ea"
  :revdesc "be4218a98ed3"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
