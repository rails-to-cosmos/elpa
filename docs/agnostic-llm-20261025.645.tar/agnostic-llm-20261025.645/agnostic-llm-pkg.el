;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agnostic-llm" "20261025.645"
  "Agentic CLI integration."
  '((emacs     "28.1")
    (transient "0.4.0")
    (vterm     "0.0.2"))
  :url "https://github.com/rails-to-cosmos/agnostic-llm"
  :commit "e6055eaae508a47faf6093835a67f89082cb1dc1"
  :revdesc "e6055eaae508"
  :keywords '("convenience" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
