;;; Generated from the package header. -*- no-byte-compile: t; -*-
(define-package "agnostic-translate" "0.1.0" "multi-language translation" '((emacs "28.1") (table-view "0.1")))
