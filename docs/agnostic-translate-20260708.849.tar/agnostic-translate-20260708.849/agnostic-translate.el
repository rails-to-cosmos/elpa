;;; agnostic-translate.el --- multi-language translation  -*- lexical-binding: t; -*-

;; Copyright (c) 2026 Dmitry Akatov
;; Author: Dmitry Akatov <dmitry.akatov@protonmail.com>
;; URL: https://github.com/rails-to-cosmos/agnostic-translate
;; Package-Version: 20260708.849
;; Package-Revision: ad1af4f19db1
;; Package-Requires: ((emacs "28.1") (table-view "0.1"))
;; Keywords: convenience, i18n

;;; Commentary:
;;
;; Translate text into multiple languages at once using an LLM backend.
;; Auto-detects the source language from the input and translates into
;; every other language in a configurable list (seeded from system locale
;; and keyboard layouts).
;;
;; Everything lives in one `table-view' buffer, `*agnostic-translate*':
;; each translation is a row, with a column for the detected source
;; language, one column per target language, and an agent comment.  Rows
;; accumulate for the session.  Press `+' to compose input (an
;; Org-capture-style buffer), `a' / `d' to add / remove a language
;; column, `w' / RET to copy the cell at point, and `o' to open the whole
;; row pretty-printed.
;;
;; Requires `claude' CLI (https://docs.anthropic.com/en/docs/claude-cli)
;; on PATH.

;;; Code:

(require 'cl-lib)
(require 'subr-x)
(require 'ansi-color)
(require 'table-view)

;;; Customization

(defgroup agnostic-translate nil
  "LLM-powered translation."
  :group 'tools
  :prefix "agnostic-translate-")

(defconst agnostic-translate--locale-map
  '(("en" . "English") ("ru" . "Russian") ("de" . "German")
    ("fr" . "French")  ("es" . "Spanish") ("it" . "Italian")
    ("pt" . "Portuguese") ("ja" . "Japanese") ("zh" . "Chinese")
    ("ko" . "Korean")  ("ar" . "Arabic")  ("hi" . "Hindi")
    ("nl" . "Dutch")   ("pl" . "Polish")  ("tr" . "Turkish")
    ("uk" . "Ukrainian") ("cs" . "Czech") ("sv" . "Swedish")
    ("us" . "English") ("gb" . "English") ("br" . "Portuguese")
    ("ua" . "Ukrainian") ("cz" . "Czech") ("se" . "Swedish")
    ("jp" . "Japanese"))
  "Map locale/XKB codes to language names.")

(defun agnostic-translate--detect-languages ()
  "Derive a language list from system locale and X11 keyboard layouts."
  (let (codes)
    (when-let ((lang (or (getenv "LANG") (getenv "LC_ALL") (getenv "LANGUAGE"))))
      (when (string-match "\\`\\([a-z][a-z]\\)" lang)
        (cl-pushnew (match-string 1 lang) codes :test #'string=)))
    (with-temp-buffer
      (when (zerop (or (ignore-errors
                        (call-process "setxkbmap" nil t nil "-query"))
                       1))
        (goto-char (point-min))
        (when (re-search-forward "^layout:\\s-*\\(.+\\)" nil t)
          (dolist (code (split-string (match-string 1) "[, ]+" t))
            (cl-pushnew code codes :test #'string=)))))
    (let ((langs (cl-remove-duplicates
                  (delq nil (mapcar (lambda (c)
                                     (cdr (assoc c agnostic-translate--locale-map)))
                                   codes))
                  :test #'string=)))
      (or langs '("English")))))

(defcustom agnostic-translate-languages (agnostic-translate--detect-languages)
  "List of languages the user works with.
When translating, the source language is auto-detected and the text
is translated into every other language in this list.
Initialized from system locale and keyboard layouts."
  :type '(repeat string)
  :group 'agnostic-translate)

(defconst agnostic-translate-model-choices
  '("claude-opus-4-7"
    "claude-opus-4-6"
    "claude-sonnet-4-6"
    "claude-haiku-4-5")
  "Claude models offered when setting `agnostic-translate-model'.
The CLI accepts these full names as well as aliases like \"opus\",
\"sonnet\", \"haiku\".  Edit this list to add new models as they ship.")

(defcustom agnostic-translate-model nil
  "Model passed to claude as `--model'.
Nil means use claude's default (whatever its config picks).  A string
is passed through verbatim — full names like \"claude-opus-4-7\" or
aliases like \"opus\" both work.

Set it from the results buffer with `M' or via
`agnostic-translate-set-default-model'."
  :type '(choice (const :tag "Default (claude picks)" nil)
                 (string :tag "Model name"))
  :group 'agnostic-translate)

(defconst agnostic-translate-all-languages
  '("English" "Russian" "German" "French" "Spanish" "Italian"
    "Portuguese" "Japanese" "Chinese" "Korean" "Arabic" "Hindi"
    "Dutch" "Polish" "Turkish" "Ukrainian" "Czech" "Swedish")
  "All languages offered when adding to the active list.")

;;; Faces

(defface agnostic-translate-header-face
  '((t :inherit header-line :slant italic))
  "Face for popup header lines."
  :group 'agnostic-translate)

;;; State

(defvar agnostic-translate--session-buffer nil
  "The one live results buffer for this session.")

(defconst agnostic-translate--cell-width 60
  "Display-width cap for a translation or comment preview cell.")

(defvar agnostic-translate--session-rows nil
  "Result rows accumulated this session, newest first.
Rendered oldest-to-newest, so the newest translation sits at the bottom.")

(defvar agnostic-translate--session-columns nil
  "Language list the current results table was built with.
When it no longer matches `agnostic-translate-languages', the table is
rebuilt so its columns track the active language set.")

(defvar agnostic-translate--result-counter 0
  "Running counter giving each result row a unique id.")

;;; Process plumbing

(defun agnostic-translate--clean-chunk (chunk)
  "Strip ANSI/OSC/CR and stray control chars from CHUNK."
  (let ((result (thread-last chunk
                  (replace-regexp-in-string "\r" "")
                  (replace-regexp-in-string "\e\\][^\a]*\\(?:\a\\|\e\\\\\\)" "")
                  (replace-regexp-in-string "\e\\[[?<>=]*[0-9;]*[a-zA-Z]" "")
                  (replace-regexp-in-string "\e[()*+][^\e\n]" "")
                  (replace-regexp-in-string "\e[^\e\n]?" "")
                  (replace-regexp-in-string "[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]" "")
                  (replace-regexp-in-string "^[ \t]*[0-9]+[ \t]*\\(?:\n\\|\\'\\)" "")
                  (ansi-color-apply))))
    (if (string-match-p "\\`[0-9[:space:]]*\\'" result) "" result)))

(defun agnostic-translate--parse-results (raw)
  "Parse RAW output into an alist of (KEY . TEXT).
Expects lines like \"[Key]: text\"; KEYs are \"Source\", \"Comment\",
and the target language names."
  (let (results current-lang current-lines)
    (dolist (line (split-string raw "\n"))
      (if (string-match "^\\[\\([^]]+\\)\\]:\\s-*\\(.*\\)" line)
          (progn
            (when current-lang
              (push (cons current-lang
                          (string-trim (mapconcat #'identity (nreverse current-lines) "\n")))
                    results))
            (setq current-lang (match-string 1 line))
            (setq current-lines (list (match-string 2 line))))
        (when (and current-lang
                   (not (string-match-p "\\`[ \t]*[0-9]+[ \t]*\\'" line)))
          (push line current-lines))))
    (when current-lang
      (push (cons current-lang
                  (string-trim (mapconcat #'identity
                                          (nreverse current-lines) "\n")))
            results))
    (nreverse results)))

(defun agnostic-translate--build-prompt (text langs)
  "Build a prompt to detect language and translate TEXT into LANGS.
Requests one `[Source]' line, one `[Language]' line per language
\(the detected language echoes the original text unchanged), and one
`[Comment]' line, so the output parses into a single result row."
  (format "Detect the language of the following text, then translate it into each language in this list: %s.
For the detected source language, output the original text unchanged (do not translate it).
Add one short comment noting anything useful (proper nouns, ambiguity, register).

Output ONLY these lines, nothing else — no explanations, no code fences:
[Source]: <detected language>
%s
[Comment]: <short note>

Text to translate:
%s"
          (mapconcat #'identity langs ", ")
          (mapconcat (lambda (l) (format "[%s]: <translation>" l)) langs "\n")
          text))

(defun agnostic-translate--filter (proc chunk)
  "Accumulate cleaned CHUNK in PROC's hidden work buffer."
  (when (buffer-live-p (process-buffer proc))
    (with-current-buffer (process-buffer proc)
      (goto-char (point-max))
      (insert (agnostic-translate--clean-chunk chunk)))))

(defun agnostic-translate--sentinel (proc _event)
  "Parse PROC's output when it exits and fill its pending row."
  (let ((status (process-status proc)))
    (when (memq status '(exit signal))
      (let* ((work (process-buffer proc))
             (id (process-get proc 'agt-id))
             (raw (when (buffer-live-p work)
                    (string-trim
                     (with-current-buffer work
                       (buffer-substring-no-properties (point-min) (point-max))))))
             (results (when (and (eq status 'exit) raw (not (string-empty-p raw)))
                        (agnostic-translate--parse-results raw))))
        (when (buffer-live-p work) (kill-buffer work))
        (agnostic-translate--results-update id results)))))

(defun agnostic-translate--spawn (text id)
  "Run `claude -p' on TEXT; fill row ID when it finishes.
Output is collected in a hidden work buffer, not shown to the user."
  (let* ((work (generate-new-buffer " *agnostic-translate-proc*"))
         (prompt (agnostic-translate--build-prompt text agnostic-translate-languages))
         (args (append (list "claude" "--output-format" "text")
                       (when agnostic-translate-model
                         (list "--model" agnostic-translate-model))
                       (list "-p" prompt)))
         (process-environment
          (append '("NO_COLOR=1" "CLICOLOR=0" "TERM=dumb")
                  process-environment))
         (proc (apply #'start-process "agnostic-translate" work args)))
    (process-put proc 'agt-id id)
    (set-process-filter   proc #'agnostic-translate--filter)
    (set-process-sentinel proc #'agnostic-translate--sentinel)))

;;; Rows

(defun agnostic-translate--preview (text)
  "Return a one-line, width-bounded preview of TEXT.
Newlines and runs of whitespace collapse to single spaces; the result
is capped at `agnostic-translate--cell-width' display columns."
  (let ((flat (replace-regexp-in-string "[ \t\n]+" " " (string-trim (or text "")))))
    (if (> (string-width flat) agnostic-translate--cell-width)
        (truncate-string-to-width flat agnostic-translate--cell-width nil nil "...")
      flat)))

(defun agnostic-translate--result-row (id results)
  "Build row ID from parsed RESULTS ((KEY . TEXT) ...).
KEYs are \"Source\", \"Comment\", and each language name emitted by the
model.  Displayed cells hold width-bounded previews; the raw values
ride along under an off-column `full' cell for faithful copy."
  (let* ((get (lambda (k) (cdr (assoc-string k results t))))
         (full  (list (cons "src"     (or (funcall get "Source") ""))
                      (cons "comment" (or (funcall get "Comment") ""))))
         (cells (list (cons 'src     (agnostic-translate--preview (funcall get "Source")))
                      (cons 'comment (agnostic-translate--preview (funcall get "Comment"))))))
    (dolist (lang agnostic-translate-languages)
      (let ((val (or (funcall get lang) "")))
        (push (cons lang val) full)
        (push (cons (intern lang) (agnostic-translate--preview val)) cells)))
    `((id . ,id)
      (cells . ,(cons (cons 'full full) cells)))))

(defun agnostic-translate--pending-row (id text)
  "Placeholder row ID marking TEXT as being translated."
  `((id . ,id)
    (cells . ((src . "")
              (comment . ,(concat "⏳ " (agnostic-translate--preview text)))
              (full . (("comment" . ,text)))))))

(defun agnostic-translate--error-row (id)
  "Row ID marking a failed or cancelled translation."
  `((id . ,id)
    (cells . ((src . "")
              (comment . "— translation failed —")
              (full . (("comment" . "translation failed")))))))

;;; Cell actions

(defun agnostic-translate--cell-full-at-point (row)
  "Full text of the cell under point in ROW, or nil when off any cell."
  (let ((col (get-text-property (point) 'table-view-col)))
    (when col
      (or (cdr (assoc col (alist-get 'full (alist-get 'cells row))))
          (cdr (assoc (intern col) (alist-get 'cells row)))))))

(defun agnostic-translate--copy-handler (_id row)
  "Copy the translation cell under point in ROW to the kill ring."
  (let ((text (agnostic-translate--cell-full-at-point row)))
    (if (and (stringp text) (not (string-empty-p text)))
        (progn (kill-new text)
               (message "Copied: %s"
                        (truncate-string-to-width text 60 nil nil "...")))
      (user-error "Point is not on a translation cell"))))

(defun agnostic-translate--view-handler (_id row)
  "Show every translation in ROW pretty-printed in a `view-mode' buffer.
Source language first, then each target language with its full text,
then the agent comment."
  (let* ((full (alist-get 'full (alist-get 'cells row)))
         (src     (cdr (assoc "src" full)))
         (comment (cdr (assoc "comment" full)))
         (langs   (reverse (cl-remove-if
                            (lambda (p) (member (car p) '("src" "comment")))
                            full))))
    (unless full
      (user-error "No translation on this row"))
    (let ((buf (get-buffer-create "*agnostic-translate-detail*")))
      (with-current-buffer buf
        (let ((inhibit-read-only t))
          (erase-buffer)
          (when (and src (not (string-empty-p src)))
            (insert (propertize "Source language: " 'face 'bold) src "\n\n"))
          (dolist (pair langs)
            (unless (string-empty-p (or (cdr pair) ""))
              (insert (propertize (car pair) 'face 'bold) "\n"
                      (cdr pair) "\n\n")))
          (when (and comment (not (string-empty-p comment)))
            (insert (propertize "Comment" 'face 'bold) "\n" comment "\n"))
          (goto-char (point-min)))
        (view-mode 1))
      (display-buffer buf))))

(defun agnostic-translate--capture-handler (&rest _)
  "Action wrapper: open the capture buffer."
  (agnostic-translate-capture))

(defun agnostic-translate--add-lang-handler (&rest _)
  "Action wrapper: add a language column."
  (call-interactively #'agnostic-translate-add-language))

(defun agnostic-translate--remove-lang-handler (&rest _)
  "Action wrapper: remove a language column."
  (call-interactively #'agnostic-translate-remove-language))

(defun agnostic-translate--model-handler (&rest _)
  "Action wrapper: set the default model."
  (call-interactively #'agnostic-translate-set-default-model))

(defun agnostic-translate--results-handlers ()
  "Handler alist for the results table."
  '(("copy"        . agnostic-translate--copy-handler)
    ("view"        . agnostic-translate--view-handler)
    ("new"         . agnostic-translate--capture-handler)
    ("add-lang"    . agnostic-translate--add-lang-handler)
    ("remove-lang" . agnostic-translate--remove-lang-handler)
    ("model"       . agnostic-translate--model-handler)))

;;; Table

(defun agnostic-translate--buffer ()
  "Return the session results buffer, creating it if needed."
  (if (buffer-live-p agnostic-translate--session-buffer)
      agnostic-translate--session-buffer
    (setq agnostic-translate--session-buffer
          (get-buffer-create "*agnostic-translate*"))))

(defun agnostic-translate--results-columns ()
  "Column spec: Source, one column per active language, then Comment."
  (append '(((key . "src") (header . "Source")))
          (mapcar (lambda (lang) `((key . ,lang) (header . ,lang)))
                  agnostic-translate-languages)
          '(((key . "comment") (header . "Comment")))))

(defun agnostic-translate--results-spec ()
  "Full table spec from the accumulated session rows and active columns."
  `((title   . ,(format "Translations — model: %s"
                        (or agnostic-translate-model "claude default")))
    (columns . ,(agnostic-translate--results-columns))
    (actions . (((key . "+")   (command . "new")         (label . "new"))
                ((key . "w")   (command . "copy")        (label . "copy"))
                ((key . "RET") (command . "copy")        (label . "copy"))
                ((key . "o")   (command . "view")        (label . "view"))
                ((key . "a")   (command . "add-lang")    (label . "+lang"))
                ((key . "d")   (command . "remove-lang") (label . "-lang"))
                ((key . "M")   (command . "model")       (label . "model"))))
    (rows    . ,(reverse agnostic-translate--session-rows))))

(defun agnostic-translate--render-table ()
  "(Re)render the whole session table with the current columns.
Return the buffer; do not steal the selected window."
  (setq agnostic-translate--session-columns
        (copy-sequence agnostic-translate-languages))
  (let ((buf (agnostic-translate--buffer)))
    (save-window-excursion
      (table-view-display buf
                          (agnostic-translate--results-spec)
                          (agnostic-translate--results-handlers)))
    (with-current-buffer buf
      (setq-local table-view-render-links nil))
    buf))

(defun agnostic-translate--render-or-upsert (row)
  "Upsert ROW into the live table, or rebuild it when columns changed.
Shows the buffer without stealing the selected window."
  (let ((buf (agnostic-translate--buffer)))
    (if (and (with-current-buffer buf (derived-mode-p 'table-view-mode))
             (equal agnostic-translate--session-columns
                    agnostic-translate-languages))
        (table-view-upsert-row buf row)
      (agnostic-translate--render-table))
    (display-buffer buf)))

(defun agnostic-translate--results-update (id results)
  "Replace pending row ID with a real row from RESULTS, or an error row."
  (let ((row (if results
                 (agnostic-translate--result-row id results)
               (agnostic-translate--error-row id))))
    (setq agnostic-translate--session-rows
          (mapcar (lambda (r) (if (equal (alist-get 'id r) id) row r))
                  agnostic-translate--session-rows))
    (agnostic-translate--render-or-upsert row)))

(defun agnostic-translate--translate-text (text)
  "Add a pending row for TEXT and start translating it."
  (let* ((id (format "%d" (cl-incf agnostic-translate--result-counter)))
         (row (agnostic-translate--pending-row id text)))
    (push row agnostic-translate--session-rows)
    (agnostic-translate--render-or-upsert row)
    (agnostic-translate--spawn text id)))

;;; Capture

(defvar agnostic-translate-capture-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-c") #'agnostic-translate-capture-finish)
    (define-key map (kbd "C-c C-k") #'agnostic-translate-capture-abort)
    map)
  "Keymap for `agnostic-translate-capture-mode'.")

(define-derived-mode agnostic-translate-capture-mode text-mode "AT-Capture"
  "Compose text to translate.
\\<agnostic-translate-capture-mode-map>\\[agnostic-translate-capture-finish] \
translates the buffer; \\[agnostic-translate-capture-abort] cancels."
  (setq header-line-format
        (propertize " Compose  C-c C-c translate | C-c C-k cancel"
                    'face 'agnostic-translate-header-face)))

(defun agnostic-translate-capture (&optional initial)
  "Open a buffer to compose multiline text to translate.
INITIAL, when given, prefills the buffer."
  (interactive)
  (let ((buf (get-buffer-create "*agnostic-translate-capture*")))
    (with-current-buffer buf
      (agnostic-translate-capture-mode)
      (erase-buffer)
      (when initial (insert initial)))
    (pop-to-buffer buf)
    (message "Compose text; C-c C-c to translate, C-c C-k to cancel")))

(defun agnostic-translate-capture-finish ()
  "Translate the composed text and close the capture buffer."
  (interactive)
  (let ((text (string-trim (buffer-string))))
    (when (string-empty-p text)
      (user-error "Nothing to translate"))
    (quit-window t)
    (agnostic-translate--translate-text text)))

(defun agnostic-translate-capture-abort ()
  "Abandon the capture buffer without translating."
  (interactive)
  (quit-window t))

;;; Language and model management

(defun agnostic-translate-add-language (lang)
  "Add LANG as a translation column and persist the change."
  (interactive
   (list (completing-read "Add language: "
                          (cl-set-difference agnostic-translate-all-languages
                                             agnostic-translate-languages
                                             :test #'string=)
                          nil t)))
  (when (and lang (not (member lang agnostic-translate-languages)))
    (customize-save-variable 'agnostic-translate-languages
                             (append agnostic-translate-languages (list lang)))
    (agnostic-translate--render-table)
    (display-buffer (agnostic-translate--buffer))
    (message "Added %s" lang)))

(defun agnostic-translate-remove-language (lang)
  "Remove LANG's column from the active list and persist the change."
  (interactive
   (list (completing-read "Remove language: "
                          agnostic-translate-languages nil t)))
  (when lang
    (let ((new (cl-remove lang agnostic-translate-languages :test #'string=)))
      (when (< (length new) 1)
        (user-error "Need at least one language"))
      (customize-save-variable 'agnostic-translate-languages new)
      (agnostic-translate--render-table)
      (display-buffer (agnostic-translate--buffer))
      (message "Removed %s" lang))))

;;;###autoload
(defun agnostic-translate-set-default-model (model)
  "Set MODEL as the default translation model and persist it.
Empty input clears the default (claude will pick).  The value is saved
via `customize-save-variable', so it survives Emacs restarts."
  (interactive
   (list (completing-read
          (format "Default model (current: %s, empty = claude picks): "
                  (or agnostic-translate-model "none"))
          agnostic-translate-model-choices nil nil nil nil
          agnostic-translate-model)))
  (let ((value (if (string-empty-p (or model "")) nil model)))
    (customize-save-variable 'agnostic-translate-model value)
    (when (buffer-live-p agnostic-translate--session-buffer)
      (agnostic-translate--render-table)
      (display-buffer agnostic-translate--session-buffer))
    (message "Default model %s"
             (if value (format "set to %s (saved)" value)
               "cleared (claude picks)"))))

;;; Entry point

;;;###autoload
(defun agnostic-translate (&optional text)
  "Open the agnostic-translate session buffer.
Translate TEXT or the active region immediately when given; otherwise
show the results table, opening the capture buffer when the session is
empty.  All translations accumulate in one buffer."
  (interactive)
  (let* ((region (when (use-region-p)
                   (prog1 (buffer-substring-no-properties
                           (region-beginning) (region-end))
                     (deactivate-mark))))
         (source (or text region)))
    (agnostic-translate--render-table)
    (pop-to-buffer (agnostic-translate--buffer))
    (cond (source (agnostic-translate--translate-text source))
          ((null agnostic-translate--session-rows)
           (agnostic-translate-capture)))))

(provide 'agnostic-translate)

;;; agnostic-translate.el ends here
