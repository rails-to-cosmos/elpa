;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darr" "20260612.916"
  "Visual layout editor for displays."
  '((emacs "28.1"))
  :url "https://github.com/rails-to-cosmos/darr"
  :commit "3f81bc15887a2fc09f60e0ace5ed7de67e3dd996"
  :revdesc "3f81bc15887a"
  :keywords '("hardware" "multimedia")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
