;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darr" "20260903.1836"
  "Visual layout editor for displays."
  '((emacs "28.1"))
  :url "https://github.com/rails-to-cosmos/darr"
  :commit "3d26ec9d6e296b75111b4dd8a064223a8d99a586"
  :revdesc "3d26ec9d6e29"
  :keywords '("hardware" "multimedia")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
