;;; Generated from the package header. -*- no-byte-compile: t; -*-
(define-package "makeel" "0.1.0" "Makefile target picker with compilation buffers" '((emacs "29.1") (transient "0.4")))
