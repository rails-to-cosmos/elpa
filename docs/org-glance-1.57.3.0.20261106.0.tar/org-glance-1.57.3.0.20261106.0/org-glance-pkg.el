;;; Generated from the package header. -*- no-byte-compile: t; -*-
(define-package "org-glance" "1.57.3.0.20261106.0" "Org-mode projections" '((emacs "29.1") (org "0") (aes "0") (dash "0") (f "0") (s "0") (transient "0") (table-view "0")))
