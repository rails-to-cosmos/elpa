;; -*- lexical-binding: t -*-

;;; org-glance-version.el --- Immutable headline version DAG

(require 'cl-lib)
(require 'f)
(require 'json)
(require 'subr-x)
(require 'org-glance-storage)

(cl-defstruct (org-glance-version (:predicate org-glance-version?)
                                  (:conc-name org-glance-version:))
  schema headline id kind parents targets observed-leaves content-sha256
  created producer directory valid)

(cl-defstruct (org-glance-version-observation
               (:conc-name org-glance-version-observation:))
  inventory history leaves payloads proof frontier directory (reusable t))

(defvar org-glance-version--exhaustive-revalidation nil
  "Whether maintenance revalidates every recorded family path.")

(defvar org-glance-version--observations nil
  "Family observations shared within one write operation.")

(defvar org-glance-version--payloads nil
  "Attribute-guarded payloads shared within one write operation.")

(defvar org-glance-version--observed-paths nil
  "Read-time source stamps collected for the current family observation.")

(defvar org-glance-version--observed-symlink nil
  "Whether the current family observation read a symlink source.")

(defun org-glance-version--record-path (path attributes)
  "Record PATH's read-time ATTRIBUTES in the current observation."
  (when org-glance-version--observed-paths
    (puthash path attributes org-glance-version--observed-paths)))

(defun org-glance-version--record-current-path (path)
  "Record PATH's current stamp when an observation will be retained."
  (when org-glance-version--observed-paths
    (org-glance-version--record-path path (org-glance-version--payload-attributes-at path))))

(cl-defstruct org-glance-version--payload attributes contents text digest)

(defun org-glance-version--make-payload (bytes attributes)
  "Decode exact BYTES and attach their digest and source ATTRIBUTES."
  (let ((contents (decode-coding-string bytes 'utf-8-unix))
        (text (decode-coding-string bytes 'utf-8)))
    (make-org-glance-version--payload
     :attributes attributes :contents contents
     :text (if (equal contents text) contents text)
     :digest (secure-hash 'sha256 bytes))))

(defun org-glance-version--payload-attributes-at (path)
  "Return PATH's identity and mutation stamp, excluding access time."
  (if (file-symlink-p path)
      (progn
        (when org-glance-version--observed-paths
          (setq org-glance-version--observed-symlink t))
        nil)
    (when-let* ((attributes (file-attributes path)))
      (list (file-attribute-size attributes)
            (file-attribute-modification-time attributes)
            (file-attribute-status-change-time attributes)
            (file-attribute-inode-number attributes)
            (file-attribute-device-number attributes)))))

(defun org-glance-version--observation-key (directory headline)
  "Return DIRECTORY and HEADLINE's operation-local observation key."
  (cons (file-name-as-directory (expand-file-name directory)) headline))

(defun org-glance-version--invalidate-observation (directory headline)
  "Forget DIRECTORY and HEADLINE's observation after mutation."
  (when org-glance-version--observations
    (remhash (org-glance-version--observation-key directory headline)
             org-glance-version--observations)))

(defun org-glance-version--read-payload (path)
  "Return PATH's digest and decoded text; signal on a changing read."
  (let* ((attributes (org-glance-version--payload-attributes-at path))
         (held (and org-glance-version--payloads
                    (gethash path org-glance-version--payloads))))
    (if (and attributes held
             (equal attributes (org-glance-version--payload-attributes held)))
        (progn (org-glance-version--record-path path attributes) held)
      (let* ((bytes (f-read-bytes path))
             (payload (org-glance-version--make-payload bytes attributes)))
        (when (and attributes
                   (not (equal attributes (org-glance-version--payload-attributes-at path))))
          (error "Snapshot changed while reading %s" path))
        (org-glance-version--record-path path attributes)
        (when (and attributes org-glance-version--payloads
                   (equal attributes (org-glance-version--payload-attributes-at path)))
          (puthash path payload org-glance-version--payloads))
        payload))))

(defun org-glance-version--observation-current-p (observation &optional exhaustive)
  "Return non-nil when OBSERVATION's frontier stamps still agree.
With EXHAUSTIVE, compare every recorded source stamp."
  (and (org-glance-version-observation:reusable observation)
       (let ((proof
              (if exhaustive
                  (org-glance-version-observation:proof observation)
                (or (org-glance-version-observation:frontier observation)
                    (setf (org-glance-version-observation:frontier observation)
                          (org-glance-version--frontier-proof observation))))))
         (and proof
              (cl-loop for path being the hash-keys of proof
                       using (hash-values stamp)
                       always (and (not (file-symlink-p path))
                                   (equal stamp
                                          (org-glance-version--payload-attributes-at
                                           path))))))))

(defun org-glance-version--frontier-proof (observation)
  "Return OBSERVATION's recorded root, legacy and structural leaf stamps."
  (let* ((proof (org-glance-version-observation:proof observation))
         (frontier (make-hash-table :test #'equal))
         (directory (org-glance-version-observation:directory observation)))
    (when proof
      (dolist (path (list (f-join directory "versions")
                         (f-join directory "data.org")))
        (puthash path (gethash path proof) frontier))
      (dolist (version (org-glance-version-observation:leaves observation))
        (dolist (name '("data.org" "meta.json"))
          (let ((path (f-join (org-glance-version:directory version) name)))
            (puthash path (gethash path proof) frontier))))
      frontier)))

(cl-defun org-glance-version:path (headline-dir version-id)
  "Return VERSION-ID's immutable directory below HEADLINE-DIR."
  (f-join headline-dir "versions" version-id))

(cl-defun org-glance-version:data-file (headline-dir version-id)
  "Return VERSION-ID's snapshot file below HEADLINE-DIR."
  (f-join (org-glance-version:path headline-dir version-id) "data.org"))

(cl-defun org-glance-version:legacy-id (headline digest)
  "Return HEADLINE and DIGEST's deterministic UUIDv5 migration id."
  (let* ((namespace (apply #'unibyte-string
                           '(#x6b #xa7 #xb8 #x10 #x9d #xad #x11 #xd1
                             #x80 #xb4 #x00 #xc0 #x4f #xd4 #x30 #xc8)))
         (hex (secure-hash 'sha1
                           (concat namespace (encode-coding-string headline 'utf-8)
                                   "\0" (encode-coding-string digest 'utf-8))))
         (bytes (substring hex 0 32)))
    (org-glance-version--uuid (org-glance-version--stamp bytes ?5))))

(cl-defun org-glance-version--uuid-v7 ()
  "Return a UUIDv7 string."
  (let* ((millis (floor (* 1000 (float-time))))
         (time-hex (format "%012x" millis))
         (random-hex (apply #'concat
                            (cl-loop repeat 10 collect (format "%02x" (random 256))))))
    (org-glance-version--uuid
     (org-glance-version--stamp (concat time-hex random-hex) ?7))))

(cl-defun org-glance-version--stamp (hex version)
  "Set UUID VERSION and variant bits in the first 32 characters of HEX."
  (let ((out (copy-sequence (substring hex 0 32))))
    (aset out 12 version)
    (aset out 16 (aref "89ab" (% (string-to-number (substring out 16 17) 16) 4)))
    out))

(cl-defun org-glance-version--uuid (hex)
  "Format 32 hexadecimal characters HEX as a UUID."
  (format "%s-%s-%s-%s-%s" (substring hex 0 8) (substring hex 8 12)
          (substring hex 12 16) (substring hex 16 20) (substring hex 20 32)))

(cl-defun org-glance-version--plist (version)
  "Return VERSION's portable metadata plist."
  (if (= 2 (org-glance-version:schema version))
      (list :version 2
            :event (pcase (org-glance-version:kind version)
                     ('snapshot "snapshot-published")
                     ('tombstone "tombstone-published"))
            :headline (org-glance-version:headline version)
            :id (org-glance-version:id version)
            :parents (apply #'vector (org-glance-version:parents version))
            :contentSha256 (org-glance-version:content-sha256 version)
            :created (org-glance-version:created version)
            :producer (org-glance-version:producer version))
    (list :version 1
          :headline (org-glance-version:headline version)
          :id (org-glance-version:id version)
          :kind (symbol-name (org-glance-version:kind version))
          :parents (apply #'vector (org-glance-version:parents version))
          :contentSha256 (org-glance-version:content-sha256 version)
          :created (org-glance-version:created version)
          :producer (org-glance-version:producer version))))

(cl-defun org-glance-version--valid-content-p (version payload)
  "Return non-nil when VERSION's payload agrees with its envelope."
  (condition-case nil
      (let* ((kind (org-glance-version:kind version))
            (digest (org-glance-version:content-sha256 version))
            (present (car payload))
            (contents (cdr payload)))
        (cond
         ((eq kind 'tombstone) (and (null digest) (not present)))
         ((eq kind 'rejection) (and (null digest) (not present)))
         ((eq kind 'snapshot)
          (and digest present contents
               (equal digest (secure-hash 'sha256 contents))))
         (t nil)))
    (error nil)))

(cl-defun org-glance-version--distinct-p (values)
  (= (length values) (length (delete-dups (copy-sequence values)))))

(cl-defun org-glance-version--strings-p (values)
  (and (listp values) (cl-every #'stringp values)))

(cl-defun org-glance-version--version-event-p (version)
  (memq (org-glance-version:kind version) '(snapshot tombstone)))

(cl-defun org-glance-version--candidate (dir headline raw payload)
  "Decode structurally local RAW metadata at DIR for HEADLINE."
  (when (and (listp raw) (integerp (plist-get raw :version))
             (> (plist-get raw :version) 2))
    (org-glance-storage:require-version 'headline-event (plist-get raw :version)))
  (condition-case nil
      (let* ((schema (plist-get raw :version))
             (id (plist-get raw :id))
             (kind-name (if (= schema 1)
                            (plist-get raw :kind)
                          (plist-get raw :event)))
             (kind (pcase kind-name
                     ((or "snapshot" "snapshot-published") 'snapshot)
                     ((or "tombstone" "tombstone-published") 'tombstone)
                     ("leaves-rejected" 'rejection)))
             (parents (if (eq kind 'rejection) nil (plist-get raw :parents)))
             (targets (and (eq kind 'rejection) (plist-get raw :targets)))
             (observed (and (eq kind 'rejection)
                            (plist-get raw :observedLeaves)))
             (digest (plist-get raw :contentSha256))
             (version (make-org-glance-version
                       :schema schema :headline headline :id id :kind kind
                       :parents parents :targets targets :observed-leaves observed
                       :content-sha256 digest :created (plist-get raw :created)
                       :producer (plist-get raw :producer) :directory dir)))
        (when (and (memq schema '(1 2)) kind (stringp id)
                   (equal headline (plist-get raw :headline))
                   (equal (f-filename dir) id)
                   (stringp (org-glance-version:created version))
                   (stringp (org-glance-version:producer version))
                   (org-glance-version--strings-p parents)
                   (org-glance-version--distinct-p parents)
                   (not (member id parents))
                   (pcase kind
                     ('snapshot (stringp digest))
                     ('tombstone (null digest))
                     ('rejection
                      (and (= schema 2) (null digest)
                           (org-glance-version--strings-p targets)
                           (org-glance-version--strings-p observed)
                           (org-glance-version--distinct-p targets)
                           (org-glance-version--distinct-p observed)
                           (cl-every (lambda (target) (member target observed)) targets)
                           (cl-some (lambda (leaf) (not (member leaf targets)))
                                    observed)))))
          (setf (org-glance-version:valid version)
                (org-glance-version--valid-content-p version payload))
          version))
    (error nil)))

(cl-defun org-glance-version:prepare
    (headline-dir headline &key parents producer kind contents)
  "Allocate a KIND event for HEADLINE below HEADLINE-DIR without writing.
Capture PARENTS, PRODUCER and CONTENTS' digest in the returned envelope."
  (let* ((id (org-glance-version--uuid-v7))
         (final (org-glance-version:path headline-dir id))
         (created (format-time-string "%Y-%m-%dT%H:%M:%SZ" nil t))
         (version (make-org-glance-version
                   :schema 2 :headline headline :id id :kind kind
                   :parents (sort (copy-sequence parents) #'string<)
                   :content-sha256 (and contents (secure-hash 'sha256 contents))
                   :created created :producer producer :directory final :valid t)))
    version))

(cl-defun org-glance-version--write
    (headline-dir headline parents producer kind contents _depth)
  "Create one immutable KIND version, optionally holding CONTENTS."
  (org-glance-version--publish
   (org-glance-version:prepare headline-dir headline :parents parents
                              :producer producer :kind kind :contents contents)
   contents))

(defvar org-glance-version--publication-hook nil
  "Function called with each immutable event publication phase.")

(cl-defun org-glance-version--publication-point (phase)
  (when org-glance-version--publication-hook
    (funcall org-glance-version--publication-hook phase)))

(cl-defun org-glance-version--publish (version contents)
  "Publish VERSION atomically, optionally storing CONTENTS."
  (let* ((final (org-glance-version:directory version))
         (parent (f-parent final)))
    (f-mkdir-full-path parent)
    (let ((temp (make-temp-file (f-join parent ".version-") t)) payload envelope-payload)
      (unwind-protect
          (progn
            (org-glance-version--publication-point 'before-temp-write)
            (when contents
              (let ((coding-system-for-write 'utf-8-unix))
                (write-region contents nil (f-join temp "data.org") nil 'silent))
              (when org-glance-version--payloads
                (let ((bytes (encode-coding-string contents 'utf-8-unix)))
                  (setq payload
                        (org-glance-version--make-payload
                         bytes (org-glance-version--payload-attributes-at
                                (f-join temp "data.org")))))))
            (org-glance-version--publication-point 'after-payload-write)
            (let ((coding-system-for-write 'utf-8-unix)
                  (envelope (concat (json-serialize (org-glance-version--plist version)) "\n")))
              (write-region envelope nil (f-join temp "meta.json") nil 'silent)
              (when org-glance-version--payloads
                (setq envelope-payload
                      (org-glance-version--make-payload
                       (encode-coding-string envelope 'utf-8-unix)
                       (org-glance-version--payload-attributes-at (f-join temp "meta.json"))))))
            (org-glance-version--publication-point 'after-envelope-write)
            (rename-file temp final)
            (org-glance-version--invalidate-observation
             (f-parent parent) (org-glance-version:headline version))
            (dolist (entry (list (cons "data.org" payload) (cons "meta.json" envelope-payload)))
              (let ((file (f-join final (car entry))) (source (cdr entry)))
                (when (and source (org-glance-version--payload-attributes source)
                           (equal (org-glance-version--payload-attributes source)
                                  (org-glance-version--payload-attributes-at file)))
                  (puthash file source org-glance-version--payloads))))
            (org-glance-version--publication-point 'after-final-rename)
            (setq temp nil))
        (when (and temp (f-exists? temp)) (delete-directory temp t))))
    version))

(cl-defun org-glance-version:write-snapshot
    (headline-dir headline parents producer contents &optional (depth 10))
  "Create a snapshot version below HEADLINE-DIR."
  (org-glance-version--write
   headline-dir headline parents producer 'snapshot contents depth))

(cl-defun org-glance-version:write-tombstone
    (headline-dir headline parents producer &optional (depth 10))
  "Create a tombstone version below HEADLINE-DIR."
  (org-glance-version--write
   headline-dir headline parents producer 'tombstone nil depth))

(cl-defun org-glance-version:read (headline-dir headline)
  "Read HEADLINE's valid version metadata below HEADLINE-DIR."
  (cl-remove-if-not
   (lambda (version)
     (and (org-glance-version--version-event-p version)
          (org-glance-version:valid version)))
   (org-glance-version:history headline-dir headline)))

(cl-defun org-glance-version:history (headline-dir headline)
  "Read HEADLINE's identifiable version history below HEADLINE-DIR.
Each returned node carries payload integrity in its `valid' slot."
  (copy-sequence
   (org-glance-version-observation:history
    (org-glance-version:observe headline-dir headline))))

(cl-defun org-glance-version:observe
    (headline-dir headline &optional (inventory nil inventory-supplied-p)
                  (exhaustive org-glance-version--exhaustive-revalidation))
  "Observe HEADLINE in HEADLINE-DIR with optional INVENTORY.
Reuse a current operation snapshot; treat its returned contents as immutable.
With EXHAUSTIVE, revalidate every source, including historical versions."
  (let* ((key (org-glance-version--observation-key headline-dir headline))
         (held (and org-glance-version--observations
                    (gethash key org-glance-version--observations))))
    (if (and held (org-glance-version--observation-current-p held exhaustive)
             (or (not inventory-supplied-p)
                 (equal inventory (org-glance-version-observation:inventory held))))
        held
      (let* ((org-glance-version--observed-paths
              (and org-glance-version--observations (make-hash-table :test #'equal)))
             (org-glance-version--observed-symlink nil)
             (root (f-join headline-dir "versions"))
             (_ (org-glance-version--record-current-path root))
             (inventory (if inventory-supplied-p
                            inventory
                          (org-glance-version:inventory headline-dir)))
             (directories (mapcar (lambda (event) (f-join root event)) inventory))
             (observation (org-glance-version--observe-directories
                           headline-dir headline inventory directories)))
        (setf (org-glance-version-observation:proof observation)
              org-glance-version--observed-paths
              (org-glance-version-observation:directory observation) headline-dir
              (org-glance-version-observation:reusable observation)
              (not org-glance-version--observed-symlink))
        (when org-glance-version--observations
          (puthash key observation org-glance-version--observations))
        observation))))

(cl-defun org-glance-version:inventory (headline-dir)
  "Return HEADLINE-DIR's published immutable event-directory names."
  (let ((root (f-join headline-dir "versions")))
    (when (f-directory? root)
      (sort
       (mapcar #'file-name-nondirectory
               (cl-remove-if
                (lambda (path)
                  (let ((name (file-name-nondirectory path)))
                    (or (file-symlink-p path)
                        (string-prefix-p ".version-" name)
                        (string-suffix-p ".tmp" name))))
                (f-directories root)))
       #'string<))))

(cl-defun org-glance-version--observe-directories
    (headline-dir headline inventory directories)
  (let* ((root (f-join headline-dir "versions"))
         (payloads (make-hash-table :test #'equal))
         (candidates
          (when (f-directory? root)
            (cl-loop for dir in (sort directories #'string<)
                     for meta = (f-join dir "meta.json")
                     for data = (f-join dir "data.org")
               do (org-glance-version--record-current-path data)
                  (org-glance-version--record-current-path meta)
                     for payload = (condition-case nil
                                       (if (f-file? data)
                                           (cons t (org-glance-version--payload-contents
                                                    (org-glance-version--read-payload data)))
                                         (cons nil nil))
                                     (error (cons t nil)))
                     do (puthash (file-name-nondirectory dir) payload payloads)
                     when (f-exists? meta)
                     for raw = (condition-case nil
                                   (json-parse-string
                                    (org-glance-version--payload-text
                                     (org-glance-version--read-payload meta))
                                    :object-type 'plist :array-type 'list
                                    :null-object nil :false-object nil)
                                 (error nil))
                     for candidate = (and raw
                                          (org-glance-version--candidate
                                           dir headline raw payload))
                     when candidate collect candidate)))
         (versions (cl-remove-if-not #'org-glance-version--version-event-p
                                     candidates))
         (known (mapcar #'org-glance-version:id versions))
         (changed t)
         stored
         (legacy (progn
                   (org-glance-version--record-current-path (f-join headline-dir "data.org"))
                   (org-glance-version--legacy headline-dir headline))))
    (while changed
      (let ((closed
             (cl-remove-if
              (lambda (version)
                (and (= 2 (org-glance-version:schema version))
                     (cl-some (lambda (parent) (not (member parent known)))
                              (org-glance-version:parents version))))
              versions)))
        (setq changed (/= (length closed) (length versions))
              versions closed
              known (mapcar #'org-glance-version:id versions))))
    (setq stored
          (cl-remove-if
           (lambda (event)
             (and (eq 'rejection (org-glance-version:kind event))
                  (cl-some (lambda (ref) (not (member ref known)))
                           (append (org-glance-version:targets event)
                                   (org-glance-version:observed-leaves event)))))
           candidates))
    (setq stored
          (cl-remove-if
           (lambda (event)
             (and (org-glance-version--version-event-p event)
                  (not (member (org-glance-version:id event) known))))
           stored))
    (let ((history
           (if (and legacy
                    (not (cl-find (org-glance-version:id legacy) stored
                                  :key #'org-glance-version:id :test #'equal)))
               (cons legacy stored)
             stored)))
      (make-org-glance-version-observation
       :inventory inventory :payloads payloads :history history
       :leaves (org-glance-version:leaves history)))))

(cl-defun org-glance-version--legacy (headline-dir headline)
  "Return HEADLINE's implicit legacy root below HEADLINE-DIR."
  (let ((data (f-join headline-dir "data.org")))
    (when (f-file? data)
      (condition-case nil
          (let* ((contents (org-glance-version--payload-contents
                            (org-glance-version--read-payload data)))
                 (digest (secure-hash 'sha256 contents)))
            (make-org-glance-version
             :schema 1 :headline headline
             :id (org-glance-version:legacy-id headline digest)
             :kind 'snapshot :parents nil :content-sha256 digest
             :created "1970-01-01T00:00:00Z" :producer "legacy"
             :directory headline-dir :valid t))
        (error nil)))))

(cl-defun org-glance-version:migrate-legacy (headline-dir headline)
  "Publish HEADLINE's deterministic root, then remove legacy data.org."
  (when-let* ((legacy (org-glance-version--legacy headline-dir headline))
              (data (f-join headline-dir "data.org"))
              (contents (org-glance-version--payload-contents
                         (org-glance-version--read-payload data)))
              (id (org-glance-version:id legacy))
              (final (org-glance-version:path headline-dir id)))
    (let ((version (make-org-glance-version
                    :schema 1 :headline headline :id id :kind 'snapshot
                    :parents nil
                    :content-sha256 (org-glance-version:content-sha256 legacy)
                    :created "1970-01-01T00:00:00Z" :producer "migration"
                    :directory final :valid t)))
      (if (f-directory? final)
          (unless (cl-find-if
                   (lambda (held)
                     (and (equal final (org-glance-version:directory held))
                          (equal (org-glance-version:content-sha256 held)
                                 (org-glance-version:content-sha256 version))))
                   (org-glance-version:read headline-dir headline))
            (error "Invalid migration root already exists: %s" final))
        (org-glance-version--publish version contents))
      (delete-file data)
      (org-glance-version--invalidate-observation headline-dir headline)
      version)))

(cl-defun org-glance-version:leaves (versions)
  "Return VERSIONS not named as another version's parent."
  (let ((versions (cl-remove-if-not #'org-glance-version--version-event-p versions))
        (parents (make-hash-table :test #'equal)))
    (dolist (version versions)
      (dolist (parent (org-glance-version:parents version))
        (puthash parent t parents)))
    (cl-remove-if (lambda (version)
                    (gethash (org-glance-version:id version) parents))
                  versions)))

(cl-defun org-glance-version:current (headline-dir headline)
  "Return a fresh list of HEADLINE's unrejected structural leaves.
Include leaves with damaged payloads."
  (let ((observation (org-glance-version:observe headline-dir headline)))
    (copy-sequence
     (org-glance-version:candidates
      (org-glance-version-observation:history observation)
      :leaves (org-glance-version-observation:leaves observation)))))

(cl-defun org-glance-version:candidates
    (history &key (leaves (org-glance-version:leaves history)))
  "Return HISTORY's unrejected candidates from structural LEAVES.
Derive LEAVES from HISTORY when omitted."
  (let ((rejected (cl-loop for event in history
                           when (eq 'rejection (org-glance-version:kind event))
                           append (org-glance-version:targets event))))
    (cl-remove-if (lambda (version)
                    (member (org-glance-version:id version) rejected))
                  leaves)))

(cl-defun org-glance-version:prune (headline-dir headline depth)
  "Retain DEPTH generations of HEADLINE history and return removed ids.
Zero keeps all history.  A family with several structural leaves is unchanged."
  (when (> depth 0)
    (let* ((observation (org-glance-version:observe headline-dir headline))
           (history (org-glance-version-observation:history observation))
           (leaves (org-glance-version-observation:leaves observation)))
      (when (= 1 (length leaves))
        (let ((by-id (make-hash-table :test #'equal))
              (kept (make-hash-table :test #'equal))
              (frontier (list (org-glance-version:id (car leaves))))
              (remaining (1- depth))
              removed)
          (dolist (version history)
            (puthash (org-glance-version:id version) version by-id))
          (puthash (car frontier) t kept)
          (while (and (> remaining 0) frontier)
            (setq frontier
                  (delete-dups
                   (cl-loop for id in frontier
                            for version = (gethash id by-id)
                            when version
                            append (cl-remove-if-not
                                    (lambda (parent) (gethash parent by-id))
                                    (org-glance-version:parents version)))))
            (dolist (id frontier) (puthash id t kept))
            (setq remaining (1- remaining)))
          (dolist (version history (nreverse removed))
            (let ((id (org-glance-version:id version)))
              (when (and (not (gethash id kept))
                         (equal (org-glance-version:directory version)
                                (org-glance-version:path headline-dir id)))
                (delete-directory (org-glance-version:directory version) t)
                (org-glance-version--invalidate-observation headline-dir headline)
                (push id removed)))))))))

(cl-defun org-glance-version:snapshot-leaves (headline-dir headline)
  "Return HEADLINE's current snapshot versions below HEADLINE-DIR."
  (cl-remove-if-not
   (lambda (version) (eq 'snapshot (org-glance-version:kind version)))
   (org-glance-version:current headline-dir headline)))

(cl-defun org-glance-version:file-p (path)
  "Return non-nil when PATH is an immutable version data or metadata file."
  (string-match-p
   "/versions/[^/]+/\\(?:data\\.org\\|meta\\.json\\)\\'"
   (expand-file-name path)))

(provide 'org-glance-version)
;;; org-glance-version.el ends here
