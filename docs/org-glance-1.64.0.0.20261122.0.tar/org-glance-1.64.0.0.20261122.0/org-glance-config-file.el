;;; org-glance-config-file.el --- Shared JSON file transactions -*- lexical-binding: t -*-

(require 'cl-lib)
(require 'json)
(require 'subr-x)

(define-error 'org-glance-config-error "Invalid Glance configuration")
(define-error 'org-glance-config-busy "Configuration is locked" 'org-glance-config-error)
(define-error 'org-glance-config-conflict "Configuration changed" 'org-glance-config-error)
(define-error 'org-glance-config-unsafe "Unsafe configuration path" 'org-glance-config-error)

(cl-defstruct (org-glance-config-file
               (:constructor org-glance-config-file--make)
               (:conc-name org-glance-config-file:))
  revision object)

(defconst org-glance-config-file--native-exact-json-p
  (condition-case nil
      (and (= 2 (length (json-parse-string "{\"x\":1,\"x\":2}" :object-type 'alist)))
           (integerp (json-parse-string "123456789012345678901234567890")))
    (json-error nil))
  "Whether native JSON retains object pairs and oversized integers.")

(defun org-glance-config-file:path (root)
  "Return ROOT's canonical configuration filename."
  (expand-file-name ".org-glance/config.json" root))

(defun org-glance-config-file--envelope (object)
  "Validate OBJECT's format envelope and return OBJECT."
  (unless (and (hash-table-p object)
               (numberp (gethash "format" object))
               (= 1 (gethash "format" object)))
    (signal 'org-glance-config-error '("config.json requires an object with format 1")))
  object)

(defun org-glance-config-file--decimal (text)
  "Return TEXT's exact decimal identity without floating-point conversion."
  (string-match
   "\\`\\(-?\\)\\([0-9]+\\)\\(?:\\.\\([0-9]+\\)\\)?\\(?:[eE]\\([+-]?[0-9]+\\)\\)?\\'" text)
  (let* ((sign (match-string 1 text))
         (fraction (or (match-string 3 text) ""))
         (exponent (string-to-number (or (match-string 4 text) "0")))
         (digits (replace-regexp-in-string
                  "\\`0+" "" (concat (match-string 2 text) fraction)))
         (trimmed (replace-regexp-in-string "0+\\'" "" digits)))
    (if (string-empty-p digits) '("" 0)
      (list (concat sign trimmed)
            (+ exponent (- (length fraction)) (- (length digits) (length trimmed)))))))

(defun org-glance-config-file--each-number (text function)
  "Call FUNCTION with each numeric literal in TEXT and its start and end."
  (let ((position 0) (size (length text)))
    (while (< position size)
      (let ((char (aref text position)))
        (cond
         ((= char ?\")
          (setq position (1+ position))
          (while (and (< position size) (/= (aref text position) ?\"))
            (setq position (+ position (if (= (aref text position) ?\\) 2 1))))
          (setq position (min size (1+ position))))
         ((or (= char ?-) (and (>= char ?0) (<= char ?9)))
          (if (and (string-match "-?[0-9]+\\(?:\\.[0-9]+\\)?\\(?:[eE][+-]?[0-9]+\\)?" text position)
                   (= position (match-beginning 0)))
              (let ((literal (match-string 0 text)) (start position)
                    (end (match-end 0)))
                (setq position end)
                (funcall function literal start end))
            (cl-incf position)))
         (t (cl-incf position)))))))

(defun org-glance-config-file--number-text (number)
  "Return NUMBER's exact JSON spelling on the running Emacs."
  (if (integerp number) (number-to-string number) (json-serialize number)))

(defun org-glance-config-file--numbers (text)
  "Refuse numeric literals in TEXT that native JSON would silently round."
  (org-glance-config-file--each-number
   text (lambda (literal _start _end)
          (let ((number (if (string-match-p "\\`-?[0-9]+\\'" literal)
                            (string-to-number literal) (json-parse-string literal))))
            (unless (equal (org-glance-config-file--decimal literal)
                           (org-glance-config-file--decimal
                            (org-glance-config-file--number-text number)))
              (signal 'org-glance-config-error
                      '("config.json number cannot round-trip through both clients")))))))

(defun org-glance-config-file--large-integer-p (value)
  "Return whether VALUE exceeds the older native JSON integer range."
  (and (integerp value)
       (or (> value #x7fffffffffffffff) (< value (- #x8000000000000000)))))

(defun org-glance-config-file--parse (text)
  "Parse TEXT, preserving integers beyond older native JSON's range."
  (if org-glance-config-file--native-exact-json-p
      (json-parse-string text :object-type 'alist :null-object :null :false-object :false)
    (let ((validated
           (condition-case original
               (json-parse-string text)
             (json-error
              (let ((start 0) pieces)
                (org-glance-config-file--each-number
                 text (lambda (literal begin end)
                        (when (and (string-match-p "\\`-?\\(?:0\\|[1-9][0-9]*\\)\\'" literal)
                                   (org-glance-config-file--large-integer-p (string-to-number literal)))
                          (push (substring text start begin) pieces)
                          (push "0" pieces)
                          (setq start end))))
                (unless pieces (signal (car original) (cdr original)))
                (json-parse-string
                 (apply #'concat (append (nreverse pieces) (list (substring text start))))))))))
      (unless (hash-table-p validated)
        (signal 'org-glance-config-error '("config.json requires an object with format 1")))
      (let ((json-object-type 'alist) (json-array-type 'vector)
            (json-key-type 'symbol) (json-null :null) (json-false :false))
        (json-read-from-string text)))))

(defun org-glance-config-file:decode (bytes)
  "Decode UTF-8 BYTES, rejecting duplicate keys and unsupported envelopes."
  (let ((text (decode-coding-string bytes 'utf-8-unix)))
    (when (cl-loop for char across text thereis (> char #x10ffff))
      (signal 'org-glance-config-error '("config.json is not valid UTF-8")))
    (cl-labels
        ((convert (value depth)
           (when (> depth 128)
             (signal 'org-glance-config-error '("config.json nesting exceeds 128 levels")))
           (cond
            ((listp value)
             (let ((table (make-hash-table :test 'equal)))
               (dolist (pair value)
                 (let ((key (symbol-name (car pair))))
                   (unless (eq (gethash key table :missing) :missing)
                     (signal 'org-glance-config-error
                             (list (concat "duplicate config.json key: " key))))
                   (puthash key (convert (cdr pair) (1+ depth)) table)))
               table))
            ((vectorp value)
             (dotimes (index (length value) (progn (ignore index) value))
               (aset value index (convert (aref value index) (1+ depth)))))
            (t value))))
      (let* ((parsed (condition-case err
                         (org-glance-config-file--parse text)
                       (json-error
                        (signal 'org-glance-config-error (list (error-message-string err))))))
             (object (org-glance-config-file--envelope (convert parsed 0))))
        (org-glance-config-file--numbers text)
        (org-glance-config-file--make :revision (secure-hash 'sha256 bytes)
                                     :object object)))))

(defun org-glance-config-file--path (root create)
  "Check ROOT's file containment, creating its control directory with CREATE."
  (unless (file-directory-p root)
    (signal 'org-glance-config-unsafe (list root)))
  (let* ((directory (expand-file-name ".org-glance" (file-truename root)))
         (path (expand-file-name "config.json" directory)))
    (when (or (file-symlink-p directory)
              (and (file-exists-p directory) (not (file-directory-p directory))))
      (signal 'org-glance-config-unsafe (list directory)))
    (when (and create (not (file-directory-p directory)))
      (condition-case err
          (make-directory directory)
        (file-already-exists
         (unless (and (file-directory-p directory) (not (file-symlink-p directory)))
           (signal (car err) (cdr err))))))
    (when (or (file-symlink-p path)
              (and (file-exists-p path) (not (file-regular-p path))))
      (signal 'org-glance-config-unsafe (list path)))
    path))

(defun org-glance-config-file--bytes (path)
  "Read PATH's exact bytes, returning nil for an absent file."
  (condition-case err
      (with-temp-buffer
        (set-buffer-multibyte nil)
        (insert-file-contents-literally path)
        (buffer-string))
    (file-missing
     (when (file-exists-p path) (signal (car err) (cdr err)))
     nil)))

(defun org-glance-config-file--read (path &optional observed)
  "Read PATH as one config snapshot; absence supplies the format envelope."
  (let ((bytes (org-glance-config-file--bytes path)))
    (cond
     ((null bytes)
      (let ((object (make-hash-table :test 'equal)))
        (puthash "format" 1 object)
        (org-glance-config-file--make :revision nil :object object)))
     ((and observed (org-glance-config-file:revision observed)
           (equal (secure-hash 'sha256 bytes)
                  (org-glance-config-file:revision observed))) observed)
     (t (org-glance-config-file:decode bytes)))))

(defun org-glance-config-file--check-revision (path expected)
  "Check PATH's current bytes against EXPECTED, preserving malformed-file errors."
  (let* ((bytes (org-glance-config-file--bytes path))
         (revision (and bytes (secure-hash 'sha256 bytes))))
    (unless (equal revision expected)
      (when bytes (org-glance-config-file:decode bytes))
      (signal 'org-glance-config-conflict (list expected revision)))))

(defun org-glance-config-file:read (root &optional observed)
  "Read ROOT's JSON configuration without creating files or acquiring a lock.
Reuse validated OBSERVED only when its exact byte revision still matches."
  (org-glance-config-file--read (org-glance-config-file--path root nil) observed))

(defun org-glance-config-file:with-lock (root action)
  "Run ACTION under ROOT's shared mkdir lock, refusing an existing owner."
  (let* ((path (org-glance-config-file--path root t))
         (lock (concat path ".lock"))
         (previous-inhibit-quit inhibit-quit)
         (inhibit-quit t))
    (condition-case nil
        (make-directory lock)
      (file-already-exists (signal 'org-glance-config-busy (list lock))))
    (unwind-protect
        (let ((inhibit-quit previous-inhibit-quit)) (funcall action))
      (delete-directory lock))))

(defun org-glance-config-file--serialize (object)
  "Encode OBJECT as UTF-8 JSON with a trailing newline."
  (let ((json (condition-case original
                  (json-serialize object :null-object :null :false-object :false)
                (error
                 (unless (org-glance-config-file--large-integer-tree-p object)
                   (signal (car original) (cdr original)))
                 (let ((json-null :null) (json-false :false)
                       (json-encoding-pretty-print nil))
                   (json-encode object))))))
    (concat (if (multibyte-string-p json)
                (encode-coding-string json 'utf-8-unix)
              json)
            "\n")))

(defun org-glance-config-file--large-integer-tree-p (object)
  "Validate OBJECT's JSON value types and detect an oversized integer."
  (let (large)
    (cl-labels ((visit (value depth)
                 (when (> depth 128)
                   (signal 'org-glance-config-error '("config.json nesting exceeds 128 levels")))
                 (cond
                  ((org-glance-config-file--large-integer-p value) (setq large t))
                  ((or (numberp value) (stringp value) (memq value '(t :null :false))))
                  ((hash-table-p value)
                   (maphash (lambda (key field)
                              (unless (stringp key) (error "JSON object key is not text"))
                              (visit field (1+ depth))) value))
                  ((vectorp value) (mapc (lambda (field) (visit field (1+ depth))) value))
                  (t (error "Unsupported JSON value")))))
      (visit object 0))
    large))

(defun org-glance-config-file--publish (path bytes)
  "Replace PATH atomically with BYTES, cleaning up a failed temporary write."
  (let ((temporary (make-temp-file (concat path ".tmp."))))
    (unwind-protect
        (let ((coding-system-for-write 'no-conversion)
              (write-region-inhibit-fsync nil)
              (write-region-annotate-functions nil))
          (write-region bytes nil temporary nil 'silent)
          (when (file-exists-p path)
            (set-file-modes temporary (file-modes path)))
          (rename-file temporary path t))
      (when (file-exists-p temporary) (delete-file temporary)))))

(defun org-glance-config-file--equal (left right)
  "Compare decoded JSON values LEFT and RIGHT independent of object order."
  (cond
   ((hash-table-p left)
    (and (hash-table-p right)
         (= (hash-table-count left) (hash-table-count right))
         (cl-loop for key being the hash-keys of left using (hash-values value)
                  always (org-glance-config-file--equal
                          value (gethash key right :missing)))))
   ((vectorp left)
    (and (vectorp right) (= (length left) (length right))
         (cl-loop for a across left for b across right
                  always (org-glance-config-file--equal a b))))
   ((and (numberp left) (numberp right))
    (or (equal left right)
        (equal (org-glance-config-file--decimal (org-glance-config-file--number-text left))
               (org-glance-config-file--decimal (org-glance-config-file--number-text right)))))
   (t (equal left right))))

(defun org-glance-config-file--prepare (current change)
  "Return CURRENT's validated CHANGE as a (snapshot . optional-bytes) pair."
  (let* ((revision (org-glance-config-file:revision current))
         (before (org-glance-config-file--serialize
                  (org-glance-config-file:object current)))
         (fields (org-glance-config-file--envelope
                  (funcall change (org-glance-config-file:object current))))
         (bytes (org-glance-config-file--serialize fields)))
    (if (and revision (equal before bytes))
        (cons current nil)
      (let ((candidate (org-glance-config-file:decode bytes))
            (original (if org-glance-config-file--native-exact-json-p
                          (json-parse-string before :null-object :null :false-object :false)
                        (let ((json-object-type 'hash-table) (json-array-type 'vector)
                              (json-key-type 'string) (json-null :null) (json-false :false))
                          (json-read-from-string (decode-coding-string before 'utf-8-unix))))))
        (if (and revision (org-glance-config-file--equal
                           original (org-glance-config-file:object candidate)))
            (progn (setf (org-glance-config-file:object current) original)
                   (cons current nil))
          (cons candidate bytes))))))

(cl-defun org-glance-config-file:write (root &key expected change)
  "Prepare CHANGE, then publish under ROOT's lock when EXPECTED still matches.
CHANGE receives the private observed object and returns a validated candidate.
A later peer or lock owner may refuse publication after CHANGE has run."
  (let* ((path (org-glance-config-file--path root nil))
         (lock (concat path ".lock")))
    (when (or (file-exists-p lock) (file-symlink-p lock))
      (signal 'org-glance-config-busy (list lock)))
    (let* ((current (org-glance-config-file--read path))
           (revision (org-glance-config-file:revision current)))
      (unless (equal revision expected)
        (signal 'org-glance-config-conflict (list expected revision)))
      (let ((prepared (org-glance-config-file--prepare current change)))
        (org-glance-config-file:with-lock
         root
         (lambda ()
           (let ((target (org-glance-config-file--path root nil)))
             (org-glance-config-file--check-revision target revision)
             (when (cdr prepared)
               (org-glance-config-file--path root nil)
               (org-glance-config-file--publish target (cdr prepared)))
             (car prepared))))))))

(provide 'org-glance-config-file)
;;; org-glance-config-file.el ends here
