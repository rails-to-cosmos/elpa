;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260714.945"
  "Org-mode mindmap."
  '((emacs      "29.1")
    (org        "0")
    (aes        "0")
    (dash       "0")
    (f          "0")
    (s          "0")
    (transient  "0")
    (table-view "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "c20566795a1624ca168dc8fab60a5f9666d57d85"
  :revdesc "c20566795a16"
  :keywords '("org-mode" "graph" "mindmap")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
