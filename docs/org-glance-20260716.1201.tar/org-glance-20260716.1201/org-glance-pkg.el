;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260716.1201"
  "Org-mode mindmap."
  '((emacs        "29.1")
    (org          "0")
    (aes          "0")
    (dash         "0")
    (f            "0")
    (s            "0")
    (transient    "0")
    (table-view   "0")
    (agnostic-llm "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "3e2353f31d4c7e507da5362f53f6dc8218776542"
  :revdesc "3e2353f31d4c"
  :keywords '("org-mode" "graph" "mindmap")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
