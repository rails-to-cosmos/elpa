;; -*- lexical-binding: t -*-

(require 'dash)
(require 'cl-macs)
(require 'org)
(require 'org-element)

(defvar-local -org-glance-datetime:local-timestamps '())

(define-minor-mode org-glance-datetime-mode "Handle multiple repeatable timestamps."
  :lighter nil
  :global nil
  :group 'glance
  (cond (org-glance-datetime-mode (advice-add 'org-auto-repeat-maybe :before #'org-glance-datetime-capture)
                                  (advice-add 'org-auto-repeat-maybe :after #'org-glance-datetime-restore))
        (t (advice-remove 'org-auto-repeat-maybe #'org-glance-datetime-capture)
           (advice-remove 'org-auto-repeat-maybe #'org-glance-datetime-restore))))

(cl-defun org-glance-datetime-sort-timestamps (tss)
  "Sort TSS."
  (sort tss #'(lambda (lhs rhs) (time-less-p
                            (org-time-string-to-time (org-element-property :raw-value lhs))
                            (org-time-string-to-time (org-element-property :raw-value rhs))))))

(cl-defun org-glance-datetime-buffer-timestamps (&optional (org-data (org-element-parse-buffer)))
  (org-element-map org-data '(timestamp) #'identity))

(cl-defun org-glance-datetime-buffer-schedules (&optional (org-data (org-element-parse-buffer)))
  (org-element-map org-data '(headline) #'(lambda (headline) (org-element-property :scheduled headline))))

(cl-defun org-glance-datetime-buffer-deadlines (&optional (org-data (org-element-parse-buffer)))
  (org-element-map org-data '(headline) #'(lambda (headline) (org-element-property :deadline headline))))

(cl-defun org-glance-datetime-headline-timestamps (&rest includes)
  (save-restriction
    (org-narrow-to-subtree)
    (cl-loop for timestamp in (let ((org-data (org-element-parse-buffer)))
                                (append (org-glance-datetime-buffer-timestamps org-data)
                                        (when (member 'include-schedules includes)
                                          (org-glance-datetime-buffer-schedules org-data))
                                        (when (member 'include-deadlines includes)
                                          (org-glance-datetime-buffer-deadlines org-data))))
       collect timestamp)))

(cl-defun org-glance-datetime:active? (ts)
  (member (org-element-property :type ts) '(active active-range)))

(cl-defun org-glance-datetime-filter-active (tss)
  (--filter (org-glance-datetime:active? it) tss))

(cl-defun org-glance-datetime-filter-repeated (tss)
  (--filter (and (org-glance-datetime:active? it)
                 (> (or (org-element-property :repeater-value it) 0) 0))
            tss))

(cl-defun org-glance-datetime-active-repeated-timestamps (&rest includes)
  "Headline's active, repeated timestamps, sorted.
INCLUDES is passed to `org-glance-datetime-headline-timestamps'."
  (-some->> (apply #'org-glance-datetime-headline-timestamps includes)
    (org-glance-datetime-filter-active)
    (org-glance-datetime-filter-repeated)
    (org-glance-datetime-sort-timestamps)))

(cl-defun org-glance-datetime-capture (&rest _args)
  (setq-local -org-glance-datetime:local-timestamps
              (org-glance-datetime-active-repeated-timestamps)))

(cl-defun org-glance-datetime-restore (&rest _args)
  (let ((standard-output 'ignore)
        (tss* (org-glance-datetime-active-repeated-timestamps)))
    (cl-loop
       for tsi from 1 below (length tss*)
       for ts = (nth tsi -org-glance-datetime:local-timestamps)
       for ts* = (nth tsi tss*)
       do (save-excursion
            (goto-char (org-element-property :begin ts*))
            (delete-region (org-element-property :begin ts*)
                           (org-element-property :end ts*))
            (insert (org-element-property :raw-value ts))))))

(cl-defun org-glance-datetime-reset-buffer-timestamps-except-earliest ()
  "Reset active timestamps in buffer except earliest."
  (let ((standard-output 'ignore)
        (tss (org-glance-datetime-active-repeated-timestamps
              'include-schedules 'include-deadlines)))
    (cl-loop
       for ts in tss
       for index from 0
       do
         (goto-char (org-element-property :begin ts))
         (if (> index 0)
             (org-toggle-timestamp-type)
           ;; reset repeater
           (save-excursion
             (let ((bound1 (org-element-property :begin ts))
                   (bound0 (org-element-property :end ts)))
               (when (and (re-search-forward
                           (concat "\\(" org-scheduled-time-regexp "\\)\\|\\("
                                   org-deadline-time-regexp "\\)\\|\\("
                                   org-ts-regexp "\\)")
                           bound0 t)
                          (re-search-backward "[ \t]+\\(?:[.+]\\)?\\+\\([0-9]+\\)[hdwmy]"
                                              bound1 t))
                 (replace-match "0" t nil nil 1))))))))

(cl-defun org-glance-datetime-headline-repeated-p ()
  "Is headline at point repeated?"
  (save-excursion
    (unless (org-at-heading-p)
      (org-back-to-heading-or-point-min))
    (when (org-glance-datetime-active-repeated-timestamps
           'include-schedules 'include-deadlines)
      t)))

(provide 'org-glance-datetime-mode)
