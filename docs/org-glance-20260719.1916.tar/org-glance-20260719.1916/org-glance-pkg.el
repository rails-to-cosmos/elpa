;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260719.1916"
  "Org-mode mindmap."
  '((emacs        "29.1")
    (org          "0")
    (aes          "0")
    (dash         "0")
    (f            "0")
    (s            "0")
    (transient    "0")
    (table-view   "0")
    (agnostic-llm "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "080097f0eb305550c7fd195cf5471e97ce101b04"
  :revdesc "080097f0eb30"
  :keywords '("org-mode" "graph" "mindmap")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
