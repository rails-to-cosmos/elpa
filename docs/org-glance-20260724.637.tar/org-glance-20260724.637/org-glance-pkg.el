;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260724.637"
  "Org-mode mindmap."
  '((emacs      "29.1")
    (org        "0")
    (aes        "0")
    (dash       "0")
    (f          "0")
    (s          "0")
    (transient  "0")
    (table-view "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "21a9249f51de32bfa3b6109b03adaec92b828d66"
  :revdesc "21a9249f51de"
  :keywords '("org-mode" "graph" "mindmap")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
