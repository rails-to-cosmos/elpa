;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260726.327"
  "Org-mode mindmap."
  '((emacs      "29.1")
    (org        "0")
    (aes        "0")
    (dash       "0")
    (f          "0")
    (s          "0")
    (transient  "0")
    (cond-let   "0")
    (table-view "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "d8dd40c77a3fe46a0f69ca3ce1ab15ba9f24390c"
  :revdesc "d8dd40c77a3f"
  :keywords '("org-mode" "graph" "mindmap")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
