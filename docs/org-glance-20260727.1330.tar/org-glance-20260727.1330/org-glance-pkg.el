;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260727.1330"
  "Org-mode mindmap."
  '((emacs      "29.1")
    (org        "0")
    (aes        "0")
    (dash       "0")
    (f          "0")
    (s          "0")
    (transient  "0")
    (cond-let   "0")
    (table-view "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "a946fe697de33c2220ca733178984810f7ba2073"
  :revdesc "a946fe697de3"
  :keywords '("org-mode" "graph" "mindmap")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
