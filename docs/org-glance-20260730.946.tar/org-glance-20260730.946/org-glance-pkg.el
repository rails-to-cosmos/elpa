;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260730.946"
  "Org-mode mindmap."
  '((emacs      "29.1")
    (org        "0")
    (aes        "0")
    (dash       "0")
    (f          "0")
    (s          "0")
    (transient  "0")
    (cond-let   "0")
    (table-view "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "50930ad490ffc8fbafd3dccd4abb669c53b57a43"
  :revdesc "50930ad490ff"
  :keywords '("org-mode" "graph" "mindmap")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
