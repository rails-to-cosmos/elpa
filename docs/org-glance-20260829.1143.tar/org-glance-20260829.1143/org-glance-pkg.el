;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260829.1143"
  "Org-mode projections."
  '((emacs      "29.1")
    (org        "0")
    (aes        "0")
    (dash       "0")
    (f          "0")
    (s          "0")
    (transient  "0")
    (cond-let   "0")
    (table-view "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "ca476cdb44eaad463eecf0a09a8963a073924559"
  :revdesc "ca476cdb44ea"
  :keywords '("org-mode" "outlines" "data" "database" "store" "projections")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
