;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260831.1211"
  "Org-mode projections."
  '((emacs      "29.1")
    (org        "0")
    (aes        "0")
    (dash       "0")
    (f          "0")
    (s          "0")
    (transient  "0")
    (cond-let   "0")
    (table-view "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "fea4f7fc9fb79cf9056fd7a054b9a95d37a139ef"
  :revdesc "fea4f7fc9fb7"
  :keywords '("org-mode" "outlines" "data" "database" "store" "projections")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
