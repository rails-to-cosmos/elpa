;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260923.1039"
  "Org-mode projections."
  '((emacs      "29.1")
    (org        "0")
    (aes        "0")
    (dash       "0")
    (f          "0")
    (s          "0")
    (transient  "0")
    (cond-let   "0")
    (table-view "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "aff5f11f7d6c5bafc1041600522d1e7b45a44eb9"
  :revdesc "aff5f11f7d6c"
  :keywords '("org-mode" "outlines" "data" "database" "store" "projections")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
