;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance" "20260925.1510"
  "Org-mode projections."
  '((emacs      "29.1")
    (org        "0")
    (aes        "0")
    (dash       "0")
    (f          "0")
    (s          "0")
    (transient  "0")
    (table-view "0"))
  :url "https://github.com/rails-to-cosmos/org-glance"
  :commit "59fc1bf0005f24481815a6b42ccf9a18ce855306"
  :revdesc "59fc1bf0005f"
  :keywords '("org-mode" "outlines" "data" "database" "store" "projections")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
