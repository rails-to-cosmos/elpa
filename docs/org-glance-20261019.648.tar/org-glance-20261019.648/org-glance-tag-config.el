;; -*- lexical-binding: t -*-
;; `org-glance-tag-config' -- system TODO cycle and optional per-tag config.

(require 's)
(require 'org)
(require 'cl-lib)
(require 'f)

(require 'org-glance-tag)
(require 'org-glance-headline)
(require 'org-glance-graph)
(require 'org-glance-filter)
(require 'org-glance-utils)

(require 'org-glance-core)

(defcustom org-glance-tag-config-dir nil
  "Directory of per-tag config files, or nil for the store's `config/tags/'."
  :group 'org-glance
  :type '(choice (const :tag "Default (store config/tags/)" nil) directory))

(cl-defstruct (org-glance-tag-config (:predicate org-glance-tag-config?)
                                     (:constructor org-glance-tag-config)
                                     (:conc-name org-glance-tag-config:))
  "A tag's optional configuration, projected from its `config/tags/<tag>.org'."
  (tag nil :read-only t :type symbol)                   ; the configured tag (= file name)
  (title nil :read-only t :type (or null string))       ; `#+TITLE:' human label, or nil
  (todo nil :read-only t :type (or null string))        ; `#+TODO:'-style cycle, or nil
  (template nil :read-only t :type (or null string)))   ; capture entry (from the first `*')

(defconst org-glance-tag-config:fields
  '((tag       nil        nil)     ; supplied by the file NAME
    (title     "TITLE"    nil)     ; human label; never emitted into a buffer
    (todo      "TODO"     t)       ; the todo cycle: capture + overview emit it
    (template  nil        nil))    ; the body from the first `*'
  "Per-tag config schema rows (SLOT PRAGMA EMIT?), checked against the struct.
PRAGMA: SLOT's `#+PRAGMA:' keyword, or nil; EMIT?: rendered buffers emit it.")

(cl-defun org-glance-tag-config--check-fields (slots fields)
  "Signal an error unless FIELDS lists struct SLOTS in order; else return t."
  (org-glance--check-struct-field-order
   :slots slots :fields fields :subject "tag-config"))

(org-glance-tag-config--check-fields
 (cdr (cl-struct-slot-info 'org-glance-tag-config))
 org-glance-tag-config:fields)

(cl-defun org-glance-tag-config--pragma-slots (&optional emitting)
  "Return (SLOT . PRAGMA) for each slot read from a `#+PRAGMA:' keyword.
With EMITTING, only those a rendered buffer emits."
  (cl-loop for (slot pragma emit) in org-glance-tag-config:fields
           when (and pragma (or (not emitting) emit))
           collect (cons slot pragma)))

(cl-defun org-glance-tag-config:dir (graph)
  "Return GRAPH's tag config directory, possibly nonexistent, or nil if none.
`org-glance-tag-config-dir' overrides the store's `config/tags/'."
  (or (and (stringp org-glance-tag-config-dir) org-glance-tag-config-dir)
      (and (org-glance-graph? graph)
           (org-glance-graph:config-file graph "tags"))))

(cl-defun org-glance-tag-config:file (graph tag)
  "Return tag symbol TAG's config file `<dir>/<tag>.org' in GRAPH, or nil."
  (when-let* ((dir (org-glance-tag-config:dir graph)))
    (f-join dir (concat (org-glance-tag:to-string tag) ".org"))))

(cl-defun org-glance-tag-config:system-file (graph)
  "Return GRAPH's system config file, or nil without a graph."
  (when (org-glance-graph? graph)
    (org-glance-graph:config-file graph "system.org")))

(cl-defun org-glance-tag-config:source-mtime (graph)
  "Return the newest mtime of GRAPH's system and tag config files."
  (let* ((system (org-glance-tag-config:system-file graph))
         (times (append (and system (list (org-glance--file-mtime system)))
                        (mapcar #'cadr (org-glance-tag-config--snapshot
                                        (org-glance-tag-config:dir graph))))))
    (cl-loop for mtime in times
             with newest = nil
             when (and mtime (or (null newest) (time-less-p newest mtime)))
             do (setq newest mtime)
             finally return newest)))

(cl-defun org-glance-tag-config--file-keyword (key)
  "Return the buffer's first `#+KEY:' value trimmed, or nil if absent or blank."
  (save-excursion
    (goto-char (point-min))
    (when (re-search-forward (format "^#\\+%s:[ \t]*\\(.*\\)$" (regexp-quote key)) nil t)
      (let ((v (s-trim (match-string-no-properties 1))))
        (unless (string-empty-p v) v)))))

(cl-defun org-glance-tag-config--entry ()
  "Return the buffer's capture entry, its first heading to EOF, or nil if none."
  (save-excursion
    (goto-char (point-min))
    (when (re-search-forward "^\\*+ " nil t)
      (s-trim-right (buffer-substring-no-properties (line-beginning-position)
                                                    (point-max))))))

(cl-defun org-glance-tag-config--parse-file (path tag)
  "Parse config file PATH for TAG (a symbol) into an `org-glance-tag-config'."
  (with-temp-buffer
    (let ((coding-system-for-read 'utf-8))
      (insert-file-contents path))
    (apply #'org-glance-tag-config
           :tag tag
           :template (org-glance-tag-config--entry)
           (cl-loop for (slot . pragma) in (org-glance-tag-config--pragma-slots)
                    append (list (intern (concat ":" (symbol-name slot)))
                                 (org-glance-tag-config--file-keyword pragma))))))

(cl-defun org-glance-tag-config--tag-of-file (path)
  "Return the tag symbol config file PATH configures: its base name."
  (org-glance-tag:from-string (f-base path)))

(cl-defun org-glance-tag-config--parse (dir)
  "Parse DIR's `<tag>.org' files into a tag -> config hash (empty without DIR)."
  (let ((by-tag (make-hash-table :test 'eq)))
    (when (and dir (f-directory? dir))
      (dolist (path (directory-files dir t "\\.org\\'"))
        (let ((tag (org-glance-tag-config--tag-of-file path)))
          (when (and (org-glance-tag? tag) (not (gethash tag by-tag)))
            (puthash tag (org-glance-tag-config--parse-file path tag) by-tag)))))
    by-tag))

(defvar org-glance-tag-config--cache nil
  "Module cache plist (:dir D :snapshot S :by-tag HASH), or nil (cold).")

(cl-defun org-glance-tag-config--snapshot (dir)
  "Return DIR's cache key: its sorted `*.org' files' (NAME MTIME SIZE), or nil."
  (when (and dir (f-directory? dir))
    (cl-loop for path in (sort (directory-files dir t "\\.org\\'") #'string<)
             for attrs = (file-attributes path)
             collect (list (f-filename path)
                           (file-attribute-modification-time attrs)
                           (file-attribute-size attrs)))))

(cl-defun org-glance-tag-config--invalidate ()
  "Drop the in-memory config cache, so the next resolve re-reads the files.
Called after in-process writes, which mtime granularity could hide."
  (setq org-glance-tag-config--cache nil))

(cl-defun org-glance-tag-config--by-tag (graph)
  "Return GRAPH's tag -> config hash, re-parsed on a dir or snapshot change."
  (let* ((dir (org-glance-tag-config:dir graph))
         (snapshot (org-glance-tag-config--snapshot dir))
         (cache org-glance-tag-config--cache))
    (unless (and cache
                 (equal (plist-get cache :dir) dir)
                 (equal (plist-get cache :snapshot) snapshot))
      (setq org-glance-tag-config--cache
            (list :dir dir :snapshot snapshot
                  :by-tag (org-glance-tag-config--parse dir))))
    (plist-get org-glance-tag-config--cache :by-tag)))

(cl-defun org-glance-tag-config:resolve (graph tag)
  "Resolve TAG to its `org-glance-tag-config' in GRAPH, or nil if it has none.
Nil means TAG uses the default capture template and system TODO cycle."
  (cl-check-type tag org-glance-tag)
  (gethash tag (org-glance-tag-config--by-tag graph)))

(cl-defun org-glance-tag-config:cycle->keywords (cycle)
  "Return `org-todo-keywords' sequences for newline-separated CYCLE strings."
  (mapcar (lambda (line) (cons 'sequence (split-string line)))
          (split-string cycle "\n" t)))

(cl-defun org-glance-tag-config:cycle->keywords-or (cycle default)
  "Return CYCLE's `org-todo-keywords' form, or DEFAULT when CYCLE is nil."
  (if cycle (org-glance-tag-config:cycle->keywords cycle) default))

(defun org-glance-tag-config:resolve-keywords (scopes recognition)
  "Resolve ordered SCOPES of (ACTIVE . INACTIVE), retaining RECOGNITION.
The first scope naming a keyword decides its meaning.
Unclaimed words are active."
  (let ((seen (make-hash-table :test 'equal)) active inactive)
    (dolist (scope (append '((("TODO") . ("DONE"))) scopes
                           (list (cons recognition nil))))
      (dolist (word (append (car scope) (cdr scope)))
        (unless (gethash word seen)
          (puthash word t seen)
          (if (member word (car scope)) (push word active) (push word inactive)))))
    (cons (nreverse active) (nreverse inactive))))

(defun org-glance-tag-config:todo-declarations (text)
  "Observe TEXT's TODO aliases as (START END VALUE) in source order.
Spans are zero-based and half-open.  Opaque blocks are excluded.
SETUPFILE is not followed: this observation owns only the supplied source."
  (with-temp-buffer
    (let* ((dos (string-match-p "\r\n" text))
           (starts (when dos
                     (let ((offset 0) (positions (list 0)))
                       (while (string-match "\n" text offset)
                         (setq offset (match-end 0))
                         (push offset positions))
                       (vconcat (nreverse positions)))))
           (line 0) (previous 1))
      (insert (if dos (replace-regexp-in-string "\r\n" "\n" text t t) text))
      (setq-local tab-width 8)
      (let ((major-mode 'org-mode) (case-fold-search t) declarations)
	(goto-char (point-min))
	(while (re-search-forward (org-make-options-regexp '("TODO" "SEQ_TODO" "TYP_TODO")) nil t)
          (let ((element (org-element-at-point)))
            (when starts
              (cl-incf line (count-lines previous (line-beginning-position)))
              (setq previous (line-beginning-position)))
            (when (org-element-type-p element 'keyword)
              (push (list (if starts (aref starts line) (1- (line-beginning-position)))
                          (if starts (if (< (1+ line) (length starts)) (aref starts (1+ line)) (length text))
                            (1- (line-beginning-position 2)))
                          (org-element-property :value element)) declarations))))
	(nreverse declarations)))))

(defun org-glance-tag-config:declaration-keywords (declarations)
  "Resolve observed DECLARATIONS with explicit active meaning in source order."
  (let (active inactive)
    (dolist (declaration declarations)
      (let ((done nil))
        (dolist (token (split-string (nth 2 declaration)))
          (if (equal token "|") (setq done t)
            (let ((word (car (org-remove-keyword-keys (list token)))))
              (if done (push word inactive) (push word active)))))))
    (let ((a (delete-dups (nreverse active))))
      (cons a (cl-remove-if (lambda (word) (member word a))
                            (delete-dups (nreverse inactive)))))))

(defun org-glance-tag-config:declared-keywords (text)
  "Read TEXT's source-owned TODO declarations with explicit active meaning."
  (org-glance-tag-config:declaration-keywords (org-glance-tag-config:todo-declarations text)))

(cl-defun org-glance-tag-config:done-keywords-for-filter (graph filter)
  "Return the done keywords FILTER's views honour in GRAPH.
Those of its system and tag cycles, else `org-glance--done-keywords'.
Bind `org-done-keywords' to it to build a `:done' predicate or a badge split."
  (if-let* ((cycle (org-glance-tag-config:cycle-for-filter graph filter)))
      (org-glance-tag-config:done-keywords cycle)
    (org-glance--done-keywords)))

(cl-defun org-glance-tag-config:done-keywords (todo-spec)
  "Return the done keywords of TODO-SPEC, or nil when it is blank.
Org derives them, so the split matches what a `#+TODO:' header produces."
  (when (org-glance--present-string? todo-spec)
    (with-temp-buffer
      (let ((org-todo-keywords (org-glance-tag-config:cycle->keywords todo-spec)))
        (delay-mode-hooks (org-mode))
        (copy-sequence org-done-keywords)))))

(cl-defun org-glance-tag-config--tags-for-filter
    (graph filter &optional (metas nil metas-supplied-p))
  "Return FILTER's tags, or every live tag in GRAPH when FILTER is nil."
  (if filter
      (org-glance-filter:tags filter)
    (and (org-glance-graph? graph)
         (mapcar #'org-glance-tag:from-string
                 (if metas-supplied-p
                     (org-glance-graph:tags graph metas)
                   (org-glance-graph:tags graph))))))

(cl-defun org-glance-tag-config--cycle-sources
    (graph filter &optional (metas nil metas-supplied-p))
  "Return distinct TODO cycles and their source files for FILTER in GRAPH.
Each result is (CYCLE SOURCE...), ordered system first and then by tag.  METAS,
when supplied, is GRAPH's precomputed live Row projection."
  (let ((system-file (org-glance-tag-config:system-file graph))
        groups)
    (cl-labels ((add (cycle source)
                  (when cycle
                    (if-let* ((group (assoc cycle groups)))
                        (push source (cdr group))
                      (push (list cycle source) groups)))))
      (when (and system-file (file-readable-p system-file))
        (with-temp-buffer
          (insert-file-contents system-file)
          (add (org-glance-tag-config--file-keyword "TODO") system-file)))
      (dolist (tag (if metas-supplied-p
                       (org-glance-tag-config--tags-for-filter graph filter metas)
                     (org-glance-tag-config--tags-for-filter graph filter)))
        (when-let* ((config (org-glance-tag-config:resolve graph tag)))
          (add (org-glance-tag-config:todo config)
               (org-glance-tag-config:file graph tag)))))
    (setq groups (nreverse groups))
    (dolist (group groups)
      (setcdr group (nreverse (cdr group))))
    groups))

(cl-defun org-glance-tag-config:cycles-for-filter
    (graph filter &optional (metas nil metas-supplied-p))
  "Return system then distinct tag TODO sequences for FILTER in GRAPH."
  (mapcar #'car
          (if metas-supplied-p
              (org-glance-tag-config--cycle-sources graph filter metas)
            (org-glance-tag-config--cycle-sources graph filter))))

(cl-defun org-glance-tag-config:cycle-for-filter
    (graph filter &optional (metas nil metas-supplied-p))
  "Return GRAPH's system and FILTER's tag TODO cycles, newline-separated.
Use precomputed METAS when supplied."
  (when-let* ((cycles
               (if metas-supplied-p
                   (org-glance-tag-config:cycles-for-filter graph filter metas)
                 (org-glance-tag-config:cycles-for-filter graph filter))))
    (mapconcat #'identity cycles "\n")))

(cl-defun org-glance-tag-config:preamble (config)
  "Return CONFIG's emittable pragmas as `#+KEY: VALUE' lines, or nil."
  (org-glance-tag-config--preamble-lines
   (cl-loop for (slot . pragma) in (org-glance-tag-config--pragma-slots t)
            collect (cons pragma (cl-struct-slot-value 'org-glance-tag-config
                                                       slot config)))))

(cl-defun org-glance-tag-config:preamble-for-filter
    (graph filter &optional source-comments (metas nil metas-supplied-p))
  "Return separate `#+TODO:' lines for system and FILTER's tags in GRAPH.
With SOURCE-COMMENTS, prefix each line with comments naming its config files.
Use precomputed METAS when supplied."
  (if source-comments
      (when-let* ((groups
                   (if metas-supplied-p
                       (org-glance-tag-config--cycle-sources graph filter metas)
                     (org-glance-tag-config--cycle-sources graph filter))))
        (apply
         #'concat
         (mapcar
          (lambda (group)
            (concat
             (mapconcat
              (lambda (source)
                (format "# TODO source: %s"
                        (if (org-glance-graph? graph)
                            (file-relative-name
                             source (org-glance-graph:store-path graph))
                          (abbreviate-file-name source))))
              (cdr group) "\n")
             "\n#+TODO: " (car group) "\n"))
          groups)))
    (org-glance-tag-config--preamble-lines
     (mapcar (lambda (cycle) (cons "TODO" cycle))
             (org-glance-tag-config:cycles-for-filter graph filter)))))

(cl-defun org-glance-tag-config--preamble-lines (pairs)
  "Return PAIRS ((PRAGMA . VALUE)...) as `#+PRAGMA: VALUE' lines, or nil.
Blank values drop out."
  (let ((lines (cl-loop for (pragma . value) in pairs
                        when (org-glance--present-string? value)
                        collect (concat "#+" pragma ": " value "\n"))))
    (when lines (apply #'concat lines))))

(defconst org-glance-tag-config--render-strip
  (append '("TAG" "TODO_KEYWORDS") org-glance-headline:hash-ignore-properties)
  "Drawer keys stripped from a rendered capture instance.
Legacy `:TAG:'/`:TODO_KEYWORDS:' keys a migrated or hand-edited entry retained;
the cycle lives only in a `#+TODO:' file keyword.")

(cl-defun org-glance-tag-config:render (config title tags)
  "Render an `org-capture' template for an instance of CONFIG.
TITLE replaces the heading text, TAGS its tags, and `--render-strip' keys go;
the rest stays verbatim.  The heading gets a `%?' unless one sits below it.
Signal a `user-error' when CONFIG has no capture entry."
  (cl-check-type config org-glance-tag-config)
  (cl-check-type title string)
  (let ((template (org-glance-tag-config:template config))
        (tags (org-glance-tag:as-list tags)))
    (unless (org-glance--present-string? template)
      (user-error "org-glance: tag config for `%s' has no capture entry (add a `*' heading)"
                  (org-glance-tag-config:tag config)))
    (with-temp-buffer
      (insert template)
      (org-glance--org-mode)
      (dolist (property org-glance-tag-config--render-strip)
        (goto-char (point-min))
        (org-entry-delete nil property))
      (goto-char (point-min))
      ;; `org-edit-headline' overwrites a `%?' in the heading, so only a
      ;; capture point BELOW it counts.
      (let ((skeleton-has-point (save-excursion
                                  (end-of-line)
                                  (s-contains? "%?" (buffer-substring-no-properties
                                                     (point) (point-max))))))
        (org-edit-headline (concat title (if skeleton-has-point "" "%?")))
        (goto-char (point-min))
        (org-set-tags (mapcar #'org-glance-tag:to-string tags)))
      (s-trim-right (buffer-substring-no-properties (point-min) (point-max))))))

(cl-defun org-glance-tag-config--migrate-on-open (graph)
  "Split GRAPH's legacy `config/tags.org' into per-tag files, once.
On `org-glance-graph-after-open-functions' (error-demoted, invariant 9), each
level-1 `:TAG:' headline becomes `<tag>.org': heading text as `#+TITLE:',
`:TODO_KEYWORDS:' as `#+TODO:', subtree minus both keys as capture entry.
Existing per-tag files are kept; the legacy file becomes `tags.org.bak'."
  (when-let* ((legacy (org-glance-graph:config-file graph "tags.org"))
              ((f-exists? legacy))
              (dir (org-glance-tag-config:dir graph)))
    (f-mkdir-full-path dir)
    (with-temp-buffer
      (let ((coding-system-for-read 'utf-8))
        (insert-file-contents legacy))
      (org-glance--org-mode)
      (goto-char (point-min))
      (while (re-search-forward "^\\* " nil t)
        (org-back-to-heading t)
        (let* ((tag-raw (org-entry-get nil "TAG"))
               (tag (and tag-raw (org-glance-tag:from-string tag-raw)))
               (todo (org-entry-get nil "TODO_KEYWORDS"))
               (title (org-get-heading t t t t))
               (beg (point))
               (end (save-excursion (org-end-of-subtree t t) (point))))
          (when (and (org-glance-tag? tag)
                     (not (f-exists? (org-glance-tag-config:file graph tag))))
            (let* ((subtree (buffer-substring-no-properties beg end))
                   (entry (with-temp-buffer
                            (insert subtree)
                            (org-glance--org-mode)
                            (goto-char (point-min))
                            (org-entry-delete nil "TAG")
                            (org-entry-delete nil "TODO_KEYWORDS")
                            (s-trim-right (buffer-substring-no-properties
                                           (point-min) (point-max))))))
              (f-write-text
               (concat "#+TITLE: " (if (org-glance--present-string? title)
                                       title (symbol-name tag)) "\n"
                       (when (org-glance--present-string? todo)
                         (concat "#+TODO:  " (s-trim todo) "\n"))
                       "\n" entry "\n")
               'utf-8 (org-glance-tag-config:file graph tag))))
          (goto-char end))))
    (rename-file legacy (concat legacy ".bak") t)
    (org-glance-tag-config--invalidate)))

(add-hook 'org-glance-graph-after-open-functions
          #'org-glance-tag-config--migrate-on-open)

(cl-defun org-glance-tag-config--stub (tag)
  "Return the stub contents of a new config file for TAG.
Comments listing the optional pragmas, none active, then a bare capture entry."
  (let ((name (symbol-name tag)))
    (concat
     "# Config for the `" name "' tag (the file name is the tag).\n"
     "# Below the comments is the org-capture template only.\n"
     "#\n"
     "# Optional pragmas to add ABOVE the `*' heading:\n"
     "#   #+TITLE:    a human label for the tag (default: the tag name).\n"
     "#   #+TODO:     another todo sequence, e.g. `DOING | DONE'\n"
     "#               (absent = the system cycle or `org-todo-keywords').\n"
     "#   #+CATEGORY: agenda category, default the tag name (planned).\n"
     "#   #+AUTHOR:   planned.\n"
     "#\n"
     "# The heading below is the skeleton: its text is filled with the captured\n"
     "# title + tags.  Add `%^{...}' prompts and keep exactly one `%?'.\n"
     "\n"
     "* %?\n")))

(cl-defun org-glance-tag-config--edit-candidates (graph)
  "Return the sorted tags to offer for configuration: GRAPH's tags and configs."
  (org-glance--sorted-distinct
   (append (and (org-glance-graph? graph) (org-glance-graph:tags graph))
           (let ((dir (org-glance-tag-config:dir graph)))
             (and dir (f-directory? dir)
                  (mapcar #'f-base (directory-files dir nil "\\.org\\'")))))))

(cl-defun org-glance-tag-config--lint ()
  "Warn about, and return as strings, the current tag config buffer's issues.
Flags residual `:TODO_KEYWORDS:'/`:TAG:' keys and a missing capture entry."
  (let (issues)
    (save-excursion
      (goto-char (point-min))
      (when (re-search-forward "^[ \t]*:TODO_KEYWORDS:" nil t)
        (push "`:TODO_KEYWORDS:' drawer is ignored -- set the cycle with a `#+TODO:' file keyword"
              issues))
      (goto-char (point-min))
      (when (re-search-forward "^[ \t]*:TAG:" nil t)
        (push "`:TAG:' drawer is ignored -- the file name is the tag" issues))
      (goto-char (point-min))
      (unless (re-search-forward "^\\*+ " nil t)
        (push "no capture entry -- add a `*' heading (org-capture needs one)" issues)))
    (setq issues (nreverse issues))
    (when issues
      (display-warning 'org-glance
                       (concat "tag config issues:\n- " (mapconcat #'identity issues "\n- "))
                       :warning))
    issues))

(cl-defun org-glance-tag-config--on-save ()
  "Invalidate the config cache, then lint; buffer-local on `after-save-hook'."
  (org-glance-tag-config--invalidate)
  (org-glance-tag-config--lint))

;;;###autoload
(cl-defun org-glance-tag-config-edit (&optional tag)
  "Open TAG's config file, creating a stub if absent; `C' in the transient.
With TAG nil, prompt for it among live tags and existing configs."
  (interactive)
  (let* ((graph (and (org-glance-initialized?) org-glance-graph))
         (tag-str (or tag (completing-read "Configure tag: "
                                           (org-glance-tag-config--edit-candidates graph))))
         (tag-sym (org-glance-tag:from-string (org-glance-tag:validate-string tag-str)))
         (path (or (org-glance-tag-config:file graph tag-sym)
                   (user-error "org-glance: not initialised and no `org-glance-tag-config-dir' set"))))
    (unless (f-exists? path)
      (f-mkdir-full-path (f-dirname path))
      (f-write-text (org-glance-tag-config--stub tag-sym) 'utf-8 path))
    (find-file path)
    (add-hook 'after-save-hook #'org-glance-tag-config--on-save nil t)))

(provide 'org-glance-tag-config)
