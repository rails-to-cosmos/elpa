;;; Generated from the package header. -*- no-byte-compile: t; -*-
(define-package "org-glance-llm" "0.5.2.0.20261110.0" "LLM sessions for org-glance headlines" '((emacs "29.1") (org-glance "1.24") (agnostic-llm "0.12.0.0.20261025.0") (table-view "0")))
