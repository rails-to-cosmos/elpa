;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance-llm" "20260723.1706"
  "LLM sessions for org-glance headlines."
  '((emacs        "29.1")
    (org-glance   "1.24")
    (agnostic-llm "0")
    (table-view   "0"))
  :url "https://github.com/rails-to-cosmos/org-glance-llm"
  :commit "add29703e72e495c0612fb4f332bf0cd189f041d"
  :revdesc "add29703e72e"
  :keywords '("convenience" "outlines")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
