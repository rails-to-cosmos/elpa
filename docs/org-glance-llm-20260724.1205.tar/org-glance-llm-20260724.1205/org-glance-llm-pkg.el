;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance-llm" "20260724.1205"
  "LLM sessions for org-glance headlines."
  '((emacs        "29.1")
    (org-glance   "1.24")
    (agnostic-llm "0")
    (table-view   "0"))
  :url "https://github.com/rails-to-cosmos/org-glance-llm"
  :commit "4fdf9980999dce1fc10c982840a95bf04574d410"
  :revdesc "4fdf9980999d"
  :keywords '("convenience" "outlines")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
