;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance-llm" "20260923.1404"
  "LLM sessions for org-glance headlines."
  '((emacs        "29.1")
    (org-glance   "1.24")
    (agnostic-llm "20260916.2109")
    (table-view   "0"))
  :url "https://github.com/rails-to-cosmos/org-glance-llm"
  :commit "0b864300f9a305664ef3b2f1062bdf87ce69ba46"
  :revdesc "0b864300f9a3"
  :keywords '("convenience" "outlines")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
