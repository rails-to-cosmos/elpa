;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance-llm" "20260924.729"
  "LLM sessions for org-glance headlines."
  '((emacs        "29.1")
    (org-glance   "1.24")
    (agnostic-llm "20260916.2109")
    (table-view   "0"))
  :url "https://github.com/rails-to-cosmos/org-glance-llm"
  :commit "f540e762e135126e5aa28c1dd423ba7ffa4bf139"
  :revdesc "f540e762e135"
  :keywords '("convenience" "outlines")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
