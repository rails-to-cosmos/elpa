;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance-llm" "20261025.626"
  "LLM sessions for org-glance headlines."
  '((emacs        "29.1")
    (org-glance   "1.24")
    (agnostic-llm "20261025")
    (table-view   "0"))
  :url "https://github.com/rails-to-cosmos/org-glance-llm"
  :commit "96c6cec1a287f9812121284d5c541fc487639680"
  :revdesc "96c6cec1a287"
  :keywords '("convenience" "outlines")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
