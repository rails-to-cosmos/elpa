;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-glance-llm" "20261025.645"
  "LLM sessions for org-glance headlines."
  '((emacs        "29.1")
    (org-glance   "1.24")
    (agnostic-llm "20261025")
    (table-view   "0"))
  :url "https://github.com/rails-to-cosmos/org-glance-llm"
  :commit "1501a6e685fed778844cabd8b738a53064674b1f"
  :revdesc "1501a6e685fe"
  :keywords '("convenience" "outlines")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
