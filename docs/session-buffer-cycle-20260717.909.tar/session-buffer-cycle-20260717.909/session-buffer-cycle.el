;;; session-buffer-cycle.el --- Cycle per-project session buffers in a window -*- lexical-binding: t; -*-

;; Copyright (c) 2026 Dmitry Akatov

;; Author: Dmitry Akatov <dmitry.akatov@protonmail.com>
;; URL: https://github.com/rails-to-cosmos/session-buffer-cycle
;; Package-Version: 20260717.909
;; Package-Revision: b1493f1145e7
;; Package-Requires: ((emacs "28.1"))
;; Keywords: convenience, tools

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Flip the current window through a set of per-project "session" buffers.
;; Each project (detected via `project.el', falling back to
;; `default-directory') gets one buffer per configured kind, named
;; `*KIND:LABEL*' where LABEL is the project's final path component.
;;
;; `session-buffer-cycle' switches the current window to the next kind's
;; buffer, wrapping around and creating it on demand.  From any buffer that
;; is not a session buffer it enters the cycle at the first kind.
;;
;; The kinds live in `session-buffer-cycle-kinds', an alist mapping a KIND
;; string to an OPENER function called with (NAME LABEL ROOT).  The opener
;; creates a buffer named NAME in the current window; `default-directory' is
;; already bound to ROOT.  The default cycles an eshell and a Dired buffer,
;; both built in.  Add anything you like -- a vterm, a shell attached to a
;; CLI agent, a browser, a REPL:
;;
;;   ;; A plain vterm and a Claude CLI vterm:
;;   (require 'vterm)
;;   (setq session-buffer-cycle-kinds
;;         '(("vterm" . (lambda (name _label _root) (vterm name)))
;;           ("llm"   . (lambda (name _label _root)
;;                        (let ((vterm-shell "claude")) (vterm name))))))
;;
;; Binds no keys itself.  Bind `session-buffer-cycle' from your config, e.g.
;;
;;   (global-set-key (kbd "C-x C-x") #'session-buffer-cycle)

;;; Code:

(require 'cl-lib)
(require 'project)

;; Declared special so the on-demand `let' in the Eshell opener rebinds it
;; dynamically without pulling in Eshell at load time.
(defvar eshell-buffer-name)

(defgroup session-buffer-cycle nil
  "Cycle per-project session buffers in a window."
  :group 'convenience
  :prefix "session-buffer-cycle-")

;;;###autoload
(defun session-buffer-cycle-open-eshell (name _label _root)
  "Open an Eshell named NAME in the current window.
An opener for `session-buffer-cycle-kinds'.  `default-directory' is bound
to the project root, so the shell starts there."
  (let ((eshell-buffer-name name))
    (eshell)))

;;;###autoload
(defun session-buffer-cycle-open-dired (name _label root)
  "Open Dired on ROOT in the current window as buffer NAME.
An opener for `session-buffer-cycle-kinds'."
  (switch-to-buffer (dired-noselect root))
  (rename-buffer name))

(defcustom session-buffer-cycle-kinds
  '(("eshell" . session-buffer-cycle-open-eshell)
    ("dired"  . session-buffer-cycle-open-dired))
  "Session kinds cycled by `session-buffer-cycle'.
Each element is (KIND . OPENER).  KIND is the buffer name segment in
`*KIND:LABEL*'; OPENER is a function called with (NAME LABEL ROOT) that
creates a buffer named NAME in the current window, with `default-directory'
bound to ROOT.  List order is the cycle order; the first kind is the entry
point when the current buffer is not a session buffer.

The default cycles an Eshell and a Dired buffer.  Add any command you want
in the rotation, e.g. a vterm:

  (add-to-list \\='session-buffer-cycle-kinds
               (cons \"vterm\"
                     (lambda (name _label _root) (vterm name)))
               t)"
  :type '(alist :key-type string :value-type function)
  :group 'session-buffer-cycle)

(defun session-buffer-cycle--root (dir)
  "Return the project root for DIR, or DIR itself when there is no project."
  (or (when-let ((proj (project-current nil dir)))
        (expand-file-name (project-root proj)))
      (expand-file-name dir)))

(defun session-buffer-cycle--label (root)
  "Return the session label for ROOT: its final path component."
  (file-name-nondirectory (directory-file-name root)))

(defun session-buffer-cycle--switch-to-kind (entry label root)
  "Switch to or create the `*KIND:LABEL*' buffer for ENTRY.
ENTRY is a (KIND . OPENER) cell from `session-buffer-cycle-kinds'; ROOT is
the project root, bound as `default-directory' while the opener runs."
  (let* ((target   (format "*%s:%s*" (car entry) label))
         (existing (get-buffer target)))
    (if (buffer-live-p existing)
        (switch-to-buffer existing)
      (let ((default-directory (file-name-as-directory root)))
        (funcall (cdr entry) target label root)))))

;;;###autoload
(defun session-buffer-cycle ()
  "Cycle the current window through `session-buffer-cycle-kinds'.
Each kind owns a `*KIND:LABEL*' buffer for the current project.  From such
a buffer, switch to the next kind in the list (wrapping around), creating it
via that kind's opener when missing.  From any other buffer, enter the cycle
at the first kind."
  (interactive)
  (let ((kinds session-buffer-cycle-kinds))
    (unless kinds
      (user-error "`session-buffer-cycle-kinds' is empty"))
    (let* ((name (buffer-name))
           (re   (format "\\`\\*\\(%s\\):\\(.*\\)\\*\\'"
                         (mapconcat (lambda (k) (regexp-quote (car k))) kinds "\\|"))))
      (if (string-match re name)
          (let* ((pos   (cl-position (match-string 1 name) kinds
                                     :key #'car :test #'equal))
                 (next  (nth (mod (1+ pos) (length kinds)) kinds))
                 (label (match-string 2 name))
                 (root  (session-buffer-cycle--root default-directory)))
            (session-buffer-cycle--switch-to-kind next label root))
        (let* ((root  (session-buffer-cycle--root default-directory))
               (label (session-buffer-cycle--label root)))
          (session-buffer-cycle--switch-to-kind (car kinds) label root))))))

(provide 'session-buffer-cycle)
;;; session-buffer-cycle.el ends here
