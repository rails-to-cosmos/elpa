;;; Generated from the package header. -*- no-byte-compile: t; -*-
(define-package "table-view" "0.10.1" "Declarative, producer-agnostic table view" '((emacs "28.1")))
