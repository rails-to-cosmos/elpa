;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view" "20260719.825"
  "Declarative, backend-agnostic table view."
  '((emacs "28.1"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "33bd04ce7d357645f2edaad178b0dd26b656f08d"
  :revdesc "33bd04ce7d35"
  :keywords '("convenience" "data" "tools")
  :authors '(("Dmitry Akatov" . "akatovda@gmail.com"))
  :maintainers '(("Dmitry Akatov" . "akatovda@gmail.com")))
