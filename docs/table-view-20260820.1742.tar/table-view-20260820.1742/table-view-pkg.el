;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view" "20260820.1742"
  "Declarative, producer-agnostic table view."
  '((emacs "28.1"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "e021d6a6ef5d880a8df5fc9390b122ab2987964d"
  :revdesc "e021d6a6ef5d"
  :keywords '("convenience" "data" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
