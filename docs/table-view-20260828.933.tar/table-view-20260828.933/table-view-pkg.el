;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view" "20260828.933"
  "Declarative, producer-agnostic table view."
  '((emacs "28.1"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "d18974cdbfcc12076bad52783d959e705ae17123"
  :revdesc "d18974cdbfcc"
  :keywords '("convenience" "data" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
