;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view" "20261005.1320"
  "Declarative, producer-agnostic table view."
  '((emacs "28.1"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "680a6c0909ce7e2d05f0327b8b854cce1cb6cccc"
  :revdesc "680a6c0909ce"
  :keywords '("convenience" "data" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
