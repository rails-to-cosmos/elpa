;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view" "20261011.522"
  "Declarative, producer-agnostic table view."
  '((emacs "28.1"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "60a40b753263d3fb2ae05ab65976b1d6bae189b8"
  :revdesc "60a40b753263"
  :keywords '("convenience" "data" "tools")
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
