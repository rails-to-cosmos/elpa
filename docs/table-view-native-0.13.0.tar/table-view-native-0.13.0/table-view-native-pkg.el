;;; Generated from the package header. -*- no-byte-compile: t; -*-
(define-package "table-view-native" "0.13.0" "Native (Rust) accelerator for table-view" '((emacs "28.1") (table-view "0.13.0")))
