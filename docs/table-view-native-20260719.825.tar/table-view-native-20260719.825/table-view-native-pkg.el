;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view-native" "20260719.825"
  "Native (Rust) data backend for table-view."
  '((emacs      "28.1")
    (table-view "0.4.0"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "33bd04ce7d357645f2edaad178b0dd26b656f08d"
  :revdesc "33bd04ce7d35"
  :authors '(("Dmitry Akatov" . "akatovda@gmail.com"))
  :maintainers '(("Dmitry Akatov" . "akatovda@gmail.com")))
