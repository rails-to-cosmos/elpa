;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view-native" "20260723.947"
  "Native (Rust) data backend for table-view."
  '((emacs      "28.1")
    (table-view "0.5.0"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "a550bf3a50c9aa817855183c7491232767adc10b"
  :revdesc "a550bf3a50c9"
  :authors '(("Dmitry Akatov" . "akatovda@gmail.com"))
  :maintainers '(("Dmitry Akatov" . "akatovda@gmail.com")))
