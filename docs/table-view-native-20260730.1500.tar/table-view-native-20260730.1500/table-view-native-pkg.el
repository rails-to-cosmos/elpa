;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view-native" "20260730.1500"
  "Native (Rust) data backend for table-view."
  '((emacs      "28.1")
    (table-view "0.7.0"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "d3d2d51e23a6bc4253cc753d0b027580a9b2062d"
  :revdesc "d3d2d51e23a6"
  :authors '(("Dmitry Akatov" . "akatovda@gmail.com"))
  :maintainers '(("Dmitry Akatov" . "akatovda@gmail.com")))
