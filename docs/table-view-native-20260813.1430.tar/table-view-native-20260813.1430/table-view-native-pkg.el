;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view-native" "20260813.1430"
  "Native (Rust) data backend for table-view."
  '((emacs      "28.1")
    (table-view "0.7.0"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "7260035dd05e3c82f2224d73f057ee362df9fad9"
  :revdesc "7260035dd05e"
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
