;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view-native" "20260815.1427"
  "Native (Rust) accelerator for table-view."
  '((emacs      "28.1")
    (table-view "0.7.0"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "a76b42ebeb2e9e6c5dbc2db28e14b1402197a6a4"
  :revdesc "a76b42ebeb2e"
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
