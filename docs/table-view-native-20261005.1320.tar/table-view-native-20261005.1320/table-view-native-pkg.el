;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view-native" "20261005.1320"
  "Native (Rust) accelerator for table-view."
  '((emacs      "28.1")
    (table-view "0.7.0"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "680a6c0909ce7e2d05f0327b8b854cce1cb6cccc"
  :revdesc "680a6c0909ce"
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
