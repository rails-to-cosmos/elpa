;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "table-view-native" "20261011.530"
  "Native (Rust) accelerator for table-view."
  '((emacs      "28.1")
    (table-view "0.10.1"))
  :url "https://github.com/rails-to-cosmos/table-view"
  :commit "d976cf032594703124b7c7e82406dad228136d84"
  :revdesc "d976cf032594"
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
